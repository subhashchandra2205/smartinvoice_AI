# Trusted PDF verification

New uploads go through authenticated processing-role checks before the server reads or stores bytes. Direct browser storage uploads are denied. Private organization/hash paths with create-only storage writes reuse an existing upload on retries instead of storing another copy; processed hash duplicates are blocked on upload, and concurrent/replayed processing still records a rejected decision through the existing transaction.

The server checks the 20 MB limit, supported PDF header, EOF trailer and cross-reference offset, then parses the file. It re-extracts the stored PDF before validation; caller-supplied text is ignored except for explicitly untrusted legacy imports. Structured fields, GST components, source text, extraction provenance and decisions are saved, with provenance in the same transaction as decision/audit evidence. Existing approval locking is unchanged.

## Checks actually run
- 46 application tests passed, including 10 new PDF cases: valid fields/GST components, truncation, renamed non-PDF, forged PDF header, over-20-MB bytes, hash/path deduplication, no-text evidence, image-only scan, encrypted PDF rejection and missing currency.
- 10 real PostgreSQL approval/concurrency tests passed against a disposable local database.
- Signed-in preview: valid PDF saved and read back, repeated PDF blocked, renamed non-PDF blocked, image-only PDF saved as Needs Review with OCR-required evidence.
- Live access checks: anonymous server upload blocked, foreign-organization server upload blocked, direct browser storage upload blocked.
- Latest application build passed; signed-in upload checks produced no page errors. Synthetic records and private files were removed.

## Remaining limits
- OCR is not implemented. No-text pages require OCR/manual review; partially unreadable PDFs also require review.
- Encrypted PDFs are unsupported. Extraction is rule-based and missing fields remain missing; canonical invoice currency retains the existing schema default for compatibility, but extracted currency remains empty and forces review.
- Parser limits: 100 pages, one million extracted characters and bounded image dimensions. These are safety bounds, not a guarantee against CPU/memory exhaustion; maximum-size and adversarial-PDF load testing on the published environment has not been performed.
- PDF parsing can recover some structural defects. Header/trailer checks and strict content parsing reject tested corruption, but do not constitute a full PDF conformance validator or malware scanner.
- PDFs uploaded successfully but not subsequently processed remain private and are reused by hash on retry; automatic orphan cleanup is not implemented.
- Published deployment was not changed or tested in this task. Publish the updated app before using the new upload boundary on the public site; the old published browser-upload flow will be blocked until updated.