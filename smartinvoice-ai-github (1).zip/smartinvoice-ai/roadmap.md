# Recruiter-ready invoice demo
- [x] Separate subtotal, tax and grand total; require invoice dates.
- [x] Validate cumulative approved spending against PO balance and expose match candidates.
- [x] Save unreadable/scanned PDFs as Needs Review with evidence (manual-review fallback, not OCR).
- [x] Add four downloadable demo scenarios and regression tests.
- [x] Write project guide and verify the live invoice flow.

# Fintech dashboard redesign
- [x] Replace typography and colors; refresh shared shell and account pages without logic changes.
- [x] Add saved Rules drawer and Settings navigation; refresh overview and processing layouts.
- [x] Add history search, filters, sorting and record detail drawer.
- [x] Verify existing tests, invoice flow and mobile layout.

# Phase 3 shared cloud processing
- [x] Connect authenticated processing to organization POs, private PDFs and atomic decision/audit saves.
- [x] Replace local history/dashboard reads with shared organization records and authorized PDF viewing.
- [x] Offer deliberate, retry-safe legacy import without changing local history.
- [x] Verify validation, persistence, permissions, organization isolation and shared access; report limitations.

# Vendor and purchase order management
- [x] Extend reference records and enforce validated organization-scoped writes.
- [x] Add searchable, filterable, sortable, paginated vendor and PO pages.
- [x] Integrate vendor matching and available PO balance into invoice decisions.
- [x] Verify regression rules, authenticated management flows, mobile screens and security.

# Concurrency-safe PO approvals
- [x] Add transaction-locked approval RPC and protect automatic approval spending.
- [x] Connect permitted human approvals without redesigning existing pages.
- [x] Test concurrent balances, duplicate and organization isolation, failed-decision rollback.
- [x] Verify signed-in approval flow and preserve existing regression tests.

# Trusted server PDF extraction
- [x] Verify private uploads, enforce byte limits and hash deduplication with server-side permissions.
- [x] Extract trusted PDF text and fields; preserve validation and locked approvals.
- [x] Show upload, verification, extraction and validation progress without redesign.
- [x] Test valid, malformed, oversized, duplicate, scanned, encrypted and unauthorized PDFs; verify signed-in flow.

# Complete production readiness
- [x] Current acceptance: verify private PDF archive recovery, retention recommendations, auth/email blockers and dependency security without deleting records.
- [x] Fix removed-creator organization read access, preserve atomic onboarding and test membership revocation.
- [ ] Publish stable changes and verify deployment completion; publication scheduling is checked separately from completion.
- [ ] Complete branded auth/invitation email sending; blocked by missing owned sender domain and real inbox confirmation recipient.
- [ ] Configure encrypted off-site backups and execute isolated restore; blocked by owner destination and actual backup inventory evidence.
- [x] Current request: test large histories and live controls; assess email, backup and deployment gaps, fixing issues without design changes.
- [x] Inspect existing implementation and report gaps without changing design or existing data.
- [x] Enforce independent human approvals, rejection, corrections and governed organization rules.
- [x] Add OCR integration and exact financial/GST evidence; advanced tax jurisdiction and arbitrary line-item completeness remain documented limits.
- [x] Add durable idempotent jobs, leases, retained failures and retry; abandoned PDFs are retained, never deleted automatically.
- [x] Correct canonical dashboard totals and add scoped reports, history filters and 25-row presentation pagination.
- [x] Complete bounded history pages, on-demand details and SQL dashboard/report aggregates; test 10,050 records in isolated PostgreSQL.
- [x] Harden audit/PDF access and verify 61 regression tests, 15 transaction tests, CSV and four screen sizes.
- [x] Verify 14 live processor/member controls, private PDF access and signed-out published protection.
- [ ] Full published two-user approval/OCR/load checks wait on completed deployment and owner-designated separate test accounts.
- [x] Document verified results, deployment steps, backups and outstanding dependencies in PRODUCTION_HANDOVER.md.
- [ ] Complete reset-link inbox/password-change check, backup inventory/restore drill and retention policy; waits on owner inbox, backup review and business retention duration.