CREATE OR REPLACE FUNCTION public.commit_cloud_invoice(_org uuid,_actor uuid,_revision text,_payload jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE inv jsonb := _payload->'invoice'; res jsonb := _payload->'result'; vid uuid; pid uuid; iid uuid; rid uuid; legacy uuid := nullif(_payload->>'legacy_id','')::uuid; stamp timestamptz := now(); dup boolean := false;
BEGIN
IF auth.role() <> 'service_role' THEN RAISE EXCEPTION 'Forbidden'; END IF;
IF NOT EXISTS(SELECT 1 FROM public.organization_members WHERE organization_id=_org AND user_id=_actor AND role IN ('admin','finance_manager','invoice_processor')) THEN RAISE EXCEPTION 'Forbidden'; END IF;
PERFORM pg_advisory_xact_lock(hashtextextended(_org::text,0));
IF legacy IS NOT NULL THEN SELECT id INTO rid FROM public.processing_runs WHERE organization_id=_org AND legacy_record_id=legacy; IF rid IS NOT NULL THEN RETURN jsonb_build_object('id',rid,'already_imported',true); END IF; END IF;
IF public.cloud_invoice_revision(_org) <> _revision THEN RETURN jsonb_build_object('retry',true); END IF;
IF legacy IS NULL AND NOT EXISTS(SELECT 1 FROM storage.objects WHERE bucket_id='invoice-pdfs' AND name=_payload->>'file_path' AND name LIKE _org::text||'/%') THEN RAISE EXCEPTION 'Private PDF missing'; END IF;
SELECT id INTO vid FROM public.vendors WHERE organization_id=_org AND normalized_name=public.normalize_vendor_name(inv->>'vendor_name');
SELECT id INTO pid FROM public.purchase_orders WHERE organization_id=_org AND po_number=inv->>'po_number';
SELECT id INTO iid FROM public.invoices WHERE organization_id=_org AND (file_sha256=nullif(_payload->>'file_hash','') OR (public.normalize_vendor_name(vendor_name_extracted)=public.normalize_vendor_name(inv->>'vendor_name') AND invoice_number_normalized=public.normalize_invoice_number(inv->>'invoice_number'))) ORDER BY created_at LIMIT 1;
IF iid IS NOT NULL THEN dup := true; END IF;
IF iid IS NULL THEN
INSERT INTO public.invoices(organization_id,vendor_id,purchase_order_id,vendor_name_extracted,invoice_number,invoice_date,currency,subtotal_amount,tax_amount,total_amount,status,file_path,file_name,file_size_bytes,file_sha256,uploaded_by)
VALUES(_org,vid,pid,inv->>'vendor_name',inv->>'invoice_number',nullif(_payload->>'invoice_date','')::date,coalesce(nullif(inv->>'currency',''),'INR'),nullif(inv->>'taxable_amount','')::numeric,nullif(inv->>'tax_amount','')::numeric,nullif(inv->>'total_amount','')::numeric,CASE WHEN res->>'status'='Approved' THEN 'processing'::public.invoice_status ELSE replace(lower(res->>'status'),' ','_')::public.invoice_status END,_payload->>'file_path',_payload->>'filename',nullif(_payload->>'file_size','')::bigint,nullif(_payload->>'file_hash',''),_actor) RETURNING id INTO iid;
END IF;
IF dup AND legacy IS NULL AND res->>'status' <> 'Rejected' THEN RAISE EXCEPTION 'Duplicate must be rejected'; END IF;
INSERT INTO public.processing_runs(organization_id,invoice_id,status,engine_version,policy_snapshot,extracted_fields,raw_text,started_at,completed_at,created_by,result_snapshot,source_file_path,source_filename,source_file_sha256,legacy_record_id,legacy_created_at,extraction_metadata)
VALUES(_org,iid,'succeeded',CASE WHEN _payload->'extraction_metadata' IS NULL THEN 'cloud-v1' ELSE 'cloud-server-pdf-v1' END,_payload->'settings',inv,_payload->>'raw_text',stamp,stamp,_actor,res,_payload->>'file_path',_payload->>'filename',_payload->>'file_hash',legacy,nullif(_payload->>'legacy_created_at','')::timestamptz,_payload->'extraction_metadata') RETURNING id INTO rid;
IF res->>'status'='Approved' THEN
res:=jsonb_set(res,'{po_balance}',public.reserve_invoice_po(_org,iid,rid));
UPDATE public.processing_runs SET result_snapshot=res WHERE id=rid;
END IF;
INSERT INTO public.validation_results(organization_id,processing_run_id,invoice_id,recommendation,checks,reasons) VALUES(_org,rid,iid,replace(lower(res->>'status'),' ','_')::public.recommendation,res->'checks',res->'reasons');
INSERT INTO public.audit_events(organization_id,actor_id,entity_type,entity_id,action,details) VALUES(_org,_actor,'processing_run',rid,CASE WHEN legacy IS NULL THEN 'invoice_processed' ELSE 'legacy_imported' END,jsonb_build_object('invoice_id',iid,'recommendation',res->>'status','duplicate',dup,'legacy_record_id',legacy,'policy_snapshot',_payload->'settings','result',res,'extraction_metadata',_payload->'extraction_metadata'));
RETURN jsonb_build_object('id',rid,'created_at',stamp,'invoice_id',iid,'result',res);
END $$;