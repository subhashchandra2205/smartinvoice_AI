
REVOKE ALL ON public.profiles, public.organizations, public.organization_members, public.vendors,
  public.purchase_orders, public.invoices, public.processing_runs, public.validation_results, public.audit_events
  FROM anon;
REVOKE UPDATE, DELETE, TRUNCATE ON public.audit_events, public.validation_results FROM authenticated;
REVOKE DELETE, TRUNCATE ON public.processing_runs FROM authenticated;
REVOKE INSERT, DELETE, TRUNCATE ON public.profiles FROM authenticated;
REVOKE TRUNCATE, REFERENCES, TRIGGER ON public.organizations, public.organization_members, public.vendors,
  public.purchase_orders, public.invoices FROM authenticated;
REVOKE ALL ON FUNCTION public.storage_org_id(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.storage_org_id(text) TO authenticated, service_role;
