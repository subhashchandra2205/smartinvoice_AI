ALTER TABLE public.processing_runs ADD COLUMN result_snapshot jsonb, ADD COLUMN source_file_path text, ADD COLUMN source_filename text, ADD COLUMN source_file_sha256 text, ADD COLUMN legacy_record_id uuid, ADD COLUMN legacy_created_at timestamptz;
CREATE UNIQUE INDEX processing_runs_legacy_once ON public.processing_runs(organization_id,legacy_record_id) WHERE legacy_record_id IS NOT NULL;
CREATE INDEX processing_runs_org_time ON public.processing_runs(organization_id,created_at DESC);
CREATE OR REPLACE FUNCTION public.cloud_invoice_revision(_org uuid) RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$ SELECT md5(jsonb_build_array((SELECT coalesce(jsonb_agg(to_jsonb(p) ORDER BY p.id),'[]') FROM public.purchase_orders p WHERE p.organization_id=_org),(SELECT coalesce(jsonb_agg(to_jsonb(v) ORDER BY v.id),'[]') FROM public.vendors v WHERE v.organization_id=_org),(SELECT coalesce(jsonb_agg(to_jsonb(i) ORDER BY i.id),'[]') FROM public.invoices i WHERE i.organization_id=_org),(SELECT coalesce(jsonb_agg(to_jsonb(r) ORDER BY r.id),'[]') FROM public.processing_runs r WHERE r.organization_id=_org))::text) $$;
REVOKE ALL ON FUNCTION public.cloud_invoice_revision(uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.cloud_invoice_revision(uuid) TO service_role;
CREATE OR REPLACE FUNCTION public.get_cloud_invoice_state(_org uuid) RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$ BEGIN
IF auth.role() <> 'service_role' AND NOT public.is_org_member(_org,auth.uid()) THEN RAISE EXCEPTION 'Forbidden'; END IF;
RETURN jsonb_build_object('revision',public.cloud_invoice_revision(_org),'invoices',(SELECT coalesce(jsonb_agg(to_jsonb(i)),'[]') FROM public.invoices i WHERE i.organization_id=_org),'runs',(SELECT coalesce(jsonb_agg(to_jsonb(r) ORDER BY r.created_at DESC),'[]') FROM public.processing_runs r WHERE r.organization_id=_org),'vendors',(SELECT coalesce(jsonb_agg(to_jsonb(v)),'[]') FROM public.vendors v WHERE v.organization_id=_org),'purchase_orders',(SELECT coalesce(jsonb_agg(to_jsonb(p)),'[]') FROM public.purchase_orders p WHERE p.organization_id=_org)); END $$;
REVOKE ALL ON FUNCTION public.get_cloud_invoice_state(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.get_cloud_invoice_state(uuid) TO authenticated,service_role;
CREATE OR REPLACE FUNCTION public.commit_cloud_invoice(_org uuid,_actor uuid,_revision text,_payload jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE inv jsonb := _payload->'invoice'; res jsonb := _payload->'result'; vid uuid; pid uuid; iid uuid; rid uuid; legacy uuid := nullif(_payload->>'legacy_id','')::uuid; stamp timestamptz := now(); dup boolean := false;
BEGIN
IF auth.role() <> 'service_role' THEN RAISE EXCEPTION 'Forbidden'; END IF;
IF NOT EXISTS(SELECT 1 FROM public.organization_members WHERE organization_id=_org AND user_id=_actor AND role IN ('admin','finance_manager','invoice_processor')) THEN RAISE EXCEPTION 'Forbidden'; END IF;
PERFORM pg_advisory_xact_lock(hashtextextended(_org::text,0));
IF legacy IS NOT NULL THEN SELECT id INTO rid FROM public.processing_runs WHERE organization_id=_org AND legacy_record_id=legacy; IF rid IS NOT NULL THEN RETURN jsonb_build_object('id',rid,'already_imported',true); END IF; END IF;
IF public.cloud_invoice_revision(_org) <> _revision THEN RETURN jsonb_build_object('retry',true); END IF;
IF legacy IS NULL AND NOT EXISTS(SELECT 1 FROM storage.objects WHERE bucket_id='invoice-pdfs' AND name=_payload->>'file_path' AND name LIKE _org::text||'/%') THEN RAISE EXCEPTION 'Private PDF missing'; END IF;
SELECT id INTO vid FROM public.vendors WHERE organization_id=_org AND normalized_name=public.normalize_vendor_name(inv->>'vendor_name');
SELECT id INTO pid FROM public.purchase_orders WHERE organization_id=_org AND po_number=inv->>'po_number';
SELECT id INTO iid FROM public.invoices WHERE organization_id=_org AND (file_sha256=nullif(_payload->>'file_hash','') OR (public.normalize_vendor_name(vendor_name_extracted)=public.normalize_vendor_name(inv->>'vendor_name') AND invoice_number_normalized=public.normalize_invoice_number(inv->>'invoice_number'))) ORDER BY created_at LIMIT 1;
IF iid IS NOT NULL THEN dup := true; END IF;
IF iid IS NULL THEN
INSERT INTO public.invoices(organization_id,vendor_id,purchase_order_id,vendor_name_extracted,invoice_number,invoice_date,currency,subtotal_amount,tax_amount,total_amount,status,file_path,file_name,file_size_bytes,file_sha256,uploaded_by)
VALUES(_org,vid,pid,inv->>'vendor_name',inv->>'invoice_number',nullif(_payload->>'invoice_date','')::date,coalesce(inv->>'currency','INR'),nullif(inv->>'taxable_amount','')::numeric,nullif(inv->>'tax_amount','')::numeric,nullif(inv->>'total_amount','')::numeric,replace(lower(res->>'status'),' ','_')::public.invoice_status,_payload->>'file_path',_payload->>'filename',nullif(_payload->>'file_size','')::bigint,nullif(_payload->>'file_hash',''),_actor) RETURNING id INTO iid;
END IF;
IF dup AND legacy IS NULL AND res->>'status' <> 'Rejected' THEN RAISE EXCEPTION 'Duplicate must be rejected'; END IF;
INSERT INTO public.processing_runs(organization_id,invoice_id,status,engine_version,policy_snapshot,extracted_fields,raw_text,started_at,completed_at,created_by,result_snapshot,source_file_path,source_filename,source_file_sha256,legacy_record_id,legacy_created_at)
VALUES(_org,iid,'succeeded','cloud-v1',_payload->'settings',inv,_payload->>'raw_text',stamp,stamp,_actor,res,_payload->>'file_path',_payload->>'filename',_payload->>'file_hash',legacy,nullif(_payload->>'legacy_created_at','')::timestamptz) RETURNING id INTO rid;
INSERT INTO public.validation_results(organization_id,processing_run_id,invoice_id,recommendation,checks,reasons) VALUES(_org,rid,iid,replace(lower(res->>'status'),' ','_')::public.recommendation,res->'checks',res->'reasons');
INSERT INTO public.audit_events(organization_id,actor_id,entity_type,entity_id,action,details) VALUES(_org,_actor,'processing_run',rid,CASE WHEN legacy IS NULL THEN 'invoice_processed' ELSE 'legacy_imported' END,jsonb_build_object('invoice_id',iid,'recommendation',res->>'status','duplicate',dup,'legacy_record_id',legacy,'policy_snapshot',_payload->'settings','result',res));
RETURN jsonb_build_object('id',rid,'created_at',stamp,'invoice_id',iid);
END $$;
REVOKE ALL ON FUNCTION public.commit_cloud_invoice(uuid,uuid,text,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.commit_cloud_invoice(uuid,uuid,text,jsonb) TO service_role;
REVOKE INSERT,UPDATE,DELETE ON public.invoices FROM authenticated;
REVOKE INSERT,UPDATE ON public.processing_runs FROM authenticated;
REVOKE INSERT ON public.validation_results FROM authenticated;
COMMENT ON FUNCTION public.commit_cloud_invoice(uuid,uuid,text,jsonb) IS 'Server-only atomic decision commit. Caller authorizes using user RLS before privileged commit; organization revision serializes concurrent validations. Duplicate attempts append runs without overwriting the canonical invoice.';