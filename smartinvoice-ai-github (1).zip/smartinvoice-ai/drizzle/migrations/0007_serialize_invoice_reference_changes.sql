CREATE OR REPLACE FUNCTION public.lock_invoice_reference_org() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$ BEGIN PERFORM pg_advisory_xact_lock(hashtextextended(COALESCE(NEW.organization_id,OLD.organization_id)::text,0)); RETURN COALESCE(NEW,OLD); END $$;
REVOKE ALL ON FUNCTION public.lock_invoice_reference_org() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER vendors_invoice_serialization BEFORE INSERT OR UPDATE OR DELETE ON public.vendors FOR EACH ROW EXECUTE FUNCTION public.lock_invoice_reference_org();
CREATE TRIGGER purchase_orders_invoice_serialization BEFORE INSERT OR UPDATE OR DELETE ON public.purchase_orders FOR EACH ROW EXECUTE FUNCTION public.lock_invoice_reference_org();
ALTER TABLE public.processing_runs ADD COLUMN legacy_evidence jsonb;
COMMENT ON COLUMN public.processing_runs.legacy_evidence IS 'Untrusted original device record retained for comparison; never used as authoritative approval or PO consumption.';