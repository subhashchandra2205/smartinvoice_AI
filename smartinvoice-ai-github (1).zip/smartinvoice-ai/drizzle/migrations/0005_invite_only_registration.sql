CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  -- Invite-only: after the first organization exists, sign-up requires a live invitation.
  IF EXISTS (SELECT 1 FROM public.organizations) AND NOT EXISTS (
    SELECT 1 FROM public.organization_invitations i
    WHERE lower(i.email) = lower(NEW.email) AND i.accepted_at IS NULL
      AND i.revoked_at IS NULL AND i.expires_at > now()
  ) THEN
    RAISE EXCEPTION 'Sign-up is by invitation only' USING ERRCODE = '42501';
  END IF;
  INSERT INTO public.profiles(id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.can_create_organization()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT NOT EXISTS (SELECT 1 FROM public.organizations)
      OR EXISTS (SELECT 1 FROM public.organization_members WHERE user_id = auth.uid() AND role = 'admin');
$$;
REVOKE ALL ON FUNCTION public.can_create_organization() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_create_organization() TO authenticated;

DROP POLICY IF EXISTS "Signed-in users create organization" ON public.organizations;
CREATE POLICY "First admin or existing admins create organization" ON public.organizations
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND public.can_create_organization());