ALTER TABLE public.invoices ADD COLUMN approved_taxable_amount numeric(14,2);
UPDATE public.invoices i SET approved_taxable_amount=coalesce(i.subtotal_amount,(SELECT coalesce(nullif(r.result_snapshot#>>'{po_balance,current_taxable}','')::numeric,nullif(r.result_snapshot#>>'{gst_validation,taxable_amount}','')::numeric) FROM public.processing_runs r WHERE r.invoice_id=i.id AND r.organization_id=i.organization_id AND r.result_snapshot->>'status'='Approved' ORDER BY r.created_at LIMIT 1)) WHERE i.status='approved';
CREATE INDEX invoices_approved_po_spend ON public.invoices(organization_id,purchase_order_id) WHERE status='approved';
CREATE OR REPLACE FUNCTION public.reserve_invoice_po(_org uuid,_invoice uuid,_run uuid) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE i public.invoices; p public.purchase_orders; r public.processing_runs; spend numeric; current_amount numeric; tolerance numeric; allowed numeric;
BEGIN
PERFORM pg_advisory_xact_lock(hashtextextended(_org::text,0));
SELECT * INTO i FROM public.invoices WHERE id=_invoice AND organization_id=_org;
IF NOT FOUND THEN RAISE EXCEPTION 'Invoice not found in this organization'; END IF;
SELECT * INTO p FROM public.purchase_orders WHERE id=i.purchase_order_id AND organization_id=_org FOR UPDATE;
IF NOT FOUND THEN RAISE EXCEPTION 'Purchase order not found in this organization'; END IF;
SELECT * INTO i FROM public.invoices WHERE id=_invoice AND organization_id=_org FOR UPDATE;
SELECT * INTO r FROM public.processing_runs WHERE id=_run AND invoice_id=i.id AND organization_id=_org;
IF NOT FOUND THEN RAISE EXCEPTION 'Invoice run not found in this organization'; END IF;
IF i.status='approved' THEN RAISE EXCEPTION 'Invoice is already approved; duplicate approval is not allowed'; END IF;
IF i.status='rejected' OR r.result_snapshot->>'status'='Rejected' OR r.legacy_record_id IS NOT NULL OR r.source_file_sha256 IS DISTINCT FROM i.file_sha256 THEN RAISE EXCEPTION 'Rejected, duplicate or unverified legacy invoices cannot be approved'; END IF;
IF i.vendor_id IS NULL OR i.vendor_id<>p.vendor_id OR NOT EXISTS(SELECT 1 FROM public.vendors v WHERE v.id=i.vendor_id AND v.organization_id=_org AND v.status='active' AND v.normalized_name=public.normalize_vendor_name(i.vendor_name_extracted)) THEN RAISE EXCEPTION 'Invoice vendor does not match the active PO vendor'; END IF;
IF p.status<>'open' THEN RAISE EXCEPTION 'Only open purchase orders can receive approvals'; END IF;
IF i.currency<>p.currency THEN RAISE EXCEPTION 'Invoice and PO currencies do not match'; END IF;
tolerance := (r.policy_snapshot->>'tolerance')::numeric;
IF tolerance IS NULL OR tolerance<0 OR tolerance>10 THEN RAISE EXCEPTION 'Saved PO tolerance is invalid'; END IF;
current_amount := coalesce(i.subtotal_amount,nullif(r.result_snapshot#>>'{po_balance,current_taxable}','')::numeric,nullif(r.result_snapshot#>>'{gst_validation,taxable_amount}','')::numeric);
IF current_amount IS NULL OR current_amount<=0 OR i.total_amount IS NULL OR i.total_amount<=0 THEN RAISE EXCEPTION 'Invoice taxable amount must be verified and positive'; END IF;
SELECT coalesce(sum(approved_taxable_amount),0) INTO spend FROM public.invoices WHERE organization_id=_org AND purchase_order_id=p.id AND status='approved';
IF EXISTS(SELECT 1 FROM public.invoices WHERE organization_id=_org AND purchase_order_id=p.id AND status='approved' AND approved_taxable_amount IS NULL) THEN RAISE EXCEPTION 'Historical approved spending requires reconciliation'; END IF;
allowed:=round(p.amount*(1+tolerance/100),2);
IF spend+current_amount>allowed THEN RAISE EXCEPTION 'PO balance exceeded: approved %, invoice %, allowance % (% percent tolerance)',spend,current_amount,allowed,tolerance; END IF;
UPDATE public.invoices SET status='approved',approved_taxable_amount=current_amount WHERE id=i.id AND organization_id=_org;
RETURN jsonb_build_object('previously_approved',spend,'current_taxable',current_amount,'remaining_before',p.amount-spend,'remaining_after',p.amount-spend-current_amount,'allowed_total',allowed);
END $$;
REVOKE ALL ON FUNCTION public.reserve_invoice_po(uuid,uuid,uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.reserve_invoice_po(uuid,uuid,uuid) TO service_role;
CREATE OR REPLACE FUNCTION public.approve_invoice(_org uuid,_run uuid,_note text) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE r public.processing_runs; balance jsonb; result jsonb; new_run uuid; actor uuid:=auth.uid();
BEGIN
IF actor IS NULL OR NOT public.has_org_role(_org,actor,ARRAY['admin','finance_manager','reviewer']::public.app_role[]) THEN RAISE EXCEPTION 'Only admins, finance managers and reviewers can approve invoices'; END IF;
IF length(btrim(coalesce(_note,'')))<3 OR length(_note)>2000 THEN RAISE EXCEPTION 'Provide an approval note between 3 and 2000 characters'; END IF;
PERFORM pg_advisory_xact_lock(hashtextextended(_org::text,0));
SELECT * INTO r FROM public.processing_runs WHERE id=_run AND organization_id=_org;
IF NOT FOUND THEN RAISE EXCEPTION 'Invoice run not found in this organization'; END IF;
IF r.result_snapshot->>'status'<>'Needs Review' THEN RAISE EXCEPTION 'Only review-pending invoices can be manually approved'; END IF;
balance:=public.reserve_invoice_po(_org,r.invoice_id,r.id);
result:=jsonb_set(jsonb_set(r.result_snapshot,'{status}','"Approved"'),'{po_balance}',balance);
result:=jsonb_set(result,'{checks}',coalesce(result->'checks','[]')||jsonb_build_array('Human approval: '||btrim(_note),'PO balance recalculated under transaction lock.'));
INSERT INTO public.processing_runs(organization_id,invoice_id,status,engine_version,policy_snapshot,extracted_fields,raw_text,started_at,completed_at,created_by,result_snapshot,source_file_path,source_filename,source_file_sha256) VALUES(_org,r.invoice_id,'succeeded','human-approval-v1',r.policy_snapshot,r.extracted_fields,r.raw_text,now(),now(),actor,result,r.source_file_path,r.source_filename,r.source_file_sha256) RETURNING id INTO new_run;
INSERT INTO public.validation_results(organization_id,processing_run_id,invoice_id,recommendation,checks,reasons) VALUES(_org,new_run,r.invoice_id,'approved',result->'checks',result->'reasons');
INSERT INTO public.audit_events(organization_id,actor_id,entity_type,entity_id,action,details) VALUES(_org,actor,'processing_run',new_run,'invoice_approved',jsonb_build_object('invoice_id',r.invoice_id,'source_run_id',r.id,'note',btrim(_note),'po_balance',balance,'policy_snapshot',r.policy_snapshot));
RETURN jsonb_build_object('id',new_run,'invoice_id',r.invoice_id,'po_balance',balance);
END $$;
REVOKE ALL ON FUNCTION public.approve_invoice(uuid,uuid,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.approve_invoice(uuid,uuid,text) TO authenticated;
CREATE OR REPLACE FUNCTION public.protect_approved_invoice() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
IF OLD.status='approved' AND (NEW.status IS DISTINCT FROM OLD.status OR NEW.approved_taxable_amount IS DISTINCT FROM OLD.approved_taxable_amount OR NEW.subtotal_amount IS DISTINCT FROM OLD.subtotal_amount OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.total_amount IS DISTINCT FROM OLD.total_amount OR NEW.purchase_order_id IS DISTINCT FROM OLD.purchase_order_id OR NEW.vendor_id IS DISTINCT FROM OLD.vendor_id OR NEW.currency IS DISTINCT FROM OLD.currency) THEN RAISE EXCEPTION 'Approved invoice amounts and balance allocations are immutable'; END IF;
RETURN NEW;
END $$;
CREATE TRIGGER invoices_protect_approved BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.protect_approved_invoice();