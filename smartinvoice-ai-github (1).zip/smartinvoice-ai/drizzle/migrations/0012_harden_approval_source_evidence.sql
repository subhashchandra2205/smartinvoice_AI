CREATE OR REPLACE FUNCTION public.validate_approval_source() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
IF NEW.status='approved' AND OLD.status<>'approved' THEN
IF NEW.file_sha256 IS NULL OR NEW.invoice_number IS NULL OR NEW.invoice_date IS NULL THEN RAISE EXCEPTION 'A verified PDF, invoice number and date are required for approval'; END IF;
END IF;
RETURN NEW;
END $$;
CREATE TRIGGER invoices_validate_approval_source BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.validate_approval_source();