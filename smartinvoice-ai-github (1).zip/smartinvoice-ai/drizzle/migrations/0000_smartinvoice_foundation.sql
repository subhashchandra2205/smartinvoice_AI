
-- ===== Enums =====
CREATE TYPE public.app_role AS ENUM ('admin','finance_manager','invoice_processor','reviewer','read_only');
CREATE TYPE public.po_status AS ENUM ('open','closed','cancelled');
CREATE TYPE public.invoice_status AS ENUM ('received','processing','approved','needs_review','rejected');
CREATE TYPE public.run_status AS ENUM ('queued','running','succeeded','failed');
CREATE TYPE public.recommendation AS ENUM ('approved','needs_review','rejected');

-- ===== Helper functions =====
CREATE OR REPLACE FUNCTION public.normalize_vendor_name(_name text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE SET search_path = public AS $$
  SELECT nullif(regexp_replace(
    regexp_replace(lower(coalesce(_name,'')),
      '\m(pvt|private|ltd|limited|llp|llc|inc|co|company|corp|corporation|the)\M', '', 'g'),
    '[^a-z0-9]', '', 'g'), '')
$$;

CREATE OR REPLACE FUNCTION public.normalize_invoice_number(_num text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE SET search_path = public AS $$
  SELECT nullif(regexp_replace(upper(coalesce(_num,'')), '[^A-Z0-9]', '', 'g'), '')
$$;

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END $$;

CREATE OR REPLACE FUNCTION public.prevent_org_change()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.organization_id IS DISTINCT FROM OLD.organization_id THEN
    RAISE EXCEPTION 'organization_id cannot be changed';
  END IF;
  RETURN NEW;
END $$;

-- ===== profiles =====
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  full_name text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ===== organizations =====
CREATE TABLE public.organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 200),
  created_by uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organizations TO authenticated;
GRANT ALL ON public.organizations TO service_role;
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER organizations_updated_at BEFORE UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ===== organization_members =====
CREATE TABLE public.organization_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role public.app_role NOT NULL DEFAULT 'read_only',
  invited_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, user_id)
);
CREATE INDEX organization_members_user_idx ON public.organization_members(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organization_members TO authenticated;
GRANT ALL ON public.organization_members TO service_role;
ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER organization_members_updated_at BEFORE UPDATE ON public.organization_members FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER organization_members_org_lock BEFORE UPDATE ON public.organization_members FOR EACH ROW EXECUTE FUNCTION public.prevent_org_change();

-- Security-definer role checks (bypass RLS, avoid recursion)
CREATE OR REPLACE FUNCTION public.is_org_member(_org uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.organization_members WHERE organization_id = _org AND user_id = _user)
$$;

CREATE OR REPLACE FUNCTION public.has_org_role(_org uuid, _user uuid, _roles public.app_role[])
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.organization_members
                 WHERE organization_id = _org AND user_id = _user AND role = ANY(_roles))
$$;

CREATE OR REPLACE FUNCTION public.shares_org_with(_other uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.organization_members a
                 JOIN public.organization_members b ON a.organization_id = b.organization_id
                 WHERE a.user_id = _user AND b.user_id = _other)
$$;

REVOKE ALL ON FUNCTION public.is_org_member(uuid, uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.has_org_role(uuid, uuid, public.app_role[]) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.shares_org_with(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_org_member(uuid, uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_org_role(uuid, uuid, public.app_role[]) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.shares_org_with(uuid, uuid) TO authenticated, service_role;

-- Membership guard: no self-role changes, no removing the last admin
CREATE OR REPLACE FUNCTION public.guard_membership()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE remaining int;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN COALESCE(NEW, OLD); -- service role / internal bootstrap
  END IF;
  IF TG_OP = 'INSERT' AND NEW.user_id = auth.uid() THEN
    RAISE EXCEPTION 'You cannot add yourself to an organization';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF OLD.user_id = auth.uid() AND NEW.role IS DISTINCT FROM OLD.role THEN
      RAISE EXCEPTION 'You cannot change your own role';
    END IF;
    IF NEW.user_id IS DISTINCT FROM OLD.user_id THEN
      RAISE EXCEPTION 'user_id cannot be changed';
    END IF;
  END IF;
  IF (TG_OP = 'DELETE' AND OLD.role = 'admin')
     OR (TG_OP = 'UPDATE' AND OLD.role = 'admin' AND NEW.role <> 'admin') THEN
    SELECT count(*) INTO remaining FROM public.organization_members
      WHERE organization_id = OLD.organization_id AND role = 'admin' AND id <> OLD.id;
    IF remaining = 0 THEN
      RAISE EXCEPTION 'An organization must keep at least one admin';
    END IF;
  END IF;
  IF TG_OP = 'INSERT' THEN NEW.invited_by := auth.uid(); END IF;
  RETURN COALESCE(NEW, OLD);
END $$;
CREATE TRIGGER organization_members_guard BEFORE INSERT OR UPDATE OR DELETE ON public.organization_members
  FOR EACH ROW EXECUTE FUNCTION public.guard_membership();

-- Bootstrap: creator becomes admin
CREATE OR REPLACE FUNCTION public.add_org_creator_as_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM set_config('request.jwt.claim.sub', '', true);
  INSERT INTO public.organization_members(organization_id, user_id, role)
  VALUES (NEW.id, NEW.created_by, 'admin');
  RETURN NEW;
END $$;
CREATE TRIGGER organizations_bootstrap_admin AFTER INSERT ON public.organizations
  FOR EACH ROW EXECUTE FUNCTION public.add_org_creator_as_admin();

-- Force created_by to caller
CREATE OR REPLACE FUNCTION public.force_org_creator()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL THEN NEW.created_by := auth.uid(); END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER organizations_force_creator BEFORE INSERT ON public.organizations
  FOR EACH ROW EXECUTE FUNCTION public.force_org_creator();

-- Profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles(id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.add_org_creator_as_admin() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.guard_membership() FROM PUBLIC, anon, authenticated;

-- ===== vendors =====
CREATE TABLE public.vendors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 300),
  normalized_name text GENERATED ALWAYS AS (public.normalize_vendor_name(name)) STORED,
  gstin text CHECK (gstin IS NULL OR gstin ~ '^[0-9]{2}[A-Z0-9]{13}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, id),
  UNIQUE (organization_id, normalized_name)
);
CREATE UNIQUE INDEX vendors_org_gstin_uq ON public.vendors(organization_id, gstin) WHERE gstin IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vendors TO authenticated;
GRANT ALL ON public.vendors TO service_role;
ALTER TABLE public.vendors ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER vendors_updated_at BEFORE UPDATE ON public.vendors FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER vendors_org_lock BEFORE UPDATE ON public.vendors FOR EACH ROW EXECUTE FUNCTION public.prevent_org_change();

-- ===== purchase_orders =====
CREATE TABLE public.purchase_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  vendor_id uuid NOT NULL,
  po_number text NOT NULL CHECK (length(trim(po_number)) BETWEEN 1 AND 100),
  status public.po_status NOT NULL DEFAULT 'open',
  currency char(3) NOT NULL DEFAULT 'INR' CHECK (currency ~ '^[A-Z]{3}$'),
  amount numeric(14,2) NOT NULL CHECK (amount >= 0),
  issued_on date,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, id),
  UNIQUE (organization_id, po_number),
  FOREIGN KEY (organization_id, vendor_id) REFERENCES public.vendors(organization_id, id) ON DELETE RESTRICT
);
CREATE INDEX purchase_orders_vendor_idx ON public.purchase_orders(organization_id, vendor_id);
CREATE INDEX purchase_orders_status_idx ON public.purchase_orders(organization_id, status);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.purchase_orders TO authenticated;
GRANT ALL ON public.purchase_orders TO service_role;
ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER purchase_orders_updated_at BEFORE UPDATE ON public.purchase_orders FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER purchase_orders_org_lock BEFORE UPDATE ON public.purchase_orders FOR EACH ROW EXECUTE FUNCTION public.prevent_org_change();

-- ===== invoices =====
CREATE TABLE public.invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  vendor_id uuid,
  purchase_order_id uuid,
  vendor_name_extracted text,
  vendor_identity text GENERATED ALWAYS AS (
    COALESCE('v:' || vendor_id::text, 'n:' || public.normalize_vendor_name(vendor_name_extracted))
  ) STORED,
  invoice_number text,
  invoice_number_normalized text GENERATED ALWAYS AS (public.normalize_invoice_number(invoice_number)) STORED,
  invoice_date date,
  currency char(3) NOT NULL DEFAULT 'INR' CHECK (currency ~ '^[A-Z]{3}$'),
  subtotal_amount numeric(14,2) CHECK (subtotal_amount >= 0),
  tax_amount numeric(14,2) CHECK (tax_amount >= 0),
  total_amount numeric(14,2) CHECK (total_amount >= 0),
  status public.invoice_status NOT NULL DEFAULT 'received',
  file_path text,
  file_name text,
  file_size_bytes bigint CHECK (file_size_bytes IS NULL OR file_size_bytes BETWEEN 1 AND 20971520),
  file_sha256 text CHECK (file_sha256 IS NULL OR file_sha256 ~ '^[0-9a-f]{64}$'),
  uploaded_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, id),
  FOREIGN KEY (organization_id, vendor_id) REFERENCES public.vendors(organization_id, id) ON DELETE RESTRICT,
  FOREIGN KEY (organization_id, purchase_order_id) REFERENCES public.purchase_orders(organization_id, id) ON DELETE RESTRICT,
  CHECK (file_path IS NULL OR file_path LIKE organization_id::text || '/%')
);
-- Invoice identity within an organization (normalized vendor + normalized number)
CREATE UNIQUE INDEX invoices_identity_uq ON public.invoices(organization_id, vendor_identity, invoice_number_normalized)
  WHERE vendor_identity IS NOT NULL AND invoice_number_normalized IS NOT NULL;
CREATE UNIQUE INDEX invoices_file_hash_uq ON public.invoices(organization_id, file_sha256) WHERE file_sha256 IS NOT NULL;
CREATE INDEX invoices_status_idx ON public.invoices(organization_id, status, created_at DESC);
CREATE INDEX invoices_po_idx ON public.invoices(organization_id, purchase_order_id);
CREATE INDEX invoices_vendor_idx ON public.invoices(organization_id, vendor_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.invoices TO authenticated;
GRANT ALL ON public.invoices TO service_role;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER invoices_org_lock BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.prevent_org_change();

-- ===== processing_runs =====
CREATE TABLE public.processing_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  invoice_id uuid NOT NULL,
  status public.run_status NOT NULL DEFAULT 'queued',
  engine_version text NOT NULL DEFAULT 'v1',
  policy_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  extracted_fields jsonb NOT NULL DEFAULT '{}'::jsonb,
  raw_text text,
  error_message text,
  started_at timestamptz,
  completed_at timestamptz,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, id),
  FOREIGN KEY (organization_id, invoice_id) REFERENCES public.invoices(organization_id, id) ON DELETE CASCADE
);
CREATE INDEX processing_runs_invoice_idx ON public.processing_runs(organization_id, invoice_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE ON public.processing_runs TO authenticated;
GRANT ALL ON public.processing_runs TO service_role;
ALTER TABLE public.processing_runs ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER processing_runs_org_lock BEFORE UPDATE ON public.processing_runs FOR EACH ROW EXECUTE FUNCTION public.prevent_org_change();

-- ===== validation_results (immutable once written) =====
CREATE TABLE public.validation_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  processing_run_id uuid NOT NULL,
  invoice_id uuid NOT NULL,
  recommendation public.recommendation NOT NULL,
  checks jsonb NOT NULL DEFAULT '[]'::jsonb,
  reasons jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (processing_run_id),
  FOREIGN KEY (organization_id, processing_run_id) REFERENCES public.processing_runs(organization_id, id) ON DELETE CASCADE,
  FOREIGN KEY (organization_id, invoice_id) REFERENCES public.invoices(organization_id, id) ON DELETE CASCADE
);
CREATE INDEX validation_results_invoice_idx ON public.validation_results(organization_id, invoice_id, created_at DESC);
GRANT SELECT, INSERT ON public.validation_results TO authenticated;
GRANT ALL ON public.validation_results TO service_role;
ALTER TABLE public.validation_results ENABLE ROW LEVEL SECURITY;

-- ===== audit_events (append-only) =====
CREATE TABLE public.audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  entity_type text NOT NULL CHECK (length(entity_type) BETWEEN 1 AND 64),
  entity_id uuid,
  action text NOT NULL CHECK (length(action) BETWEEN 1 AND 64),
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_events_org_time_idx ON public.audit_events(organization_id, created_at DESC);
CREATE INDEX audit_events_entity_idx ON public.audit_events(organization_id, entity_type, entity_id);
GRANT SELECT, INSERT ON public.audit_events TO authenticated;
GRANT ALL ON public.audit_events TO service_role;
ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.audit_stamp()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL THEN
    NEW.actor_id := auth.uid();
    NEW.created_at := now();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER audit_events_stamp BEFORE INSERT ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.audit_stamp();

CREATE OR REPLACE FUNCTION public.block_mutation()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL THEN
    RAISE EXCEPTION '% is append-only', TG_TABLE_NAME;
  END IF;
  RETURN COALESCE(NEW, OLD);
END $$;
CREATE TRIGGER audit_events_immutable BEFORE UPDATE OR DELETE ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.block_mutation();
CREATE TRIGGER validation_results_immutable BEFORE UPDATE OR DELETE ON public.validation_results FOR EACH ROW EXECUTE FUNCTION public.block_mutation();

-- ===== RLS policies =====
-- profiles
CREATE POLICY "Read own or co-member profiles" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.shares_org_with(id, auth.uid()));
CREATE POLICY "Update own profile" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- organizations
CREATE POLICY "Members read organization" ON public.organizations FOR SELECT TO authenticated
  USING (public.is_org_member(id, auth.uid()) OR created_by = auth.uid());
CREATE POLICY "Signed-in users create organization" ON public.organizations FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid());
CREATE POLICY "Admins update organization" ON public.organizations FOR UPDATE TO authenticated
  USING (public.has_org_role(id, auth.uid(), ARRAY['admin']::public.app_role[]))
  WITH CHECK (public.has_org_role(id, auth.uid(), ARRAY['admin']::public.app_role[]));
CREATE POLICY "Admins delete organization" ON public.organizations FOR DELETE TO authenticated
  USING (public.has_org_role(id, auth.uid(), ARRAY['admin']::public.app_role[]));

-- organization_members
CREATE POLICY "Members read memberships" ON public.organization_members FOR SELECT TO authenticated
  USING (public.is_org_member(organization_id, auth.uid()));
CREATE POLICY "Admins add members" ON public.organization_members FOR INSERT TO authenticated
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin']::public.app_role[]));
CREATE POLICY "Admins change members" ON public.organization_members FOR UPDATE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin']::public.app_role[]))
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin']::public.app_role[]));
CREATE POLICY "Admins remove members or self leave" ON public.organization_members FOR DELETE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin']::public.app_role[]) OR user_id = auth.uid());

-- vendors
CREATE POLICY "Members read vendors" ON public.vendors FOR SELECT TO authenticated
  USING (public.is_org_member(organization_id, auth.uid()));
CREATE POLICY "Finance writes vendors" ON public.vendors FOR INSERT TO authenticated
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager']::public.app_role[]));
CREATE POLICY "Finance updates vendors" ON public.vendors FOR UPDATE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager']::public.app_role[]))
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager']::public.app_role[]));
CREATE POLICY "Admins delete vendors" ON public.vendors FOR DELETE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin']::public.app_role[]));

-- purchase_orders
CREATE POLICY "Members read POs" ON public.purchase_orders FOR SELECT TO authenticated
  USING (public.is_org_member(organization_id, auth.uid()));
CREATE POLICY "Finance creates POs" ON public.purchase_orders FOR INSERT TO authenticated
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager']::public.app_role[]));
CREATE POLICY "Finance updates POs" ON public.purchase_orders FOR UPDATE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager']::public.app_role[]))
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager']::public.app_role[]));
CREATE POLICY "Admins delete POs" ON public.purchase_orders FOR DELETE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin']::public.app_role[]));

-- invoices
CREATE POLICY "Members read invoices" ON public.invoices FOR SELECT TO authenticated
  USING (public.is_org_member(organization_id, auth.uid()));
CREATE POLICY "Processors create invoices" ON public.invoices FOR INSERT TO authenticated
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager','invoice_processor']::public.app_role[]));
CREATE POLICY "Processors and reviewers update invoices" ON public.invoices FOR UPDATE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager','invoice_processor','reviewer']::public.app_role[]))
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager','invoice_processor','reviewer']::public.app_role[]));
CREATE POLICY "Admins delete invoices" ON public.invoices FOR DELETE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin']::public.app_role[]));

-- processing_runs
CREATE POLICY "Members read runs" ON public.processing_runs FOR SELECT TO authenticated
  USING (public.is_org_member(organization_id, auth.uid()));
CREATE POLICY "Processors create runs" ON public.processing_runs FOR INSERT TO authenticated
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager','invoice_processor']::public.app_role[]));
CREATE POLICY "Processors update runs" ON public.processing_runs FOR UPDATE TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager','invoice_processor']::public.app_role[]))
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager','invoice_processor']::public.app_role[]));

-- validation_results
CREATE POLICY "Members read validation results" ON public.validation_results FOR SELECT TO authenticated
  USING (public.is_org_member(organization_id, auth.uid()));
CREATE POLICY "Processors write validation results" ON public.validation_results FOR INSERT TO authenticated
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager','invoice_processor']::public.app_role[]));

-- audit_events
CREATE POLICY "Members read audit events" ON public.audit_events FOR SELECT TO authenticated
  USING (public.is_org_member(organization_id, auth.uid()));
CREATE POLICY "Active members append audit events" ON public.audit_events FOR INSERT TO authenticated
  WITH CHECK (public.has_org_role(organization_id, auth.uid(), ARRAY['admin','finance_manager','invoice_processor','reviewer']::public.app_role[]));

-- ===== Storage: private invoice PDFs, path = <organization_id>/<file> =====
CREATE OR REPLACE FUNCTION public.storage_org_id(_name text)
RETURNS uuid LANGUAGE plpgsql IMMUTABLE SET search_path = public AS $$
BEGIN
  RETURN split_part(_name, '/', 1)::uuid;
EXCEPTION WHEN others THEN RETURN NULL;
END $$;

CREATE POLICY "Members read invoice PDFs" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'invoice-pdfs' AND public.is_org_member(public.storage_org_id(name), auth.uid()));
CREATE POLICY "Processors upload invoice PDFs" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'invoice-pdfs'
    AND lower(storage.extension(name)) = 'pdf'
    AND public.has_org_role(public.storage_org_id(name), auth.uid(), ARRAY['admin','finance_manager','invoice_processor']::public.app_role[]));
CREATE POLICY "Admins delete invoice PDFs" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'invoice-pdfs' AND public.has_org_role(public.storage_org_id(name), auth.uid(), ARRAY['admin']::public.app_role[]));
