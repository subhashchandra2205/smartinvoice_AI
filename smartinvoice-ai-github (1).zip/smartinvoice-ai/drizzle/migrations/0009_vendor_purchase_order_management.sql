ALTER TABLE public.vendors ADD COLUMN email text, ADD COLUMN phone text, ADD COLUMN address text, ADD COLUMN status text NOT NULL DEFAULT 'active';
ALTER TABLE public.vendors ADD CONSTRAINT vendors_status_valid CHECK (status IN ('active','inactive'));
ALTER TABLE public.purchase_orders ADD COLUMN delivery_date date, ADD COLUMN description text;
CREATE UNIQUE INDEX purchase_orders_normalized_number_uq ON public.purchase_orders (organization_id, upper(btrim(po_number)));
CREATE OR REPLACE FUNCTION public.validate_reference_record() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
IF TG_TABLE_NAME='vendors' THEN
 NEW.name := btrim(NEW.name); NEW.gstin := nullif(upper(btrim(NEW.gstin)),''); NEW.email := nullif(btrim(NEW.email),''); NEW.phone := nullif(btrim(NEW.phone),''); NEW.address := nullif(btrim(NEW.address),'');
 IF length(NEW.name)<2 OR length(NEW.name)>200 OR public.normalize_vendor_name(NEW.name)='' THEN RAISE EXCEPTION 'Vendor name is invalid'; END IF;
 IF NEW.gstin IS NOT NULL AND NEW.gstin !~ '^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$' THEN RAISE EXCEPTION 'GSTIN is invalid'; END IF;
 IF length(NEW.email)>254 OR (NEW.email IS NOT NULL AND NEW.email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$') OR length(NEW.phone)>30 OR length(NEW.address)>2000 THEN RAISE EXCEPTION 'Contact details are invalid'; END IF;
ELSE
 NEW.po_number := upper(btrim(NEW.po_number)); NEW.currency := upper(btrim(NEW.currency));
 IF length(NEW.po_number)<2 OR length(NEW.po_number)>100 OR NEW.amount<=0 OR NEW.currency !~ '^[A-Z]{3}$' THEN RAISE EXCEPTION 'PO reference, amount or currency is invalid'; END IF;
 IF NEW.delivery_date IS NOT NULL AND NEW.issued_on IS NOT NULL AND NEW.delivery_date<NEW.issued_on THEN RAISE EXCEPTION 'Delivery date cannot precede PO date'; END IF;
 IF length(NEW.description)>4000 THEN RAISE EXCEPTION 'Description is too long'; END IF;
 IF TG_OP='UPDATE' AND (NEW.po_number IS DISTINCT FROM OLD.po_number OR NEW.vendor_id IS DISTINCT FROM OLD.vendor_id OR NEW.currency IS DISTINCT FROM OLD.currency) AND EXISTS(SELECT 1 FROM public.invoices WHERE organization_id=OLD.organization_id AND purchase_order_id=OLD.id) THEN RAISE EXCEPTION 'PO number, vendor and currency are locked after invoice processing'; END IF;
END IF;
RETURN NEW;
END $$;
CREATE TRIGGER vendors_validate BEFORE INSERT OR UPDATE ON public.vendors FOR EACH ROW EXECUTE FUNCTION public.validate_reference_record();
CREATE TRIGGER purchase_orders_validate BEFORE INSERT OR UPDATE ON public.purchase_orders FOR EACH ROW EXECUTE FUNCTION public.validate_reference_record();
CREATE OR REPLACE FUNCTION public.audit_reference_record() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
INSERT INTO public.audit_events(organization_id,actor_id,entity_type,entity_id,action,details) VALUES(NEW.organization_id,auth.uid(),TG_TABLE_NAME,NEW.id,lower(TG_OP),jsonb_build_object('before',CASE WHEN TG_OP='UPDATE' THEN to_jsonb(OLD) ELSE NULL END,'after',to_jsonb(NEW)));
RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.audit_reference_record() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER vendors_audit AFTER INSERT OR UPDATE ON public.vendors FOR EACH ROW EXECUTE FUNCTION public.audit_reference_record();
CREATE TRIGGER purchase_orders_audit AFTER INSERT OR UPDATE ON public.purchase_orders FOR EACH ROW EXECUTE FUNCTION public.audit_reference_record();