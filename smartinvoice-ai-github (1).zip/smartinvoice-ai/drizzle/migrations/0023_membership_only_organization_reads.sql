ALTER POLICY "Members read organization" ON public.organizations USING (public.is_org_member(id, auth.uid()));
CREATE OR REPLACE FUNCTION public.create_organization(_name text) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $function$
DECLARE org_id uuid; actor uuid := auth.uid();
BEGIN
 IF actor IS NULL OR NOT public.can_create_organization() THEN RAISE EXCEPTION 'Only an existing administrator or the first user can create an organization'; END IF;
 IF length(btrim(coalesce(_name,''))) NOT BETWEEN 2 AND 200 THEN RAISE EXCEPTION 'Organization name must be between 2 and 200 characters'; END IF;
 INSERT INTO public.organizations(name, created_by) VALUES (btrim(_name), actor) RETURNING id INTO org_id;
 IF NOT public.has_org_role(org_id, actor, ARRAY['admin']::public.app_role[]) THEN RAISE EXCEPTION 'Organization administrator was not created'; END IF;
 RETURN org_id;
END $function$;
REVOKE ALL ON FUNCTION public.create_organization(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_organization(text) TO authenticated, service_role;