ALTER TABLE public.processing_runs ADD COLUMN extraction_metadata jsonb;
DROP POLICY "Processors upload invoice PDFs" ON storage.objects;
COMMENT ON COLUMN public.processing_runs.extraction_metadata IS 'Server PDF extractor provenance, page counts and OCR-required page evidence; null for pre-verification and legacy runs.';