
CREATE OR REPLACE FUNCTION public.add_org_creator_as_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM set_config('smartinvoice.bootstrap', 'on', true);
  INSERT INTO public.organization_members(organization_id, user_id, role)
  VALUES (NEW.id, NEW.created_by, 'admin');
  PERFORM set_config('smartinvoice.bootstrap', 'off', true);
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.guard_membership()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE remaining int;
BEGIN
  IF auth.uid() IS NULL THEN RETURN COALESCE(NEW, OLD); END IF;
  IF TG_OP = 'INSERT' AND coalesce(current_setting('smartinvoice.bootstrap', true), 'off') = 'on' THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'INSERT' AND NEW.user_id = auth.uid() THEN
    RAISE EXCEPTION 'You cannot add yourself to an organization';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF OLD.user_id = auth.uid() AND NEW.role IS DISTINCT FROM OLD.role THEN
      RAISE EXCEPTION 'You cannot change your own role';
    END IF;
    IF NEW.user_id IS DISTINCT FROM OLD.user_id THEN
      RAISE EXCEPTION 'user_id cannot be changed';
    END IF;
  END IF;
  IF (TG_OP = 'DELETE' AND OLD.role = 'admin')
     OR (TG_OP = 'UPDATE' AND OLD.role = 'admin' AND NEW.role <> 'admin') THEN
    SELECT count(*) INTO remaining FROM public.organization_members
      WHERE organization_id = OLD.organization_id AND role = 'admin' AND id <> OLD.id;
    IF remaining = 0 THEN RAISE EXCEPTION 'An organization must keep at least one admin'; END IF;
  END IF;
  IF TG_OP = 'INSERT' THEN NEW.invited_by := auth.uid(); END IF;
  RETURN COALESCE(NEW, OLD);
END $$;
