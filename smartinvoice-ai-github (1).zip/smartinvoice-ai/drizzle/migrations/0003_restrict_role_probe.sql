
CREATE OR REPLACE FUNCTION public.is_org_member(_org uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT (auth.uid() IS NULL OR _user = auth.uid())
     AND EXISTS (SELECT 1 FROM public.organization_members WHERE organization_id = _org AND user_id = _user)
$$;
CREATE OR REPLACE FUNCTION public.has_org_role(_org uuid, _user uuid, _roles public.app_role[])
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT (auth.uid() IS NULL OR _user = auth.uid())
     AND EXISTS (SELECT 1 FROM public.organization_members
                 WHERE organization_id = _org AND user_id = _user AND role = ANY(_roles))
$$;
CREATE OR REPLACE FUNCTION public.shares_org_with(_other uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT (auth.uid() IS NULL OR _user = auth.uid())
     AND EXISTS (SELECT 1 FROM public.organization_members a
                 JOIN public.organization_members b ON a.organization_id = b.organization_id
                 WHERE a.user_id = _user AND b.user_id = _other)
$$;
