
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;

CREATE TABLE public.organization_invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  email text NOT NULL CHECK (email = lower(email) AND email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  role public.app_role NOT NULL,
  token_hash text NOT NULL UNIQUE,
  invited_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT now() + interval '7 days',
  accepted_at timestamptz,
  accepted_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  revoked_at timestamptz
);
CREATE INDEX organization_invitations_org_idx ON public.organization_invitations(organization_id, created_at DESC);
CREATE UNIQUE INDEX organization_invitations_pending_uq ON public.organization_invitations(organization_id, email)
  WHERE accepted_at IS NULL AND revoked_at IS NULL;
GRANT SELECT ON public.organization_invitations TO authenticated;
GRANT ALL ON public.organization_invitations TO service_role;
ALTER TABLE public.organization_invitations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read invitations" ON public.organization_invitations FOR SELECT TO authenticated
  USING (public.has_org_role(organization_id, auth.uid(), ARRAY['admin']::public.app_role[]));

-- Create invitation (admin only); returns the one-time token. Only its hash is stored.
CREATE OR REPLACE FUNCTION public.create_invitation(_org uuid, _email text, _role public.app_role)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
DECLARE tok text; em text := lower(trim(_email));
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_org_role(_org, auth.uid(), ARRAY['admin']::public.app_role[]) THEN
    RAISE EXCEPTION 'Only organization admins can invite employees';
  END IF;
  IF em !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' OR length(em) > 254 THEN
    RAISE EXCEPTION 'Enter a valid email address';
  END IF;
  IF EXISTS (SELECT 1 FROM public.organization_members m JOIN public.profiles p ON p.id = m.user_id
             WHERE m.organization_id = _org AND lower(p.email) = em) THEN
    RAISE EXCEPTION 'This person is already a member';
  END IF;
  UPDATE public.organization_invitations SET revoked_at = now()
    WHERE organization_id = _org AND email = em AND accepted_at IS NULL AND revoked_at IS NULL;
  tok := encode(extensions.gen_random_bytes(32), 'hex');
  INSERT INTO public.organization_invitations(organization_id, email, role, token_hash, invited_by)
    VALUES (_org, em, _role, encode(extensions.digest(tok, 'sha256'), 'hex'), auth.uid());
  INSERT INTO public.audit_events(organization_id, entity_type, action, details)
    VALUES (_org, 'invitation', 'invited', jsonb_build_object('email', em, 'role', _role));
  RETURN tok;
END $$;

CREATE OR REPLACE FUNCTION public.revoke_invitation(_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE org uuid;
BEGIN
  SELECT organization_id INTO org FROM public.organization_invitations WHERE id = _id;
  IF org IS NULL OR NOT public.has_org_role(org, auth.uid(), ARRAY['admin']::public.app_role[]) THEN
    RAISE EXCEPTION 'Not allowed';
  END IF;
  UPDATE public.organization_invitations SET revoked_at = now()
    WHERE id = _id AND accepted_at IS NULL AND revoked_at IS NULL;
  INSERT INTO public.audit_events(organization_id, entity_type, entity_id, action) VALUES (org, 'invitation', _id, 'revoked');
END $$;

-- Preview an invitation by token (signed-in only)
CREATE OR REPLACE FUNCTION public.get_invitation(_token text)
RETURNS TABLE(organization_name text, role public.app_role, email text, status text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, extensions AS $$
  SELECT o.name, i.role, i.email,
    CASE WHEN i.revoked_at IS NOT NULL THEN 'revoked'
         WHEN i.accepted_at IS NOT NULL THEN 'accepted'
         WHEN i.expires_at < now() THEN 'expired'
         ELSE 'pending' END
  FROM public.organization_invitations i JOIN public.organizations o ON o.id = i.organization_id
  WHERE auth.uid() IS NOT NULL AND i.token_hash = encode(extensions.digest(_token, 'sha256'), 'hex')
$$;

-- Accept: caller's verified account email must match the invited email
CREATE OR REPLACE FUNCTION public.accept_invitation(_token text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
DECLARE inv public.organization_invitations; caller_email text; confirmed timestamptz;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Sign in to accept this invitation'; END IF;
  SELECT * INTO inv FROM public.organization_invitations
    WHERE token_hash = encode(extensions.digest(_token, 'sha256'), 'hex') FOR UPDATE;
  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invitation not found'; END IF;
  IF inv.revoked_at IS NOT NULL THEN RAISE EXCEPTION 'This invitation was revoked'; END IF;
  IF inv.accepted_at IS NOT NULL THEN RAISE EXCEPTION 'This invitation was already used'; END IF;
  IF inv.expires_at < now() THEN RAISE EXCEPTION 'This invitation has expired'; END IF;
  SELECT lower(email), email_confirmed_at INTO caller_email, confirmed FROM auth.users WHERE id = auth.uid();
  IF confirmed IS NULL THEN RAISE EXCEPTION 'Confirm your email address first'; END IF;
  IF caller_email IS DISTINCT FROM inv.email THEN
    RAISE EXCEPTION 'This invitation was sent to a different email address';
  END IF;
  IF NOT public.is_org_member(inv.organization_id, auth.uid()) THEN
    PERFORM set_config('smartinvoice.bootstrap', 'on', true);
    INSERT INTO public.organization_members(organization_id, user_id, role, invited_by)
      VALUES (inv.organization_id, auth.uid(), inv.role, inv.invited_by);
    PERFORM set_config('smartinvoice.bootstrap', 'off', true);
  END IF;
  UPDATE public.organization_invitations SET accepted_at = now(), accepted_by = auth.uid() WHERE id = inv.id;
  RETURN inv.organization_id;
END $$;

REVOKE ALL ON FUNCTION public.create_invitation(uuid, text, public.app_role) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.revoke_invitation(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.get_invitation(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.accept_invitation(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_invitation(uuid, text, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.revoke_invitation(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_invitation(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.accept_invitation(text) TO authenticated;

-- Keep invited_by from the invite when bootstrapping
CREATE OR REPLACE FUNCTION public.guard_membership()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE remaining int;
BEGIN
  IF auth.uid() IS NULL THEN RETURN COALESCE(NEW, OLD); END IF;
  IF TG_OP = 'INSERT' AND coalesce(current_setting('smartinvoice.bootstrap', true), 'off') = 'on' THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'INSERT' AND NEW.user_id = auth.uid() THEN
    RAISE EXCEPTION 'You cannot add yourself to an organization';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF OLD.user_id = auth.uid() AND NEW.role IS DISTINCT FROM OLD.role THEN
      RAISE EXCEPTION 'You cannot change your own role';
    END IF;
    IF NEW.user_id IS DISTINCT FROM OLD.user_id THEN RAISE EXCEPTION 'user_id cannot be changed'; END IF;
  END IF;
  IF (TG_OP = 'DELETE' AND OLD.role = 'admin')
     OR (TG_OP = 'UPDATE' AND OLD.role = 'admin' AND NEW.role <> 'admin') THEN
    SELECT count(*) INTO remaining FROM public.organization_members
      WHERE organization_id = OLD.organization_id AND role = 'admin' AND id <> OLD.id;
    IF remaining = 0 THEN RAISE EXCEPTION 'An organization must keep at least one admin'; END IF;
  END IF;
  IF TG_OP = 'INSERT' THEN NEW.invited_by := auth.uid(); END IF;
  RETURN COALESCE(NEW, OLD);
END $$;

-- Audit every membership change
CREATE OR REPLACE FUNCTION public.audit_membership()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'DELETE' AND NOT EXISTS (SELECT 1 FROM public.organizations WHERE id = OLD.organization_id) THEN
    RETURN OLD;
  END IF;
  INSERT INTO public.audit_events(organization_id, actor_id, entity_type, entity_id, action, details)
  VALUES (COALESCE(NEW.organization_id, OLD.organization_id), auth.uid(), 'membership',
          COALESCE(NEW.user_id, OLD.user_id), lower(TG_OP),
          jsonb_build_object('old_role', CASE WHEN TG_OP <> 'INSERT' THEN OLD.role END,
                             'new_role', CASE WHEN TG_OP <> 'DELETE' THEN NEW.role END));
  RETURN COALESCE(NEW, OLD);
END $$;
REVOKE ALL ON FUNCTION public.audit_membership() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER organization_members_audit AFTER INSERT OR UPDATE OR DELETE ON public.organization_members
  FOR EACH ROW EXECUTE FUNCTION public.audit_membership();
