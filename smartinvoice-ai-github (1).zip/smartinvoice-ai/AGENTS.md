<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Invoice architecture
- Keep extraction and decision rules in the browser-safe invoice module with regression tests; PDF libraries load dynamically only during user actions to avoid SSR browser dependencies.
- Preserve optional evidence fields for older local-device audit records; canonical extracted total_amount is payable total for new records, while PO consumption is taxable spend from approved recommendations only.
- Generate demo PDFs on demand from shared synthetic fixtures so downloads stay reproducible without shipping binary assets.

## Frontend presentation
- Shared authenticated navigation and page headings belong in AppShell; page content stays in its existing leaf route to preserve authentication and invoice flows.
- Reuse RulesForm in the rules drawer and Settings page; submit organization policy changes through the authorized server function so drafts never change checks prematurely.
- Keep history search, sorting and detail selection as presentation state; never mutate persisted invoice records to deduplicate or filter the displayed list.

## Database
- Every business table carries organization_id; access is decided only by security-definer `is_org_member`/`has_org_role` over `organization_members`, so roles can never be self-assigned from the client.
- audit_events and validation_results are append-only for app users (no UPDATE/DELETE grants plus blocking triggers) to keep the audit trail trustworthy.
- Invoice PDFs live in the private `invoice-pdfs` bucket under `<organization_id>/...` so storage policies can reuse the same membership checks.
- Browser localStorage history is left untouched until a deliberate migration step.
- Signed-in app pages live under `src/routes/_authenticated/` (client-only gate); public auth pages are `/auth`, `/reset-password`, `/accept-invite`.
- Invitations are created/accepted only through security-definer RPCs that store a token hash and require the accepting account's confirmed email to match; there is no direct insert on memberships for non-admins.
- Registration is invite-only: the signup trigger rejects emails without a live invitation once any organization exists, and only existing admins (or the very first user) may create organizations — so outsiders can never bootstrap their own workspace.
- Shared invoice reads use an organization-scoped authenticated workspace query; local history is legacy-only and server-loaded organization policy is snapshotted for each run.
- Recompute decisions server-side with organization POs and shared history, then commit invoice/run/result/audit atomically through a server-only RPC with organization revision retries and reference-data serialization; browsers cannot write decision-bearing rows directly.
- Duplicate attempts append rejected runs and retain their own private PDF without changing the canonical invoice; deliberate legacy imports are idempotent per organization and retain untrusted evidence as review-only records.
- Reference management uses authenticated server functions with organization-scoped RLS clients and shared Zod schemas; database triggers validate and audit writes so direct API calls cannot bypass record integrity.
- Vendor and PO list controls live in URL search parameters; loaders prime an organization-scoped Query cache and views subscribe with Suspense to keep reads consistent across navigation.
- PO number, vendor and currency are immutable once invoices reference a PO; this preserves saved balance evidence while amounts and operational details remain editable.
- Cloud invoice matching requires normalized exact vendor identity and an explicit PO reference; ambiguous vendor candidates never auto-select a PO, and negative balances require review even within device tolerance.
- Root head initializes refresh globals only in development before shared chunks evaluate; the preview bundler otherwise evaluates transformed shared modules before its refresh preamble.
- Human approvals alone call the PO-row-lock reservation after the org advisory lock; canonical allocations are immutable and counted once with saved policy tolerance and append-only evidence.
- Manual approvals use the authenticated approve_invoice RPC and saved evidence only; callers cannot supply amounts, PO IDs or tolerance, and pending legacy/duplicate records cannot consume balance.
- New PDF uploads enter authenticated server functions that parse bytes before privileged private-storage writes at organization/hash paths; direct browser uploads are denied to prevent verification bypass.
- PDF parsing uses server-only unpdf with bounded sequential pages and original-byte preservation; trusted extraction is cached in server-owned durable hash jobs, with server-only Gateway OCR for unreadable pages.
- Corrections append revalidated runs without modifying original extraction; decision audit triggers reject stale source runs and terminal invoice changes to preserve evidence integrity.
- History uses bounded pages and lazy details; dashboard/report SQL aggregates avoid full-source transfers. PDFs use authenticated downloads, not shareable signed URLs.
