# Production-readiness inspection — 9 November 2026

## Preserved working foundation
The app uses TanStack Start server functions with authenticated Cloud clients, not separate Edge Functions. Existing organizations, invitations, tenant RLS, private storage, vendors/POs, shared invoice records, normalized duplicates, atomic decision saves and transaction-locked PO approvals are retained. Normal PDF processing already verifies and extracts stored bytes on the server; the brief's browser-extraction premise predates the latest changes.

Baseline executed: 46 application tests passed. The older 23-check security script is not retained in the repository; its prior reported result is not a new test result. The retained ten transaction tests use a disposable PostgreSQL instance, not production.

## Gaps to close
- Caller-supplied device settings are still authoritative; organization-governed policy is required.
- JavaScript floating point is used in monetary checks; exact decimal calculations are required.
- Automatic approvals currently exist, and an uploader can manually approve their own record. The chosen policy now requires a separate authorized approver for every invoice.
- Structured line-item evidence, complete GST checks and OCR are missing. No configured external OCR connector was found.
- Rejection, audited corrections, full processing lifecycle and durable idempotent retry are incomplete.
- Users can currently append arbitrary audit events; PDF deletion is not gated by retained evidence.
- Last-admin checks need serialization; PO reductions must not fall below approved allocations.
- Dashboard totals currently count attempts/human-decision runs and mislabel approval share as automatic approval. History loads entire organizations without pagination; reports are limited to run CSV.
- Live auth configuration, actual reset-email delivery, backup inventory, production load tests and published runtime are not yet verified.

## Implementation sequence
1. Exact financial rules and structured extraction/OCR evidence.
2. Additive governed policy, required independent approvals, rejection, corrections and audit hardening.
3. Durable processing/retry evidence, canonical reports and history pagination.
4. Role/isolation/concurrency tests and signed-in workflow checks.
5. Deployment, backup/recovery and retention handover with explicit external blockers.

No user records or source PDFs will be reset, deleted or overwritten. Existing presentation is preserved; only requested workflow controls and reporting are added.