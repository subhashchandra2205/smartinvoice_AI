export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      audit_events: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          details: Json
          entity_id: string | null
          entity_type: string
          id: string
          organization_id: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          details?: Json
          entity_id?: string | null
          entity_type: string
          id?: string
          organization_id: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          details?: Json
          entity_id?: string | null
          entity_type?: string
          id?: string
          organization_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "audit_events_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_processing_jobs: {
        Row: {
          created_at: string
          error_message: string | null
          extraction: Json | null
          file_hash: string
          file_path: string
          id: string
          lease_until: string | null
          organization_id: string
          processing_run_id: string | null
          status: string
          updated_at: string
          uploaded_by: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          extraction?: Json | null
          file_hash: string
          file_path: string
          id?: string
          lease_until?: string | null
          organization_id: string
          processing_run_id?: string | null
          status?: string
          updated_at?: string
          uploaded_by: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          extraction?: Json | null
          file_hash?: string
          file_path?: string
          id?: string
          lease_until?: string | null
          organization_id?: string
          processing_run_id?: string | null
          status?: string
          updated_at?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoice_processing_jobs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_processing_jobs_processing_run_id_fkey"
            columns: ["processing_run_id"]
            isOneToOne: false
            referencedRelation: "canonical_invoice_report"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_processing_jobs_processing_run_id_fkey"
            columns: ["processing_run_id"]
            isOneToOne: false
            referencedRelation: "processing_runs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_processing_jobs_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          approved_taxable_amount: number | null
          created_at: string
          currency: string
          file_name: string | null
          file_path: string | null
          file_sha256: string | null
          file_size_bytes: number | null
          id: string
          invoice_date: string | null
          invoice_number: string | null
          invoice_number_normalized: string | null
          organization_id: string
          purchase_order_id: string | null
          status: Database["public"]["Enums"]["invoice_status"]
          subtotal_amount: number | null
          tax_amount: number | null
          total_amount: number | null
          updated_at: string
          uploaded_by: string | null
          vendor_id: string | null
          vendor_identity: string | null
          vendor_name_extracted: string | null
        }
        Insert: {
          approved_taxable_amount?: number | null
          created_at?: string
          currency?: string
          file_name?: string | null
          file_path?: string | null
          file_sha256?: string | null
          file_size_bytes?: number | null
          id?: string
          invoice_date?: string | null
          invoice_number?: string | null
          invoice_number_normalized?: string | null
          organization_id: string
          purchase_order_id?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          subtotal_amount?: number | null
          tax_amount?: number | null
          total_amount?: number | null
          updated_at?: string
          uploaded_by?: string | null
          vendor_id?: string | null
          vendor_identity?: string | null
          vendor_name_extracted?: string | null
        }
        Update: {
          approved_taxable_amount?: number | null
          created_at?: string
          currency?: string
          file_name?: string | null
          file_path?: string | null
          file_sha256?: string | null
          file_size_bytes?: number | null
          id?: string
          invoice_date?: string | null
          invoice_number?: string | null
          invoice_number_normalized?: string | null
          organization_id?: string
          purchase_order_id?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          subtotal_amount?: number | null
          tax_amount?: number | null
          total_amount?: number | null
          updated_at?: string
          uploaded_by?: string | null
          vendor_id?: string | null
          vendor_identity?: string | null
          vendor_name_extracted?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invoices_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_organization_id_purchase_order_id_fkey"
            columns: ["organization_id", "purchase_order_id"]
            isOneToOne: false
            referencedRelation: "purchase_orders"
            referencedColumns: ["organization_id", "id"]
          },
          {
            foreignKeyName: "invoices_organization_id_vendor_id_fkey"
            columns: ["organization_id", "vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["organization_id", "id"]
          },
          {
            foreignKeyName: "invoices_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      organization_invitations: {
        Row: {
          accepted_at: string | null
          accepted_by: string | null
          created_at: string
          email: string
          expires_at: string
          id: string
          invited_by: string | null
          organization_id: string
          revoked_at: string | null
          role: Database["public"]["Enums"]["app_role"]
          token_hash: string
        }
        Insert: {
          accepted_at?: string | null
          accepted_by?: string | null
          created_at?: string
          email: string
          expires_at?: string
          id?: string
          invited_by?: string | null
          organization_id: string
          revoked_at?: string | null
          role: Database["public"]["Enums"]["app_role"]
          token_hash: string
        }
        Update: {
          accepted_at?: string | null
          accepted_by?: string | null
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          invited_by?: string | null
          organization_id?: string
          revoked_at?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          token_hash?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_invitations_accepted_by_fkey"
            columns: ["accepted_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "organization_invitations_invited_by_fkey"
            columns: ["invited_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "organization_invitations_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organization_members: {
        Row: {
          created_at: string
          id: string
          invited_by: string | null
          organization_id: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          invited_by?: string | null
          organization_id: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          invited_by?: string | null
          organization_id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_members_invited_by_fkey"
            columns: ["invited_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "organization_members_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "organization_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          created_at: string
          created_by: string
          id: string
          invoice_policy: Json
          name: string
          policy_version: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          id?: string
          invoice_policy?: Json
          name: string
          policy_version?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          invoice_policy?: Json
          name?: string
          policy_version?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "organizations_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      processing_runs: {
        Row: {
          completed_at: string | null
          created_at: string
          created_by: string | null
          engine_version: string
          error_message: string | null
          extracted_fields: Json
          extraction_metadata: Json | null
          id: string
          invoice_id: string
          legacy_created_at: string | null
          legacy_evidence: Json | null
          legacy_record_id: string | null
          operation_key: string | null
          organization_id: string
          policy_snapshot: Json
          raw_text: string | null
          result_snapshot: Json | null
          source_file_path: string | null
          source_file_sha256: string | null
          source_filename: string | null
          started_at: string | null
          status: Database["public"]["Enums"]["run_status"]
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          engine_version?: string
          error_message?: string | null
          extracted_fields?: Json
          extraction_metadata?: Json | null
          id?: string
          invoice_id: string
          legacy_created_at?: string | null
          legacy_evidence?: Json | null
          legacy_record_id?: string | null
          operation_key?: string | null
          organization_id: string
          policy_snapshot?: Json
          raw_text?: string | null
          result_snapshot?: Json | null
          source_file_path?: string | null
          source_file_sha256?: string | null
          source_filename?: string | null
          started_at?: string | null
          status?: Database["public"]["Enums"]["run_status"]
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          engine_version?: string
          error_message?: string | null
          extracted_fields?: Json
          extraction_metadata?: Json | null
          id?: string
          invoice_id?: string
          legacy_created_at?: string | null
          legacy_evidence?: Json | null
          legacy_record_id?: string | null
          operation_key?: string | null
          organization_id?: string
          policy_snapshot?: Json
          raw_text?: string | null
          result_snapshot?: Json | null
          source_file_path?: string | null
          source_file_sha256?: string | null
          source_filename?: string | null
          started_at?: string | null
          status?: Database["public"]["Enums"]["run_status"]
        }
        Relationships: [
          {
            foreignKeyName: "processing_runs_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "processing_runs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "processing_runs_organization_id_invoice_id_fkey"
            columns: ["organization_id", "invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["organization_id", "id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      purchase_orders: {
        Row: {
          amount: number
          created_at: string
          created_by: string | null
          currency: string
          delivery_date: string | null
          description: string | null
          id: string
          issued_on: string | null
          organization_id: string
          po_number: string
          status: Database["public"]["Enums"]["po_status"]
          updated_at: string
          vendor_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          created_by?: string | null
          currency?: string
          delivery_date?: string | null
          description?: string | null
          id?: string
          issued_on?: string | null
          organization_id: string
          po_number: string
          status?: Database["public"]["Enums"]["po_status"]
          updated_at?: string
          vendor_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          created_by?: string | null
          currency?: string
          delivery_date?: string | null
          description?: string | null
          id?: string
          issued_on?: string | null
          organization_id?: string
          po_number?: string
          status?: Database["public"]["Enums"]["po_status"]
          updated_at?: string
          vendor_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "purchase_orders_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_orders_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_orders_organization_id_vendor_id_fkey"
            columns: ["organization_id", "vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["organization_id", "id"]
          },
        ]
      }
      validation_results: {
        Row: {
          checks: Json
          created_at: string
          id: string
          invoice_id: string
          organization_id: string
          processing_run_id: string
          reasons: Json
          recommendation: Database["public"]["Enums"]["recommendation"]
          rule_evidence: Json
        }
        Insert: {
          checks?: Json
          created_at?: string
          id?: string
          invoice_id: string
          organization_id: string
          processing_run_id: string
          reasons?: Json
          recommendation: Database["public"]["Enums"]["recommendation"]
          rule_evidence?: Json
        }
        Update: {
          checks?: Json
          created_at?: string
          id?: string
          invoice_id?: string
          organization_id?: string
          processing_run_id?: string
          reasons?: Json
          recommendation?: Database["public"]["Enums"]["recommendation"]
          rule_evidence?: Json
        }
        Relationships: [
          {
            foreignKeyName: "validation_results_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "validation_results_organization_id_invoice_id_fkey"
            columns: ["organization_id", "invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["organization_id", "id"]
          },
          {
            foreignKeyName: "validation_results_organization_id_processing_run_id_fkey"
            columns: ["organization_id", "processing_run_id"]
            isOneToOne: false
            referencedRelation: "canonical_invoice_report"
            referencedColumns: ["organization_id", "id"]
          },
          {
            foreignKeyName: "validation_results_organization_id_processing_run_id_fkey"
            columns: ["organization_id", "processing_run_id"]
            isOneToOne: false
            referencedRelation: "processing_runs"
            referencedColumns: ["organization_id", "id"]
          },
        ]
      }
      vendors: {
        Row: {
          address: string | null
          created_at: string
          email: string | null
          gstin: string | null
          id: string
          name: string
          normalized_name: string | null
          organization_id: string
          phone: string | null
          status: string
          updated_at: string
        }
        Insert: {
          address?: string | null
          created_at?: string
          email?: string | null
          gstin?: string | null
          id?: string
          name: string
          normalized_name?: string | null
          organization_id: string
          phone?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          address?: string | null
          created_at?: string
          email?: string | null
          gstin?: string | null
          id?: string
          name?: string
          normalized_name?: string | null
          organization_id?: string
          phone?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "vendors_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      canonical_invoice_report: {
        Row: {
          created_at: string | null
          created_by: string | null
          extracted_fields: Json | null
          id: string | null
          invoice_id: string | null
          organization_id: string | null
          result_snapshot: Json | null
          source_file_path: string | null
          source_file_sha256: string | null
          source_filename: string | null
        }
        Relationships: [
          {
            foreignKeyName: "processing_runs_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "processing_runs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "processing_runs_organization_id_invoice_id_fkey"
            columns: ["organization_id", "invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["organization_id", "id"]
          },
        ]
      }
    }
    Functions: {
      accept_invitation: { Args: { _token: string }; Returns: string }
      approve_invoice: {
        Args: { _note: string; _org: string; _run: string }
        Returns: Json
      }
      can_create_organization: { Args: never; Returns: boolean }
      claim_invoice_job: {
        Args: { _actor: string; _job: string; _org: string }
        Returns: Json
      }
      cloud_invoice_revision: { Args: { _org: string }; Returns: string }
      commit_cloud_invoice: {
        Args: {
          _actor: string
          _org: string
          _payload: Json
          _revision: string
        }
        Returns: Json
      }
      commit_invoice_correction: {
        Args: {
          _actor: string
          _invoice: Json
          _note: string
          _org: string
          _policy: Json
          _result: Json
          _run: string
        }
        Returns: string
      }
      create_invitation: {
        Args: {
          _email: string
          _org: string
          _role: Database["public"]["Enums"]["app_role"]
        }
        Returns: string
      }
      create_organization: { Args: { _name: string }; Returns: string }
      get_cloud_invoice_state: { Args: { _org: string }; Returns: Json }
      get_invitation: {
        Args: { _token: string }
        Returns: {
          email: string
          organization_name: string
          role: Database["public"]["Enums"]["app_role"]
          status: string
        }[]
      }
      has_org_role: {
        Args: {
          _org: string
          _roles: Database["public"]["Enums"]["app_role"][]
          _user: string
        }
        Returns: boolean
      }
      invoice_report_summary: {
        Args: { _from?: string; _org: string; _to?: string; _view?: string }
        Returns: Json
      }
      is_org_member: { Args: { _org: string; _user: string }; Returns: boolean }
      normalize_invoice_number: { Args: { _num: string }; Returns: string }
      normalize_vendor_name: { Args: { _name: string }; Returns: string }
      read_invoice_history: {
        Args: {
          _ascending?: boolean
          _from?: string
          _limit?: number
          _offset?: number
          _org: string
          _search?: string
          _sort?: string
          _status?: string
          _to?: string
          _vendor?: string
        }
        Returns: Json
      }
      reject_invoice: {
        Args: { _note: string; _org: string; _run: string }
        Returns: string
      }
      reserve_invoice_po: {
        Args: { _invoice: string; _org: string; _run: string }
        Returns: Json
      }
      retain_legacy_invoice_evidence: {
        Args: { _evidence: Json; _org: string; _run: string }
        Returns: undefined
      }
      revoke_invitation: { Args: { _id: string }; Returns: undefined }
      save_invoice_policy: {
        Args: { _org: string; _policy: Json }
        Returns: undefined
      }
      shares_org_with: {
        Args: { _other: string; _user: string }
        Returns: boolean
      }
      storage_org_id: { Args: { _name: string }; Returns: string }
    }
    Enums: {
      app_role:
        | "admin"
        | "finance_manager"
        | "invoice_processor"
        | "reviewer"
        | "read_only"
      invoice_status:
        | "received"
        | "processing"
        | "approved"
        | "needs_review"
        | "rejected"
        | "pending_approval"
        | "extracted"
        | "failed"
        | "cancelled"
      po_status: "open" | "closed" | "cancelled"
      recommendation:
        | "approved"
        | "needs_review"
        | "rejected"
        | "pending_approval"
      run_status: "queued" | "running" | "succeeded" | "failed"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "finance_manager",
        "invoice_processor",
        "reviewer",
        "read_only",
      ],
      invoice_status: [
        "received",
        "processing",
        "approved",
        "needs_review",
        "rejected",
        "pending_approval",
        "extracted",
        "failed",
        "cancelled",
      ],
      po_status: ["open", "closed", "cancelled"],
      recommendation: [
        "approved",
        "needs_review",
        "rejected",
        "pending_approval",
      ],
      run_status: ["queued", "running", "succeeded", "failed"],
    },
  },
} as const
