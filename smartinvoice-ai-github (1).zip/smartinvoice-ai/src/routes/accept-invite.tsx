import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AuthLayout, authButton } from "@/components/AuthLayout";
import { ROLE_LABELS, type AppRole } from "@/lib/org";

export const Route = createFileRoute("/accept-invite")({
  validateSearch: (s: Record<string, unknown>) => ({ token: typeof s["token"] === "string" ? s["token"] : "" }),
  head: () => ({
    meta: [
      { title: "Join your team — SmartInvoice AI" },
      { name: "description", content: "Accept an invitation to join your organization on SmartInvoice AI." },
      { property: "og:title", content: "Join your team — SmartInvoice AI" },
      { property: "og:description", content: "Accept an invitation to your organization's SmartInvoice AI workspace." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  ssr: false,
  component: AcceptInvite,
});

type Invite = { organization_name: string; role: AppRole; email: string; status: string };

function AcceptInvite() {
  const { token } = Route.useSearch();
  const qc = useQueryClient();
  const [state, setState] = useState<"loading" | "signedout" | "ready" | "error">("loading");
  const [invite, setInvite] = useState<Invite | null>(null);
  const [me, setMe] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const here = `/accept-invite?token=${encodeURIComponent(token)}`;

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) return setState("signedout");
      setMe(data.user.email ?? "");
      const { data: rows, error } = await supabase.rpc("get_invitation", { _token: token });
      const row = rows?.[0];
      if (error || !row) {
        setError("This invitation link is not valid.");
        return setState("error");
      }
      setInvite(row as Invite);
      setState("ready");
    })();
  }, [token]);

  async function accept() {
    setBusy(true);
    setError(null);
    const { data, error } = await supabase.rpc("accept_invitation", { _token: token });
    setBusy(false);
    if (error) return setError(error.message);
    localStorage.setItem("smartinvoice.activeOrg", data as string);
    await qc.resetQueries({ queryKey: ["memberships"] });
    window.location.replace("/");
  }

  return (
    <AuthLayout title="Join your team" subtitle="You've been invited to SmartInvoice AI.">
      {state === "loading" && <Loader2 className="size-5 animate-spin text-muted-foreground" />}
      {state === "signedout" && (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">Sign in or create an account with the email address the invitation was sent to.</p>
          <Link to="/auth" search={{ redirect: here, mode: "signup" }} className={authButton}>Create account</Link>
          <Link to="/auth" search={{ redirect: here }} className="block text-center text-sm font-medium hover:underline">I already have an account</Link>
        </div>
      )}
      {state === "error" && <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
      {state === "ready" && invite && (
        <div className="space-y-5">
          <div className="panel space-y-2 p-4 text-sm">
            <p><span className="text-muted-foreground">Organization:</span> <b>{invite.organization_name}</b></p>
            <p><span className="text-muted-foreground">Role:</span> {ROLE_LABELS[invite.role]}</p>
            <p><span className="text-muted-foreground">Invited email:</span> {invite.email}</p>
            <p><span className="text-muted-foreground">Signed in as:</span> {me}</p>
          </div>
          {invite.status !== "pending" ? (
            <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">This invitation is {invite.status}. Ask your admin for a new one.</p>
          ) : (
            <>
              {error && <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
              <button onClick={accept} disabled={busy} className={authButton}>
                {busy && <Loader2 className="size-4 animate-spin" />}Accept invitation
              </button>
            </>
          )}
        </div>
      )}
    </AuthLayout>
  );
}
