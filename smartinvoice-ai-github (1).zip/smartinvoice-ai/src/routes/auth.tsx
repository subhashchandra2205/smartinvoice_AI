import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AuthLayout, authButton, authInput } from "@/components/AuthLayout";
import { safeRedirect } from "@/lib/org";

type Mode = "signin" | "signup" | "forgot";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { redirect?: string | undefined; mode?: Mode | undefined } => ({
    redirect: typeof s["redirect"] === "string" ? s["redirect"] : undefined,
    mode: s["mode"] === "signup" || s["mode"] === "forgot" ? (s["mode"] as Mode) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Sign in — SmartInvoice AI" },
      { name: "description", content: "Sign in to SmartInvoice AI to process and validate supplier invoices." },
      { property: "og:title", content: "Sign in — SmartInvoice AI" },
      { property: "og:description", content: "Secure sign-in for your accounts payable team." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>(search.mode ?? "signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const target = safeRedirect(search.redirect);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: target, replace: true });
    });
  }, [navigate, target]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: target, replace: true });
      } else if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin + target,
            data: { full_name: name.trim() || undefined },
          },
        });
        if (error) throw error;
        if (data.session) navigate({ to: target, replace: true });
        else setNotice("Check your email to confirm your account, then sign in.");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setNotice("If an account exists for that email, a reset link is on its way.");
      }
    } catch (err) {
      let msg = err instanceof Error ? err.message : "Something went wrong";
      if (mode === "signup" && /database error/i.test(msg)) msg = "Sign-up is by invitation only. Use the email address your admin invited.";
      setError(msg === "Invalid login credentials" ? "Email or password is incorrect." : msg);
    } finally {
      setBusy(false);
    }
  }

  const copy = {
    signin: { t: "Sign in", s: "Welcome back. Use your work email." },
    signup: { t: "Create your account", s: "Set up the first administrator account for your company, or join with an invitation." },
    forgot: { t: "Reset your password", s: "We'll email you a link to choose a new password." },
  }[mode];

  return (
    <AuthLayout title={copy.t} subtitle={copy.s}>
      <form onSubmit={submit} className="space-y-4">
        {mode === "signup" && (
          <label className="block text-sm font-medium text-foreground">
            Full name
            <input className={authInput} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" maxLength={120} />
          </label>
        )}
        <label className="block text-sm font-medium text-foreground">
          Work email
          <input className={authInput} type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        </label>
        {mode !== "forgot" && (
          <label className="block text-sm font-medium text-foreground">
            <span className="flex items-center justify-between">
              Password
              {mode === "signin" && (
                <button type="button" onClick={() => setMode("forgot")} className="text-xs font-normal text-secondary-foreground hover:underline">
                  Forgot password?
                </button>
              )}
            </span>
            <input
              className={authInput}
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
            />
          </label>
        )}
        {error && <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
        {notice && <p role="status" className="rounded-md bg-accent px-3 py-2 text-sm text-accent-foreground">{notice}</p>}
        <button type="submit" disabled={busy} className={authButton}>
          {busy && <Loader2 className="size-4 animate-spin" />}
          {mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : "Send reset link"}
        </button>
      </form>
      <p className="mt-6 text-center text-sm text-muted-foreground">
        {mode === "signin" ? (
          <>New here? <button onClick={() => setMode("signup")} className="font-medium text-foreground hover:underline">Create an account</button></>
        ) : (
          <>Already have an account? <button onClick={() => setMode("signin")} className="font-medium text-foreground hover:underline">Sign in</button></>
        )}
      </p>
    </AuthLayout>
  );
}
