import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AuthLayout, authButton, authInput } from "@/components/AuthLayout";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Choose a new password — SmartInvoice AI" },
      { name: "description", content: "Set a new password for your SmartInvoice AI account." },
      { property: "og:title", content: "Choose a new password — SmartInvoice AI" },
      { property: "og:description", content: "Set a new password for your SmartInvoice AI account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const isRecovery = window.location.hash.includes("type=recovery");
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") setReady(true);
    });
    supabase.auth.getSession().then(({ data: s }) => {
      if (s.session && isRecovery) setReady(true);
      else if (!isRecovery) setReady(Boolean(s.session));
    });
    return () => data.subscription.unsubscribe();
  }, []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (password !== confirm) return setError("Passwords do not match.");
    setBusy(true);
    setError(null);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) return setError(error.message);
    navigate({ to: "/", replace: true });
  }

  return (
    <AuthLayout title="Choose a new password" subtitle={ready ? "Use at least 8 characters." : "Open this page from the reset link in your email."}>
      {ready ? (
        <form onSubmit={submit} className="space-y-4">
          <label className="block text-sm font-medium">
            New password
            <input className={authInput} type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
          </label>
          <label className="block text-sm font-medium">
            Confirm password
            <input className={authInput} type="password" required minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
          </label>
          {error && <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
          <button className={authButton} disabled={busy}>
            {busy && <Loader2 className="size-4 animate-spin" />}Update password
          </button>
        </form>
      ) : (
        <a href="/auth?mode=forgot" className={authButton}>Request a new link</a>
      )}
    </AuthLayout>
  );
}
