import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Skeleton } from "@/components/ui/skeleton";
import { UploadCloud, FileText, Loader2, CheckCircle2, AlertTriangle, XCircle, Check, Circle } from "lucide-react";
import { Panel, Field, StatusPill } from "@/components/ui-kit";
import { inr, type Run } from "@/lib/invoice";
import { usePolicy } from "@/lib/policy";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { DemoCases } from "@/components/DemoCases";

import { useServerFn } from "@tanstack/react-start";
import { processCloudInvoice, uploadCloudPdf } from "@/lib/invoices.functions";
import { useRefreshInvoices } from "@/lib/invoices-store";
import { useOrg } from "@/lib/org";
import { InvoiceEvidence } from "@/components/InvoiceEvidence";
import { InvoicePdfButton } from "@/components/InvoicePdfButton";

export const Route = createFileRoute("/_authenticated/process")({
  head: () => ({
    meta: [
      { title: "Process invoice — SmartInvoice AI" },
      { name: "description", content: "Upload an invoice PDF to extract fields, match the purchase order and validate GST." },
      { property: "og:title", content: "Process invoice — SmartInvoice AI" },
      { property: "og:description", content: "Upload an invoice PDF for automated validation." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Process,
});

const STAGES = ["Upload", "Verify", "Extract", "Validate"];

function Process() {
  const {settings}=usePolicy();
  const { active } = useOrg();
  const process = useServerFn(processCloudInvoice);
  const upload = useServerFn(uploadCloudPdf);
  const refresh = useRefreshInvoices();
  const canProcess = !!active && ["admin", "finance_manager", "invoice_processor"].includes(active.role);
  const [file, setFile] = useState<File | null>(null);
  const [stage, setStage] = useState(-1);
  const [error, setError] = useState<string | null>(null);
  const [run, setRun] = useState<Run | null>(null);
  const [drag, setDrag] = useState(false);

  const pick = (f?: File) => { if (f && !busy) { setFile(f);setRun(null); setError(null); setStage(-1); } };

  async function go() {
    if (!file || !active || !canProcess) return;
    setError(null); setRun(null);
    try {
      setStage(0);
      if (file.size > 20971520) throw new Error("PDF must be 20 MB or smaller.");
      const body = new FormData();
      body.set("organizationId", active.organization_id); body.set("pdf", file);
      setStage(1);
      const uploaded = await upload({ data: body });
      setStage(2);
      setStage(3);
      const r = await process({ data: { organizationId: active.organization_id,operationKey:uploaded.operationKey,filePath: uploaded.filePath, filename: uploaded.filename, settings } });
      await refresh();
      setStage(4);
      setRun(r);
      toast.success("Invoice decision saved");
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      toast.error("Invoice could not be processed");
    }
  }

  const busy = stage >= 0 && stage < 4 && !error;

  return (
    <>
      <section className="mx-auto max-w-2xl">
        {!canProcess && <p className="mb-4 text-xs text-muted-foreground">Your role can view invoices but cannot upload or process them.</p>}
        <label
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files[0]); }}
          className={cn("flex min-h-[240px] cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed bg-card px-6 py-10 text-center transition-colors", drag ? "border-primary bg-primary-soft" : "border-input hover:border-primary")}
        >
          <input aria-label="Invoice PDF" type="file" accept="application/pdf" className="sr-only" onChange={(e) => pick(e.target.files?.[0])} />
          <span className="grid size-12 place-items-center rounded-xl bg-primary-soft text-primary">{file ? <FileText className="size-5" /> : <UploadCloud className="size-5" />}</span>
          <p className="mt-5 max-w-full break-all text-sm font-semibold">{file ? file.name : "Drop your invoice PDF here"}</p>
          <p className="mt-2 text-xs text-muted-foreground">{file ? `${file.size.toLocaleString()} bytes · Select another file` : "or browse files · PDF only"}</p>
        </label>
        <Button disabled={!file || busy || !canProcess} onClick={go} className="mt-4 h-10 w-full">{busy ? <Loader2 className="animate-spin" /> : <FileText />}Process invoice</Button>
        <ol className="mt-8 grid grid-cols-4 gap-2" aria-label="Processing progress">{STAGES.map((st, i) => {
          const done = stage > i, active = stage === i && !error;
          return <li key={st} className="flex min-w-0 flex-col items-center gap-2 text-xs"><span className={cn("grid size-8 place-items-center rounded-full border", done ? "border-primary bg-primary text-primary-foreground" : active ? "border-primary bg-primary-soft text-primary" : "border-border bg-card text-muted-foreground")}>{done ? <Check className="size-4" /> : active ? <Loader2 className="size-4 animate-spin" /> : <span className="num">{i + 1}</span>}</span><span className={cn("font-medium", !done && !active && "text-muted-foreground")}>{st}</span></li>;
        })}</ol>
        {error && <p role="alert" className="mt-6 rounded-md border border-border bg-card p-4 text-sm">{error}</p>}
        {busy && <div className="mt-8 grid grid-cols-2 gap-4" aria-label="Processing invoice"><Skeleton className="h-24" /><Skeleton className="h-24" /></div>}
      </section>

      {run && <Result run={run} />}
      <DemoCases />
    </>
  );
}

function Result({ run }: { run: Run }) {
  const { invoice: inv, result: res } = run;
  const tone = res.status === "Approved"
    ? { cls: "bg-success-soft text-muted-foreground ring-success/25", I: CheckCircle2, t: "All configured checks passed" }
    : res.status === "Rejected"
      ? { cls: "bg-danger-soft text-destructive ring-destructive/25", I: XCircle, t: "A blocking condition was detected" }
      : { cls: "bg-warning-soft text-muted-foreground ring-warning/30", I: AlertTriangle, t: "Human verification required" };
  const gst = res.gst_validation;

  return (
    <div className="mt-10 space-y-6">
      <div className="panel flex flex-wrap items-center gap-5 p-6">
        <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary-soft text-primary"><tone.I className="size-5" /></span>
        <div className="min-w-40">
          <StatusPill status={res.status} />
          <InvoicePdfButton path={run.file_path} />
          <p className="text-sm opacity-90">{tone.t}</p>
        </div>
        <div className="ml-auto flex flex-wrap gap-x-8 gap-y-2 text-sm">
          <div>
            <p className="text-[11px] uppercase tracking-[0.14em] opacity-70">Invoice value</p>
            <p className="num font-semibold">{inr(inv.total_amount)}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.14em] opacity-70">Vendor</p>
            <p className="font-semibold">{inv.vendor_name ?? "—"}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.14em] opacity-70">PO</p>
            <p className="num font-semibold">{inv.po_number ?? "—"}</p>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel
          title="Extracted invoice data"
          right={<span className="text-xs text-muted-foreground">Completeness <span className="num font-medium text-foreground">{Math.round(inv.confidence * 100)}%</span></span>}
        >
          <dl className="grid grid-cols-2 gap-4">
            <Field label="Vendor" value={inv.vendor_name} />
            <Field label="GSTIN" value={inv.gstin} mono />
            <Field label="Invoice number" value={<span className="font-mono text-xs">{inv.invoice_number ?? "Missing"}</span>} />
            <Field label="Invoice date" value={inv.invoice_date} mono />
            <Field label="PO reference" value={<span className="font-mono text-xs">{inv.po_number ?? "Missing"}</span>} />
            <Field label="Grand total / payable" value={inv.total_amount == null ? null : inr(inv.total_amount)} mono />
            <Field label="Subtotal (extracted)" value={inv.taxable_amount == null ? null : inr(inv.taxable_amount)} mono />
            <Field label="GST / tax" value={inv.tax_amount == null ? null : inr(inv.tax_amount)} mono />
          </dl>
          <p className="mt-4 text-[11px] text-muted-foreground">Completeness is a heuristic of required fields found, not calibrated AI confidence.</p>
        </Panel>

        <Panel title="Purchase order match">
          {res.matched_po ? (
            <dl className="grid grid-cols-2 gap-4">
              <Field label="PO number" value={<span className="font-mono text-xs">{res.matched_po.po_number}</span>} />
              <Field label="PO status" value={res.matched_po.status} />
              <Field label="PO vendor" value={res.matched_po.vendor_name} />
              <Field label="PO amount" value={inr(res.matched_po.po_amount)} mono />
              <Field label="Cumulative overage" value={res.variance_pct == null ? "—" : `${res.variance_pct.toFixed(2)}%`} mono />
              {res.po_balance && <>
                <Field label="Previously approved (net)" value={inr(res.po_balance.previously_approved)} mono />
                <Field label="Current taxable spend" value={inr(res.po_balance.current_taxable)} mono />
                <Field label="Remaining before" value={inr(res.po_balance.remaining_before)} mono />
                <Field label="Remaining after (if approved)" value={inr(res.po_balance.remaining_after)} mono />
                <Field label="PO allowance incl. tolerance" value={inr(res.po_balance.allowed_total)} mono />
              </>}
            </dl>
          ) : (
            <div><p className="text-sm text-muted-foreground">No purchase order selected.</p>
              {(res.po_candidates?.length ?? 0) > 0 && <ul className="mt-3 divide-y divide-border">{res.po_candidates?.map((po) => <li key={po.po_number} className="flex flex-wrap justify-between gap-2 py-3 text-sm"><span className="num font-medium">{po.po_number}</span><span>{po.vendor_name}</span><span className="num">{inr(po.po_amount)}</span></li>)}</ul>}
            </div>
          )}
        </Panel>
      </div>

      <Panel title="GST validation" right={gst && <StatusPill status={gst.status} />}>
        {gst ? (
          <>
            <dl className="grid grid-cols-2 gap-4 sm:grid-cols-5">
              <Field label="Taxable amount" value={inr(gst.taxable_amount)} mono />
              <Field label="Expected GST" value={inr(gst.expected_tax)} mono />
              <Field label="Extracted GST" value={inr(gst.extracted_tax)} mono />
              <Field label="Difference" value={inr(gst.tax_difference)} mono />
              <Field label="Expected total" value={inr(gst.expected_total)} mono />
            </dl>
            <p className="mt-4 text-sm text-muted-foreground">{gst.message}</p>
          </>
        ) : (
          <p className="text-sm text-muted-foreground">GST validation was not performed (amount missing).</p>
        )}
      </Panel>

      <Panel title="Decision explanation">
        <ul className="space-y-2 text-sm">
          {res.reasons.map((r) => (
            <li key={r} className="flex gap-2">
              <AlertTriangle className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
              {r}
            </li>
          ))}
          {res.checks.map((c) => (
            <li key={c} className="flex gap-2 text-muted-foreground">
              <Check className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
              {c}
            </li>
          ))}
        </ul>
      </Panel>

      <InvoiceEvidence run={run} />
      <details className="panel p-5">
        <summary className="cursor-pointer text-sm font-semibold">Extracted source text</summary>
        <pre className="num mt-4 max-h-96 overflow-auto whitespace-pre-wrap rounded-md bg-muted p-4 text-xs">{run.raw_text.slice(0, 12000)}</pre>
      </details>

      <p className="text-center text-xs text-muted-foreground">Prototype recommendation only. A human approver must authorise any payment.</p>
    </div>
  );
}
