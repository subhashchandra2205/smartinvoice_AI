import { createFileRoute } from '@tanstack/react-router';
import { ReferenceManagement, parseReferenceSearch } from '@/components/ReferenceManagement';
import { loadReferences } from '@/lib/reference-query';
export const Route=createFileRoute('/_authenticated/purchase-orders')({
 validateSearch:parseReferenceSearch,
 loader:({context})=>loadReferences(context.queryClient,context.user.id),
 head:()=>({meta:[{title:'Purchase orders — SmartInvoice AI'},{name:'description',content:'Manage purchase orders, approved invoice spending and remaining balances.'},{property:'og:title',content:'Purchase orders — SmartInvoice AI'},{property:'og:description',content:'Purchase order commitments and available balances.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary'}]}),
 component:PurchaseOrders,
 errorComponent:({error})=><div role="alert">{error instanceof Error?error.message:'Unable to load purchase orders.'}</div>,
 notFoundComponent:()=><p>Purchase orders not found.</p>,
});
function PurchaseOrders(){const search=Route.useSearch(),navigate=Route.useNavigate();return <ReferenceManagement kind="orders" search={search} update={patch=>{void navigate({search:prev=>({...prev,...patch}),replace:true});}}/>;}
