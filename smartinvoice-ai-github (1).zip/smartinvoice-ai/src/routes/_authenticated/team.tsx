import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Copy, Loader2, Trash2, UserPlus, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader, Panel } from "@/components/ui-kit";
import { ROLES, ROLE_LABELS, useOrg, type AppRole } from "@/lib/org";

export const Route = createFileRoute("/_authenticated/team")({
  head: () => ({
    meta: [
      { title: "Team — SmartInvoice AI" },
      { name: "description", content: "Invite employees and manage roles for your SmartInvoice AI organization." },
      { property: "og:title", content: "Team — SmartInvoice AI" },
      { property: "og:description", content: "Invite employees and manage roles." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Team,
});

const sel = "rounded-md border border-input bg-card px-2.5 py-1.5 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20";

function Team() {
  const { active, user } = useOrg();
  const org = active!.organization_id;
  const isAdmin = active!.role === "admin";
  const qc = useQueryClient();

  const members = useQuery({
    queryKey: ["members", org],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("organization_members")
        .select("id, user_id, role, created_at, profiles!organization_members_user_id_fkey(email, full_name)")
        .eq("organization_id", org)
        .order("created_at");
      if (error) throw error;
      return data;
    },
  });

  const invites = useQuery({
    queryKey: ["invites", org],
    enabled: isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("organization_invitations")
        .select("id, email, role, created_at, expires_at")
        .eq("organization_id", org)
        .is("accepted_at", null)
        .is("revoked_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["members", org] });
    qc.invalidateQueries({ queryKey: ["invites", org] });
  };
  const onErr = (e: Error) => toast.error(e.message);

  const changeRole = useMutation({
    mutationFn: async ({ id, role }: { id: string; role: AppRole }) => {
      const { data, error } = await supabase.from("organization_members").update({ role }).eq("id", id).select("id");
      if (error) throw error;
      if (!data?.length) throw new Error("You don't have permission to change roles.");
    },
    onSuccess: () => { toast.success("Role updated"); refresh(); },
    onError: onErr,
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase.from("organization_members").delete().eq("id", id).select("id");
      if (error) throw error;
      if (!data?.length) throw new Error("You don't have permission to remove members.");
    },
    onSuccess: () => { toast.success("Member removed"); refresh(); },
    onError: onErr,
  });

  const revoke = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.rpc("revoke_invitation", { _id: id });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Invitation revoked"); refresh(); },
    onError: onErr,
  });

  const [email, setEmail] = useState("");
  const [role, setRole] = useState<AppRole>("invoice_processor");
  const [link, setLink] = useState<string | null>(null);
  const invite = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.rpc("create_invitation", { _org: org, _email: email, _role: role });
      if (error) throw error;
      return `${window.location.origin}/accept-invite?token=${data}`;
    },
    onSuccess: (url) => { setLink(url); setEmail(""); refresh(); },
    onError: onErr,
  });

  return (
    <div className="space-y-6">
      <PageHeader eyebrow={active!.organization_name} title="Team" sub="People who can access this organization and what they're allowed to do." />

      {!isAdmin && (
        <div className="flex items-center gap-2 rounded-md bg-accent px-4 py-3 text-sm text-accent-foreground">
          <ShieldAlert className="size-4" /> Only admins can invite people or change roles. You're viewing the member list.
        </div>
      )}

      {isAdmin && (
        <Panel title="Invite an employee">
          <form
            onSubmit={(e: FormEvent) => { e.preventDefault(); setLink(null); invite.mutate(); }}
            className="flex flex-wrap items-end gap-3 p-5"
          >
            <label className="min-w-60 flex-1 text-sm font-medium">
              Work email
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className={`${sel} mt-1.5 w-full`} />
            </label>
            <label className="text-sm font-medium">
              Role
              <select value={role} onChange={(e) => setRole(e.target.value as AppRole)} className={`${sel} mt-1.5 block`}>
                {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
              </select>
            </label>
            <button disabled={invite.isPending} className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary-strong disabled:opacity-60">
              {invite.isPending ? <Loader2 className="size-4 animate-spin" /> : <UserPlus className="size-4" />} Create invite
            </button>
          </form>
          {link && (
            <div className="mx-5 mb-5 rounded-md border border-border bg-primary-soft p-3 text-sm">
              <p className="font-medium">Send this link to the employee. It works once, only for that email, for 7 days.</p>
              <div className="mt-2 flex items-center gap-2">
                <code className="num min-w-0 flex-1 truncate rounded bg-card px-2 py-1 text-xs">{link}</code>
                <button
                  type="button"
                  onClick={() => { navigator.clipboard.writeText(link); toast.success("Link copied"); }}
                  className="inline-flex items-center gap-1 rounded-md border border-input bg-card px-2.5 py-1 text-xs hover:bg-muted"
                ><Copy className="size-3.5" /> Copy</button>
              </div>
            </div>
          )}
        </Panel>
      )}

      <Panel title={`Members (${members.data?.length ?? 0})`}>
        {members.isLoading ? (
          <div className="p-5"><Loader2 className="size-4 animate-spin" /></div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr><th className="px-5 py-2.5">Person</th><th className="px-5 py-2.5">Role</th><th className="px-5 py-2.5 text-right">Actions</th></tr>
            </thead>
            <tbody>
              {members.data?.map((m) => {
                const p = m.profiles as { email: string | null; full_name: string | null } | null;
                const self = m.user_id === user.id;
                return (
                  <tr key={m.id} className="border-t border-border">
                    <td className="px-5 py-3">
                      <p className="font-medium">{p?.full_name || p?.email}{self && <span className="ml-2 text-xs text-muted-foreground">(you)</span>}</p>
                      {p?.full_name && <p className="text-xs text-muted-foreground">{p.email}</p>}
                    </td>
                    <td className="px-5 py-3">
                      {isAdmin && !self ? (
                        <select
                          aria-label={`Role for ${p?.email}`}
                          value={m.role}
                          onChange={(e) => changeRole.mutate({ id: m.id, role: e.target.value as AppRole })}
                          className={sel}
                        >
                          {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
                        </select>
                      ) : (
                        ROLE_LABELS[m.role]
                      )}
                    </td>
                    <td className="px-5 py-3 text-right">
                      {isAdmin && !self && (
                        <button
                          onClick={() => confirm(`Remove ${p?.email} from this organization?`) && remove.mutate(m.id)}
                          className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-destructive hover:bg-destructive/10"
                        ><Trash2 className="size-3.5" /> Remove</button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </Panel>

      {isAdmin && (
        <Panel title={`Pending invitations (${invites.data?.length ?? 0})`}>
          {invites.data?.length ? (
            <ul>
              {invites.data.map((i) => (
                <li key={i.id} className="flex items-center justify-between border-t border-border px-5 py-3 text-sm first:border-t-0">
                  <span>{i.email} · <span className="text-muted-foreground">{ROLE_LABELS[i.role]} · expires {new Date(i.expires_at).toLocaleDateString()}</span></span>
                  <button onClick={() => revoke.mutate(i.id)} className="text-xs text-destructive hover:underline">Revoke</button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-4 text-sm text-muted-foreground">No pending invitations.</p>
          )}
        </Panel>
      )}
    </div>
  );
}
