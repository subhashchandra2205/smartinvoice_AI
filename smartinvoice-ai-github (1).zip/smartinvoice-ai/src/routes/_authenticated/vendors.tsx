import { createFileRoute } from '@tanstack/react-router';
import { ReferenceManagement, parseReferenceSearch } from '@/components/ReferenceManagement';
import { loadReferences } from '@/lib/reference-query';
export const Route=createFileRoute('/_authenticated/vendors')({
 validateSearch:parseReferenceSearch,
 loader:({context})=>loadReferences(context.queryClient,context.user.id),
 head:()=>({meta:[{title:'Vendors — SmartInvoice AI'},{name:'description',content:'Manage organization vendors and supplier contact records.'},{property:'og:title',content:'Vendors — SmartInvoice AI'},{property:'og:description',content:'Organization vendor management and supplier records.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary'}]}),
 component:Vendors,
 errorComponent:({error})=><div role="alert">{error instanceof Error?error.message:'Unable to load vendors.'}</div>,
 notFoundComponent:()=><p>Vendor records not found.</p>,
});
function Vendors(){const search=Route.useSearch(),navigate=Route.useNavigate();return <ReferenceManagement kind="vendors" search={search} update={patch=>{void navigate({search:prev=>({...prev,...patch}),replace:true});}}/>;}
