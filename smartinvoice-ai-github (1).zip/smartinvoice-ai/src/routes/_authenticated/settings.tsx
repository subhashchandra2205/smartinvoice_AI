import { createFileRoute } from "@tanstack/react-router";
import { RulesForm } from "@/components/RulesForm";
import { PdfBackup } from "@/components/PdfBackup";
export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings — SmartInvoice AI" }, { name: "description", content: "Manage invoice validation preferences in SmartInvoice AI." }, { property: "og:title", content: "Settings — SmartInvoice AI" }, { property: "og:description", content: "Manage PO and GST validation preferences." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: () => <section className="max-w-xl"><h2 className="mb-6 text-base font-semibold">Validation rules</h2><RulesForm /><PdfBackup /></section>,
});
