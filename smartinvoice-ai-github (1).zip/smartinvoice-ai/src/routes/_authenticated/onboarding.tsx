import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Building2, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AuthLayout, authButton, authInput } from "@/components/AuthLayout";
import { membershipsQuery, useOrg } from "@/lib/org";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({
    meta: [
      { title: "Set up your company — SmartInvoice AI" },
      { name: "description", content: "Create your organization workspace in SmartInvoice AI." },
      { property: "og:title", content: "Set up your company — SmartInvoice AI" },
      { property: "og:description", content: "Create your organization workspace in SmartInvoice AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Onboarding,
});

function Onboarding() {
  const { user, memberships, setActive } = useOrg();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [allowed, setAllowed] = useState<boolean | null>(null);
  useEffect(() => {
    supabase.rpc("can_create_organization").then(({ data }) => setAllowed(Boolean(data)));
  }, []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { data, error } = await supabase.rpc("create_organization", { _name: name.trim() });
    setBusy(false);
    if (error) return setError(error.message);
    if (!data) return setError("Organization creation did not return a workspace.");
    setActive(data);
    const q = membershipsQuery(user.id);
    qc.setQueryData(q.queryKey, await q.queryFn());
    // Full reload so the workspace shell starts from fresh membership data.
    window.location.replace("/");
  }

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", search: {}, replace: true });
  }

  return (
    <AuthLayout
      title="Set up your company"
      subtitle={memberships.length ? "Create another organization workspace." : "You'll be its administrator and can invite your team next. Waiting for an invite instead? Open the link your admin sent you."}
    >
      {allowed === false ? (
        <p className="rounded-md bg-accent px-3 py-2 text-sm text-accent-foreground">
          New organizations can only be created by an existing administrator. To join your company, open the invitation link your admin sent you.
        </p>
      ) : (
      <form onSubmit={submit} className="space-y-4">
        <label className="block text-sm font-medium">
          Company name
          <div className="relative">
            <Building2 className="pointer-events-none absolute left-3 top-1/2 mt-0.75 size-4 -translate-y-1/2 text-muted-foreground" />
            <input className={`${authInput} pl-9`} required maxLength={200} value={name} onChange={(e) => setName(e.target.value)} placeholder="Acme Industries Pvt Ltd" />
          </div>
        </label>
        {error && <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
        <button className={authButton} disabled={busy || !name.trim()}>
          {busy && <Loader2 className="size-4 animate-spin" />}Create organization
        </button>
      </form>
      )}
      <p className="mt-6 text-center text-sm text-muted-foreground">
        Signed in as {user.email} ·{" "}
        <button onClick={signOut} className="font-medium text-foreground hover:underline">Sign out</button>
      </p>
    </AuthLayout>
  );
}
