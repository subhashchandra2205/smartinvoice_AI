import { decimal, money } from "./money";
import type { Invoice, ValidationResult } from "./invoice";
export interface RuleEvidence { rule_id: string; description: string; expected: string | null; actual: string | null; difference: string | null; result: "pass" | "fail" | "review"; severity: "info" | "warning" | "blocking"; timestamp: string }
const alphabet="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
export function gstinChecksum(value: string) {
 if(!/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(value)) return false;
 let total=0;
 for(let i=0;i<14;i++){const character=value[i];if(!character)return false;const product=alphabet.indexOf(character)*(i%2===0?1:2);total+=Math.floor(product/36)+product%36;}
 return alphabet[(36-total%36)%36]===value[14];
}
export function financialEvidence(invoice:Invoice,tolerance:number,stamp:string):RuleEvidence[]{
 const rules:RuleEvidence[]=[];
 const add=(id:string,description:string,expected:string|null,actual:string|null,result:RuleEvidence["result"],difference:string|null=null)=>rules.push({rule_id:id,description,expected,actual,difference,result,severity:result==='pass'?'info':'blocking',timestamp:stamp});
 if(invoice.gstin)add('gstin.checksum','GSTIN format and checksum (not government verification)','valid checksum',invoice.gstin,gstinChecksum(invoice.gstin)?'pass':'fail');
 else add('gstin.present','Vendor GSTIN must be evidenced','GSTIN',null,'review');
 const c=invoice.gst_components;
 if(c && (c.cgst!=null||c.sgst!=null||c.igst!=null)){
  const interstate=c.igst!=null&&decimal(c.igst).gt(0),local=(c.cgst!=null&&decimal(c.cgst).gt(0))||(c.sgst!=null&&decimal(c.sgst).gt(0));
  add('gst.components.exclusive','IGST cannot be combined with CGST/SGST','one GST scheme',JSON.stringify(c),interstate&&local?'fail':'pass');
  if(local)add('gst.components.equal','CGST and SGST must both be present and equal',String(c.cgst),String(c.sgst),c.cgst!=null&&c.sgst!=null&&decimal(c.cgst).eq(c.sgst)?'pass':'fail');
  const total=decimal(c.cgst??0).plus(c.sgst??0).plus(c.igst??0);
  if(invoice.tax_amount!=null)add('gst.components.total','GST components reconcile to aggregate tax',total.toFixed(2),decimal(invoice.tax_amount).toFixed(2),total.minus(invoice.tax_amount).abs().lte(tolerance)?'pass':'fail',total.minus(invoice.tax_amount).toFixed(2));
 }
 if(invoice.taxable_amount!=null&&invoice.tax_amount!=null&&invoice.grand_total!=null){
  const expected=decimal(invoice.taxable_amount).plus(invoice.tax_amount).plus(invoice.other_charges??0).minus(invoice.discount_amount??0);
  const diff=expected.minus(invoice.grand_total);
  add('invoice.arithmetic','Taxable amount + tax + charges − discounts equals payable',expected.toFixed(2),decimal(invoice.grand_total).toFixed(2),diff.abs().lte(tolerance)?'pass':'fail',diff.toFixed(2));
 }
 if(invoice.line_items?.length){
  for(const [i,item] of invoice.line_items.entries()){
   if(item.quantity==null||item.unit_price==null||item.line_total==null){add(`line.${i+1}.arithmetic`,'Line-item values require verification',null,null,'review');continue;}
   const expected=decimal(item.quantity).times(item.unit_price);const diff=expected.minus(item.line_total);
   add(`line.${i+1}.arithmetic`,'Quantity × unit price reconciles to line net amount',expected.toFixed(2),decimal(item.line_total).toFixed(2),diff.abs().lte(tolerance)?'pass':'fail',diff.toFixed(2));
  }
  if(invoice.line_items.every(i=>i.line_total!=null)&&invoice.taxable_amount!=null){const expected=invoice.line_items.reduce((s,i)=>s.plus(i.line_total??0),decimal(0));const diff=expected.minus(invoice.taxable_amount);add('lines.subtotal','Line-item net totals reconcile to taxable amount',expected.toFixed(2),decimal(invoice.taxable_amount).toFixed(2),diff.abs().lte(tolerance)?'pass':'fail',diff.toFixed(2));}
 }
 return rules;
}
export function requireHumanApproval(result:ValidationResult):ValidationResult{
 if(result.status!=='Approved')return result;
 return {...result,status:'Pending Approval',checks:[...result.checks,'All checks passed; independent authorized human approval is required.']};
}