import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type AppRole = Database["public"]["Enums"]["app_role"];

export const ROLE_LABELS: Record<AppRole, string> = {
  admin: "Admin",
  finance_manager: "Finance Manager",
  invoice_processor: "Invoice Processor",
  reviewer: "Reviewer",
  read_only: "Read-only",
};
export const ROLES = Object.keys(ROLE_LABELS) as AppRole[];

export type Membership = { organization_id: string; role: AppRole; organization_name: string };

const ACTIVE_KEY = "smartinvoice.activeOrg";

export const membershipsQuery = (userId: string) => ({
  queryKey: ["memberships", userId],
  queryFn: async (): Promise<Membership[]> => {
    const { data, error } = await supabase
      .from("organization_members")
      .select("organization_id, role, organizations(name)")
      .eq("user_id", userId)
      .order("created_at");
    if (error) throw error;
    return (data ?? []).map((m) => ({
      organization_id: m.organization_id,
      role: m.role,
      organization_name: (m.organizations as { name: string } | null)?.name ?? "Organization",
    }));
  },
});

type OrgCtx = {
  user: User;
  memberships: Membership[];
  active: Membership | null;
  setActive: (id: string) => void;
  loading: boolean;
};
const Ctx = createContext<OrgCtx | null>(null);

export function OrgProvider({ user, children }: { user: User; children: ReactNode }) {
  const q = useQuery(membershipsQuery(user.id));
  const [activeId, setActiveId] = useState<string | null>(null);
  useEffect(() => setActiveId(localStorage.getItem(ACTIVE_KEY)), []);

  const memberships = q.data ?? [];
  const active = useMemo(
    () => memberships.find((m) => m.organization_id === activeId) ?? memberships[0] ?? null,
    [memberships, activeId],
  );
  const value: OrgCtx = {
    user,
    memberships,
    active,
    loading: q.isLoading,
    setActive: (id) => {
      localStorage.setItem(ACTIVE_KEY, id);
      setActiveId(id);
    },
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useOrg() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useOrg must be used inside OrgProvider");
  return v;
}

/** Same-origin relative path only, to avoid open redirects. */
export function safeRedirect(path: unknown): string {
  return typeof path === "string" && path.startsWith("/") && !path.startsWith("//") ? path : "/";
}
