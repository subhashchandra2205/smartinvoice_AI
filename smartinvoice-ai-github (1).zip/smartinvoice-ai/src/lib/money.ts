import Decimal from "decimal.js";
export const decimal = (value: Decimal.Value) => new Decimal(value);
export const money = (value: Decimal.Value) => decimal(value).toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toNumber();
export const sumMoney = (values: Decimal.Value[]) => money(values.reduce<Decimal>((sum, value) => sum.plus(value), decimal(0)));