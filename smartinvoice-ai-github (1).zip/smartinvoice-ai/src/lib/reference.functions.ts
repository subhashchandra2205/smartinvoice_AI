import { createServerFn } from '@tanstack/react-start';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { vendorSchema, poSchema } from './reference';
export const saveVendor = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(vendorSchema).handler(async ({data,context})=>{
 const {data:allowed,error:roleError}=await context.supabase.rpc('has_org_role',{_org:data.organizationId,_user:context.userId,_roles:['admin','finance_manager']});
 if(roleError || !allowed) throw new Error('Only admins and finance managers can manage vendors.');
 const row={name:data.name,gstin:data.gstin||null,email:data.email||null,phone:data.phone||null,address:data.address||null,status:data.status};
 const query=data.id ? context.supabase.from('vendors').update(row).eq('id',data.id).eq('organization_id',data.organizationId) : context.supabase.from('vendors').insert({...row,organization_id:data.organizationId});
 const {data:saved,error}=await query.select('id').single();
 if(error) throw new Error(error.code==='23505'?'A vendor with this name or GSTIN already exists.':'Unable to save vendor. Check your details and permissions.');
 return saved;
});
export const savePurchaseOrder = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(poSchema).handler(async ({data,context})=>{
 const {data:allowed,error:roleError}=await context.supabase.rpc('has_org_role',{_org:data.organizationId,_user:context.userId,_roles:['admin','finance_manager']});
 if(roleError || !allowed) throw new Error('Only admins and finance managers can manage purchase orders.');
 const {data:vendor}=await context.supabase.from('vendors').select('id,status').eq('id',data.vendor_id).eq('organization_id',data.organizationId).single();
 if(!vendor) throw new Error('Vendor not found in this organization.');
 if(!data.id && vendor.status!=='active') throw new Error('Choose an active vendor for a new PO.');
 const row={po_number:data.po_number,vendor_id:data.vendor_id,issued_on:data.issued_on,delivery_date:data.delivery_date||null,amount:data.amount,currency:data.currency,status:data.status,description:data.description||null};
 const query=data.id ? context.supabase.from('purchase_orders').update(row).eq('id',data.id).eq('organization_id',data.organizationId) : context.supabase.from('purchase_orders').insert({...row,organization_id:data.organizationId,created_by:context.userId});
 const {data:saved,error}=await query.select('id').single();
 if(error) throw new Error(error.code==='23505'?'This PO number already exists.':error.message.includes('locked after')?'PO number, vendor and currency cannot change after invoice processing.':'Unable to save purchase order. Check your details and permissions.');
 return saved;
});
