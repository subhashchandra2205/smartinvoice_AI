export const MAX_PDF_BYTES = 20 * 1024 * 1024;
export function verifyPdfEnvelope(bytes: Uint8Array) {
  if (bytes.byteLength > MAX_PDF_BYTES) throw new Error("PDF exceeds 20 MB.");
  const header = new TextDecoder().decode(bytes.subarray(0, 16));
  if (!/^%PDF-(?:1\.[0-7]|2\.0)[\r\n]/.test(header)) throw new Error("The file bytes are not a supported PDF.");
  const tail = new TextDecoder().decode(bytes.subarray(Math.max(0, bytes.length - 2048)));
  const end = tail.match(/startxref\s+(\d+)\s+%%EOF\s*$/);
  if (!end || Number(end[1]) <= 0 || Number(end[1]) >= bytes.length) throw new Error("PDF is corrupted or incomplete (missing valid trailer).");
  const offset = Number(end[1]);
  const xref = new TextDecoder().decode(bytes.subarray(offset, offset + 80));
  if (!/^(?:xref\b|\d+\s+\d+\s+obj\b)/.test(xref)) throw new Error("PDF is corrupted (invalid cross-reference offset).");
}
export function verifiedPdfPath(organizationId: string, hash: string) {
  return `${organizationId}/verified/${hash}.pdf`;
}