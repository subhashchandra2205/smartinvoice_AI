import { z } from 'zod';
import type { Run } from './invoice';
import { taxableAmount, DEFAULT_SETTINGS } from './invoice';
export const orgSchema = z.object({ organizationId: z.string().uuid() });
const optionalText = (max: number) => z.string().trim().max(max).default('');
export const vendorSchema = orgSchema.extend({ id: z.string().uuid().optional(), name: z.string().trim().min(2).max(200).refine(v => /[a-z0-9]/i.test(v), 'Enter a vendor name'), gstin: optionalText(15).transform(v => v.toUpperCase()).refine(v => !v || /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(v), 'Enter a valid GSTIN'), email: optionalText(254).refine(v => !v || z.string().email().safeParse(v).success, 'Enter a valid email'), phone: optionalText(30), address: optionalText(2000), status: z.enum(['active','inactive']) });
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => { const d = new Date(v); return !Number.isNaN(d.getTime()) && d.toISOString().slice(0,10) === v; }, 'Invalid date');
export const poSchema = orgSchema.extend({ id: z.string().uuid().optional(), po_number: z.string().trim().min(2).max(100).transform(v => v.toUpperCase()), vendor_id: z.string().uuid(), issued_on: date, delivery_date: z.union([date,z.literal('')]), amount: z.coerce.number().positive().max(999999999999.99).refine(v => Math.abs(v*100-Math.round(v*100))<0.001,'Use no more than two decimal places'), currency: z.string().trim().regex(/^[A-Za-z]{3}$/).transform(v=>v.toUpperCase()), status: z.enum(['open','closed','cancelled']), description: optionalText(4000) }).refine(v => !v.delivery_date || v.delivery_date >= v.issued_on, { message: 'Delivery date cannot precede PO date', path: ['delivery_date'] });
export function canManageReferences(role: string) { return role === 'admin' || role === 'finance_manager'; }
export function poSpending(poNumber: string, runs: Run[]) {
 const seen = new Set<string>();
 return +runs.reduce((total,run)=> { const key=run.invoice_id ?? `${run.invoice.vendor_name}:${run.invoice.invoice_number ?? run.file_hash}`; if(run.result.status!=='Approved' || run.result.matched_po?.po_number!==poNumber || seen.has(key)) return total; seen.add(key); return total+(run.result.po_balance?.current_taxable ?? run.result.gst_validation?.taxable_amount ?? taxableAmount(run.invoice,DEFAULT_SETTINGS) ?? 0); },0).toFixed(2);
}
