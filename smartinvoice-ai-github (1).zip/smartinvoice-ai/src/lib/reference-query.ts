import { queryOptions } from '@tanstack/react-query';
import { readInvoiceWorkspace } from './invoices.functions';
import { membershipsQuery } from './org';
import type { QueryClient } from '@tanstack/react-query';
export const referenceQuery = (organizationId: string) => queryOptions({queryKey:['reference-records',organizationId],queryFn:()=>readInvoiceWorkspace({data:{organizationId}}),staleTime:10000});
export async function loadReferences(queryClient: QueryClient, userId: string) {
 const memberships=await queryClient.ensureQueryData(membershipsQuery(userId));
 const selected=localStorage.getItem('smartinvoice.activeOrg');
 const active=memberships.find(m=>m.organization_id===selected) ?? memberships[0];
 if(active) await queryClient.ensureQueryData(referenceQuery(active.organization_id));
}
