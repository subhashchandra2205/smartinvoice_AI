// Rule-based invoice extraction + validation (port of the SmartInvoice AI Python prototype).
import { decimal, money } from "./money";
import type { RuleEvidence } from "./production-rules";

export type Status = "Approved" | "Needs Review" | "Pending Approval" | "Rejected";

export interface PurchaseOrder {
  po_number: string;
  vendor_name: string;
  po_amount: number;
  currency: string;
  status: "Open" | "Closed" | "Cancelled";
}

export interface Invoice {
  due_date?: string | null;
  vendor_address?: string | null;
  vendor_email?: string | null;
  vendor_phone?: string | null;
  other_charges?: number | null;
  discount_amount?: number | null;
  line_items?: { description: string; hsn_sac: string | null; quantity: number | null; unit_price: number | null; tax_percentage: number | null; line_total: number | null; source_page: number | null }[];
  field_evidence?: { field: string; value: string | number | null; confidence: number | null; source_page: number | null; verification_status: "extracted" | "uncertain" | "missing" | "corrected" }[];
  gstin?: string | null;
  gst_components?: { cgst: number | null; sgst: number | null; igst: number | null };
  vendor_name: string | null;
  invoice_number: string | null;
  invoice_date: string | null;
  po_number: string | null;
  total_amount: number | null;
  taxable_amount?: number | null;
  grand_total?: number | null;
  amount_source?: "explicit" | "derived" | "ambiguous";
  tax_amount: number | null;
  currency: string;
  confidence: number;
  extraction_method: string;
}

export interface GstResult {
  status: "PASS" | "FAIL" | "REVIEW";
  taxable_amount: number;
  expected_tax: number;
  extracted_tax: number;
  tax_difference: number;
  expected_total: number;
  message: string;
}

export interface ValidationResult {
  evidence?: RuleEvidence[];
  status: Status;
  reasons: string[];
  checks: string[];
  matched_po: PurchaseOrder | null;
  variance_pct: number | null;
  gst_validation: GstResult | null;
  po_candidates?: PurchaseOrder[];
  po_balance?: { previously_approved: number; current_taxable: number; remaining_before: number; remaining_after: number; allowed_total: number } | null;
}

export interface Settings {
  tolerance: number;
  gstRate: number;
  gstBasis: "taxable" | "inclusive";
  gstTolerance: number;
}

export interface Run {
  created_by?: string | null | undefined;
  engine_version?: string | undefined;
  started_at?: string | null | undefined;
  completed_at?: string | null | undefined;
  id: string;
  created_at: string;
  filename: string;
  file_hash: string;
  invoice: Invoice;
  result: ValidationResult;
  raw_text: string;
  file_path?: string | null;
  invoice_id?: string;
  legacy_created_at?: string | null;
}

// Synthetic demonstration PO register (mirrors data/purchase_orders.csv intent).
export const PURCHASE_ORDERS: PurchaseOrder[] = [
  { po_number: "PO-1001", vendor_name: "Acme Supplies Pvt Ltd", po_amount: 50000, currency: "INR", status: "Open" },
  { po_number: "PO-1002", vendor_name: "Bright Office Solutions", po_amount: 18500, currency: "INR", status: "Open" },
  { po_number: "PO-1003", vendor_name: "Nimbus Cloud Services", po_amount: 120000, currency: "INR", status: "Open" },
  { po_number: "PO-1004", vendor_name: "Vertex Logistics", po_amount: 32000, currency: "INR", status: "Closed" },
  { po_number: "PO-1005", vendor_name: "Greenleaf Facilities", po_amount: 7600, currency: "INR", status: "Cancelled" },
  { po_number: "PO-1006", vendor_name: "Acme Supplies Pvt Ltd", po_amount: 25000, currency: "INR", status: "Open" },
];

export const DEFAULT_SETTINGS: Settings = { tolerance: 2, gstRate: 18, gstBasis: "taxable", gstTolerance: 1 };

const num = (s?: string | null) => {
  if (!s) return null;
  const n = parseFloat(s.replace(/[,₹\s]|INR|Rs\.?/gi, ""));
  return Number.isFinite(n) ? n : null;
};

function grab(text: string, patterns: RegExp[]): string | null {
  for (const p of patterns) {
    const m = text.match(p);
    if (m?.[1]) return m[1].trim();
  }
  return null;
}

export function extractFields(text: string, method: string): Invoice {
  const amt = "([₹]?\\s*(?:INR|Rs\\.?)?\\s*[\\d,]+(?:\\.\\d{1,2})?)";
  const vendor = grab(text, [
    /(?:vendor|supplier|seller|from)\s*(?:name)?\s*[:\-]\s*([^\n]+)/i,
    /^\s*([A-Z][A-Za-z&.\s]+(?:Pvt\.?\s*Ltd\.?|Ltd\.?|LLP|Inc\.?|Services|Solutions|Logistics|Supplies|Facilities))\s*$/m,
  ]);
  const invoice_number = grab(text, [/invoice\s*(?:no\.?|number|#|id)\s*[:\-]?\s*([A-Z0-9][A-Z0-9\-\/]+)/i]);
  const invoice_date = grab(text, [/(?:invoice\s*)?date\s*[:\-]?\s*([0-9]{1,4}[\/\-.][0-9]{1,2}[\/\-.][0-9]{1,4}|[0-9]{1,2}\s+[A-Za-z]{3,9}\s+[0-9]{4})/i]);
  const po_number = grab(text, [/(?:p\.?o\.?|purchase\s*order)\s*(?:no\.?|number|#|ref(?:erence)?)?\s*[:\-]\s*([A-Z0-9][A-Z0-9\-\/]*)/i, /(?:p\.?o\.?|purchase\s*order)\s*(?:no\.?|number|#|ref(?:erence)?)?\s*[:\-]?\s*(PO[\-\s]?\d+)/i, /\b(PO-\d{3,})\b/i]);
  const taxable_amount = num(grab(text, [new RegExp(`(?:subtotal|sub\\s*total|taxable\\s*(?:amount|value))\\s*[:\\-]?\\s*${amt}`, "i")]));
  const grand_total = num(grab(text, [new RegExp(`(?:grand\\s*total|invoice\\s*total|amount\\s*due|total\\s*amount)\\s*[:\\-]?\\s*${amt}`, "i")]));
  const ambiguous_amount = num(grab(text, [new RegExp(`^\\s*total\\s*[:\\-]?\\s*${amt}`, "im")]));
  const component = (label: string) => num(grab(text, [new RegExp(`\\b${label}(?:\\s*amount)?\\s*(?:@\\s*\\d+(?:\\.\\d+)?%?)?\\s*[:\\-]?\\s*${amt}`, "i")]));
  const gst_components = { cgst: component("CGST"), sgst: component("SGST"), igst: component("IGST") };
  const explicitTax = num(grab(text, [new RegExp(`\\b(?:total\\s*)?(?:gst|tax)(?:\\s*amount)?\\s*(?:@\\s*\\d+(?:\\.\\d+)?%?)?\\s*[:\\-]?\\s*${amt}`, "i")]));
  const components = Object.values(gst_components).filter((v): v is number => v != null);
  const tax_amount = explicitTax ?? (components.length ? money(components.reduce((a, b) => a.plus(b), decimal(0))) : null);
  const total_amount = grand_total ?? (taxable_amount != null && tax_amount != null ? money(decimal(taxable_amount).plus(tax_amount)) : taxable_amount ?? ambiguous_amount);
  const fields = [vendor, invoice_number, invoice_date, po_number, total_amount, tax_amount];
  return {
    due_date: grab(text, [/due\s*date\s*[:\-]\s*([^\n]+)/i]),
    vendor_address: grab(text, [/(?:vendor|supplier|seller)\s*address\s*[:\-]\s*([^\n]+)/i]),
    vendor_email: grab(text, [/(?:vendor\s*|supplier\s*)?email\s*[:\-]\s*([^\s\n]+@[^\s\n]+)/i]),
    vendor_phone: grab(text, [/(?:vendor\s*|supplier\s*)?(?:phone|contact)\s*[:\-]\s*([^\n]+)/i]),
    other_charges: num(grab(text, [new RegExp(`(?:other\\s*charges|additional\\s*charges|freight)\\s*[:\\-]\\s*${amt}`,"i")])),
    discount_amount: num(grab(text, [new RegExp(`discount(?:\\s*amount)?\\s*[:\\-]\\s*${amt}`,"i")])),
    gstin: grab(text, [/\b(?:supplier\s*|vendor\s*|seller\s*)?GSTIN\s*[:\-]?\s*([0-9]{2}[A-Z0-9]{13})\b/i])?.toUpperCase() ?? null,
    gst_components,
    vendor_name: vendor,
    invoice_number,
    invoice_date,
    po_number: po_number ? po_number.toUpperCase().replace(/\s/, "-") : null,
    total_amount,
    taxable_amount,
    grand_total,
    amount_source: grand_total != null ? "explicit" : taxable_amount != null && tax_amount != null ? "derived" : "ambiguous",
    tax_amount,
    currency: grab(text, [/currency\s*[:\-]\s*([A-Z]{3})\b/i])?.toUpperCase() ?? "INR",
    confidence: fields.filter((f) => f !== null && f !== "").length / fields.length,
    extraction_method: method,
  };
}

export function taxableAmount(inv: Invoice, s: Settings): number | null {
  if (inv.taxable_amount != null) return inv.taxable_amount;
  if (inv.total_amount == null) return null;
  return money(inv.grand_total != null || inv.amount_source === "derived" || s.gstBasis === "inclusive"
    ? decimal(inv.total_amount).div(decimal(s.gstRate).div(100).plus(1)) : inv.total_amount);
}

export function validateGst(inv: Invoice, s: Settings): GstResult | null {
  if (inv.total_amount == null) return null;
  const rate = decimal(s.gstRate).div(100);
  const taxable = taxableAmount(inv, s);
  if (taxable == null) return null;
  const expected_tax = money(decimal(taxable).times(rate));
  const expected_total = money(decimal(taxable).plus(expected_tax));
  if (inv.tax_amount == null) {
    return { status: "REVIEW", taxable_amount: +taxable.toFixed(2), expected_tax, extracted_tax: 0, tax_difference: expected_tax, expected_total, message: "GST amount not found on invoice — verify manually." };
  }
  const difference = decimal(inv.tax_amount).minus(expected_tax).abs();
  const diff = money(difference);
  const pass = difference.lte(s.gstTolerance);
  return {
    status: pass ? "PASS" : "FAIL",
    taxable_amount: +taxable.toFixed(2),
    expected_tax,
    extracted_tax: inv.tax_amount,
    tax_difference: diff,
    expected_total,
    message: pass
      ? `GST at ${s.gstRate}% matches within ₹${s.gstTolerance} tolerance.`
      : `GST differs from expected ${s.gstRate}% by ₹${diff.toFixed(2)} (tolerance ₹${s.gstTolerance}).`,
  };
}

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");

export function validateInvoice(inv: Invoice, history: Run[], s: Settings, fileHash: string, purchaseOrders: PurchaseOrder[] = PURCHASE_ORDERS): ValidationResult {
  const reasons: string[] = [];
  const checks: string[] = [];
  let rejected = false;
  let review = false;

  if (history.some((r) => r.file_hash === fileHash)) {
    reasons.push("Duplicate file: this exact PDF was processed before.");
    rejected = true;
  } else if (inv.vendor_name && inv.invoice_number && history.some((r) => norm(r.invoice.invoice_number ?? "") === norm(inv.invoice_number ?? "") && norm(r.invoice.vendor_name ?? "") === norm(inv.vendor_name ?? ""))) {
    reasons.push(`Duplicate invoice: ${inv.invoice_number} from this vendor already exists.`);
    rejected = true;
  } else checks.push("No duplicate file or invoice identity found.");

  const missing = (["vendor_name", "invoice_number", "invoice_date", "po_number", "total_amount"] as const).filter((k) => inv[k] == null || inv[k] === "");
  if (missing.length) {
    reasons.push(`Missing required fields: ${missing.join(", ")}.`);
    review = true;
  } else checks.push("All required fields extracted.");

  if (inv.extraction_method === "No readable text") {
    reasons.push("No readable PDF text layer. Scanned or image-only invoice requires OCR or manual review; no payment approval issued.");
    review = true;
  }
  if (inv.amount_source === "ambiguous") {
    reasons.push("Amount basis is ambiguous: subtotal and grand total are not clearly identified. Verify manually."); review = true;
  }
  if (inv.total_amount != null && inv.total_amount <= 0) { reasons.push("Invoice amount must be positive."); review = true; }
  if (inv.taxable_amount != null && inv.grand_total != null && inv.tax_amount != null) {
    const difference = decimal(inv.taxable_amount).plus(inv.tax_amount).plus(inv.other_charges??0).minus(inv.discount_amount??0).minus(inv.grand_total).abs();
    if (difference.gt(s.gstTolerance)) { reasons.push(`Subtotal plus tax differs from grand total by ${inr(money(difference))}.`); review = true; }
    else checks.push("Subtotal plus tax reconciles to grand total.");
  }

  const po = inv.po_number ? purchaseOrders.find((p) => p.po_number === inv.po_number) ?? null : null;
  const candidates = !po && inv.vendor_name ? purchaseOrders.filter((p) => p.status === "Open" && norm(p.vendor_name) === norm(inv.vendor_name ?? "")) : [];
  if (candidates.length) reasons.push(`${candidates.length} possible PO match${candidates.length > 1 ? "es" : ""} for this vendor. Confirm the PO reference; no match was selected automatically.`);
  let variance: number | null = null;
  let balance: ValidationResult["po_balance"] = null;
  if (inv.po_number && !po) { reasons.push(`PO ${inv.po_number} not found in register.`); review = true; }
  if (po) {
    checks.push(`Matched purchase order ${po.po_number}.`);
    if (po.status === "Cancelled") { reasons.push(`PO ${po.po_number} is cancelled.`); rejected = true; }
    else if (po.status === "Closed") { reasons.push(`PO ${po.po_number} is closed.`); review = true; }
    else checks.push("PO status is open.");
    if (inv.vendor_name && !norm(po.vendor_name).includes(norm(inv.vendor_name)) && !norm(inv.vendor_name).includes(norm(po.vendor_name))) {
      reasons.push(`Vendor mismatch: invoice "${inv.vendor_name}" vs PO "${po.vendor_name}".`); review = true;
    } else if (inv.vendor_name) checks.push("Vendor matches PO.");
    const current = taxableAmount(inv, s);
    if (current != null && po.po_amount) {
      const seen = new Set<string>();
      const previous = history.filter((r) => {
        const identity = `${norm(r.invoice.vendor_name ?? "")}:${norm(r.invoice.invoice_number ?? r.file_hash)}`;
        if (r.result.status !== "Approved" || r.result.matched_po?.po_number !== po.po_number || seen.has(identity)) return false;
        seen.add(identity); return true;
      }).reduce((sum, r) => sum.plus(r.result.po_balance?.current_taxable ?? r.result.gst_validation?.taxable_amount ?? taxableAmount(r.invoice, s) ?? 0), decimal(0));
      const cumulative = previous.plus(current);
      const allowed = decimal(po.po_amount).times(decimal(s.tolerance).div(100).plus(1)).toDecimalPlaces(2);
      balance = { previously_approved: money(previous), current_taxable: current, remaining_before: money(decimal(po.po_amount).minus(previous)), remaining_after: money(decimal(po.po_amount).minus(cumulative)), allowed_total: money(allowed) };
      variance = decimal(cumulative.minus(po.po_amount).gt(0)?cumulative.minus(po.po_amount):0).div(po.po_amount).times(100).toDecimalPlaces(4).toNumber();
      if (cumulative.gt(allowed)) { reasons.push(`Cumulative taxable spend ${inr(money(cumulative))} exceeds PO allowance ${inr(money(allowed))} (${s.tolerance}% tolerance).`); review = true; }
      else checks.push(`Cumulative taxable spend ${inr(money(cumulative))} is within PO allowance ${inr(money(allowed))}. Remaining balance: ${inr(balance.remaining_after)}.`);
    }
  }

  const gst = validateGst(inv, s);
  if (gst?.status === "PASS") checks.push(gst.message);
  else if (gst) { reasons.push(gst.message); review = true; }

  const status: Status = rejected ? "Rejected" : review ? "Needs Review" : "Approved";
  return { status, reasons, checks, matched_po: po, variance_pct: variance, gst_validation: gst, po_candidates: candidates, po_balance: balance };
}

export async function sha256(buf: ArrayBuffer) {
  const h = await crypto.subtle.digest("SHA-256", buf);
  return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function extractPdfText(buf: ArrayBuffer): Promise<string> {
  const pdfjs = await import("pdfjs-dist");
  const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  const doc = await pdfjs.getDocument({ data: buf }).promise;
  const pages: string[] = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const c = await (await doc.getPage(i)).getTextContent();
    let line = "", out = "", lastY: number | null = null;
    for (const it of c.items as { str: string; transform: number[] }[]) {
      const y = it.transform[5] ?? 0;
      if (lastY !== null && Math.abs(y - lastY) > 2) { out += line.trim() + "\n"; line = ""; }
      line += it.str + " ";
      lastY = y;
    }
    pages.push(out + line.trim());
  }
  return pages.join("\n\n");
}

export const inr = (n: number | null | undefined) =>
  n == null ? "—" : "₹" + n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
