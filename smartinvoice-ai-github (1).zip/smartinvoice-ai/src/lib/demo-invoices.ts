export interface DemoInvoice { filename: string; text: string; scanned?: boolean }
const invoice = (id: string, subtotal: number, po: string | null = "PO-1001") => `Vendor: Acme Supplies Pvt Ltd\nInvoice number: ${id}\nInvoice date: 09/11/2026\n${po ? `PO number: ${po}\n` : ""}Subtotal: ${subtotal}\nGST: ${(subtotal * .18).toFixed(2)}\nGrand total: ${(subtotal * 1.18).toFixed(2)}`;
export const DEMO_CASES: { title: string; expected: string; files: DemoInvoice[] }[] = [
  { title: "Duplicate identity", expected: "Approved → Rejected", files: [
    { filename: "duplicate-original.pdf", text: invoice("DEMO-DUP", 20000) },
    { filename: "duplicate-reissued.pdf", text: invoice("DEMO-DUP", 20000) + "\nReissued copy - same invoice identity" },
  ] },
  { title: "Split PO spending", expected: "Approved → Approved → Needs Review", files: [
    { filename: "split-first.pdf", text: invoice("DEMO-SPLIT-1", 20000) },
    { filename: "split-second.pdf", text: invoice("DEMO-SPLIT-2", 30000) },
    { filename: "split-over-limit.pdf", text: invoice("DEMO-SPLIT-3", 2000) },
  ] },
  { title: "Missing PO reference", expected: "Needs Review · two possible POs", files: [
    { filename: "missing-po.pdf", text: invoice("DEMO-NO-PO", 20000, null) },
  ] },
  { title: "Tax-inclusive boundary", expected: "At 2%: Approved · above 2%: Needs Review", files: [
    { filename: "inclusive-at-limit.pdf", text: "Vendor: Acme Supplies Pvt Ltd\nInvoice number: DEMO-INC-1\nInvoice date: 09/11/2026\nPO: PO-1001\nGST: 9180\nGrand total: 60180" },
    { filename: "inclusive-over-limit.pdf", text: "Vendor: Acme Supplies Pvt Ltd\nInvoice number: DEMO-INC-2\nInvoice date: 09/11/2026\nPO: PO-1001\nGST: 9180.18\nGrand total: 60181.18" },
  ] },
];
export const SCANNED_SAMPLE: DemoInvoice = { filename: "scanned-invoice.pdf", text: invoice("DEMO-SCAN", 20000), scanned: true };

export async function downloadDemoInvoice(sample: DemoInvoice) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF();
  if (sample.scanned) {
    const canvas = document.createElement("canvas"); canvas.width = 1000; canvas.height = 700;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Unable to create sample invoice.");
    ctx.fillStyle = "white"; ctx.fillRect(0, 0, 1000, 700);
    ctx.fillStyle = "black"; ctx.font = "26px monospace";
    sample.text.split("\n").forEach((line, i) => ctx.fillText(line, 40, 70 + i * 48));
    doc.addImage(canvas.toDataURL("image/png"), "PNG", 15, 20, 180, 126);
  } else {
    doc.setFont("courier"); doc.setFontSize(12); doc.text(sample.text, 20, 25);
  }
  doc.save(sample.filename);
}