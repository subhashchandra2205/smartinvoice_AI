import { unzipSync, strFromU8 } from 'fflate';
import { sha256 } from './invoice';
import { MAX_PDF_BYTES, verifyPdfEnvelope } from './pdf-verification';

export const BACKUP_MAX_BYTES = 100 * 1024 * 1024;
export type BackupFile = { path: string; sha256: string; invoiceIds: string[]; runIds: string[] };
export type BackupManifest = { version: 1; organizationId: string; createdAt: string; files: BackupFile[] };
export function assertBackupPath(org: string, path: string) {
  if (!path.startsWith(`${org}/`) || path.includes('..') || path.includes('\\') || path.includes('//')) throw new Error('Backup contains an invalid organization PDF path.');
}
export async function verifyBackupArchive(bytes: Uint8Array, organizationId: string): Promise<BackupManifest> {
  if (bytes.length > BACKUP_MAX_BYTES) throw new Error('Backup exceeds 100 MB.');
  let expanded = 0;
  const archive = unzipSync(bytes, { filter: entry => {
    expanded += entry.originalSize;
    if (expanded > BACKUP_MAX_BYTES || entry.originalSize > (entry.name === 'manifest.json' ? 1024 * 1024 : MAX_PDF_BYTES)) throw new Error('Backup expanded size exceeds the safe limit.');
    return true;
  }});
  const raw = archive['manifest.json'];
  if (!raw) throw new Error('Backup manifest is missing.');
  const manifest = JSON.parse(strFromU8(raw)) as BackupManifest;
  if (manifest.version !== 1 || manifest.organizationId !== organizationId || !Array.isArray(manifest.files) || manifest.files.length > 200) throw new Error('Backup does not belong to this organization.');
  const seen = new Set<string>();
  for (const file of manifest.files) {
    assertBackupPath(organizationId, file.path);
    if (seen.has(file.path) || !/^[a-f0-9]{64}$/.test(file.sha256)) throw new Error('Backup manifest is invalid.');
    seen.add(file.path);
    const pdf = archive[file.path];
    if (!pdf) throw new Error('A PDF listed in the backup is missing.');
    verifyPdfEnvelope(pdf);
    if (await sha256(pdf.slice().buffer) !== file.sha256) throw new Error('PDF checksum does not match the backup manifest.');
  }
  if (Object.keys(archive).some(path => path !== 'manifest.json' && !seen.has(path))) throw new Error('Backup contains unlisted files.');
  return manifest;
}