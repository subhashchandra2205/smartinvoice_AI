import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { extractFields, sha256, type Run, type ValidationResult } from "./invoice";
import { cloudRuns, validateCloudInvoice, invoiceDate, type CloudState } from "./cloud-invoice";
import type { Json } from "@/integrations/supabase/types";
import { MAX_PDF_BYTES, verifiedPdfPath } from "./pdf-verification";
import { financialEvidence, requireHumanApproval } from "./production-rules";
import {historyQuery,historyArguments} from './history-query';
export const readInvoiceHistory=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(historyQuery).handler(async({data,context})=>{const {data:result,error}=await context.supabase.rpc('read_invoice_history',historyArguments(data));if(error)throw new Error('Unable to load invoice history.');return result as unknown as {total:number;runs:CloudState['runs'];counts:Record<string,number>;vendors:string[]};});
export const readInvoiceDetail=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({organizationId:z.string().uuid(),runId:z.string().uuid()})).handler(async({data,context})=>{const {data:row,error}=await context.supabase.from('processing_runs').select('*').eq('organization_id',data.organizationId).eq('id',data.runId).single();if(error||!row)throw new Error('Invoice not found.');return cloudRuns({revision:'',vendors:[],purchase_orders:[],invoices:[],runs:[row as unknown as CloudState['runs'][number]]})[0];});
const orgInput = z.object({ organizationId: z.string().uuid() });
export const readReportSummary=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(orgInput.extend({from:z.string().default(''),to:z.string().default(''),view:z.string().default('Invoice summary')})).handler(async({data,context})=>{const {data:summary,error}=await context.supabase.rpc('invoice_report_summary',{_org:data.organizationId,_from:data.from,_to:data.to,_view:data.view});if(error)throw new Error('Reports unavailable.');return summary as unknown as {processed:number;approved:number;pending:number;rejected:number;currencyTotals:Record<string,number>;groups:{label:string;currency:string;count:number;value:number}[];recent:CloudState['runs']};});
const settingsSchema = z.object({ tolerance: z.number().min(0).max(10), gstRate: z.number().min(0).max(100), gstBasis: z.enum(["taxable", "inclusive"]), gstTolerance: z.number().min(0).max(1000000) });
export const readInvoicePolicy=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(orgInput).handler(async({data,context})=>{const {data:org,error}=await context.supabase.from('organizations').select('invoice_policy,policy_version').eq('id',data.organizationId).single();if(error||!org)throw new Error('Unable to read organization rules.');return {settings:settingsSchema.parse(org.invoice_policy),version:org.policy_version};});
export const saveInvoicePolicy=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(orgInput.extend({settings:settingsSchema})).handler(async({data,context})=>{const {error}=await context.supabase.rpc('save_invoice_policy',{_org:data.organizationId,_policy:{...data.settings,requireHumanApproval:true}});if(error)throw new Error('Only authorized finance managers and admins can save valid organization rules.');});
export const readInvoiceWorkspace = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator(orgInput).handler(async ({ data, context }) => {
 const { data: state, error } = await context.supabase.rpc("get_cloud_invoice_state", { _org: data.organizationId });
 if (error) throw new Error("Unable to load organization invoice records.");
 return state as unknown as CloudState;
});
export const uploadCloudPdf = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input: FormData) => {
 if (!(input instanceof FormData)) throw new Error("Invalid PDF upload.");
 return input;
}).handler(async ({ data, context }) => {
 const organizationId = z.string().uuid().parse(data.get("organizationId"));
 const { data: permitted } = await context.supabase.rpc("has_org_role", { _org: organizationId, _user: context.userId, _roles: ["admin", "finance_manager", "invoice_processor"] });
 if (!permitted) throw new Error("Your role cannot upload invoices to this organization.");
 const file = data.get("pdf");
 if (!(file instanceof Blob) || file.size === 0) throw new Error("Select a nonempty PDF.");
 if (file.size > MAX_PDF_BYTES) throw new Error("PDF exceeds 20 MB.");
 const buffer = await file.arrayBuffer();
 const { extractVerifiedPdf } = await import("./pdf-extraction.server");
 // Parse before storage: even a renamed file with a forged header cannot be uploaded.
 const extraction=await extractVerifiedPdf(buffer.slice(0));
 const hash = await sha256(buffer);
 const filePath = verifiedPdfPath(organizationId, hash);
 const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
 const {data:existingJob}=await context.supabase.from('invoice_processing_jobs').select('id,status').eq('organization_id',organizationId).eq('file_hash',hash).maybeSingle();
 if(existingJob)return {filePath,filename:`invoice-${hash.slice(0,12)}.pdf`,reused:true,operationKey:existingJob.id};
 const { data: previous } = await context.supabase.from("invoices").select("id").eq("organization_id", organizationId).eq("file_sha256", hash).limit(1);
 if (previous?.length) throw new Error("Duplicate PDF: this exact file has already been processed.");
 const { error } = await supabaseAdmin.storage.from("invoice-pdfs").upload(filePath, buffer, { contentType: "application/pdf", upsert: false });
 if (error && !error.message.toLowerCase().includes("already exists")) throw new Error("Private PDF upload failed. Please retry.");
 const {data:job,error:jobError}=await supabaseAdmin.from('invoice_processing_jobs').insert({organization_id:organizationId,file_hash:hash,file_path:filePath,uploaded_by:context.userId,extraction:JSON.parse(JSON.stringify(extraction)) as Json}).select('id').single();
 if(jobError){const {data:winner}=await context.supabase.from('invoice_processing_jobs').select('id').eq('organization_id',organizationId).eq('file_hash',hash).maybeSingle();if(winner)return {filePath,filename:`invoice-${hash.slice(0,12)}.pdf`,reused:true,operationKey:winner.id};throw new Error('Verified upload retained; processing registration failed. Retry this PDF safely.');}
 return { filePath, filename: `invoice-${hash.slice(0, 12)}.pdf`, reused: false,operationKey:job.id };
});
export const inspectCloudPdf = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator(orgInput.extend({ filePath: z.string().max(500) })).handler(async ({ data, context }) => {
 const { data: permitted } = await context.supabase.rpc("has_org_role", { _org: data.organizationId, _user: context.userId, _roles: ["admin", "finance_manager", "invoice_processor"] });
 if (!permitted || !data.filePath.startsWith(`${data.organizationId}/`)) throw new Error("You cannot extract this organization PDF.");
 const { data: pdf, error } = await context.supabase.storage.from("invoice-pdfs").download(data.filePath);
 if (error || !pdf) throw new Error("Unable to read the private PDF.");
 if (pdf.size > MAX_PDF_BYTES) throw new Error("PDF exceeds 20 MB.");
 const { extractVerifiedPdf } = await import("./pdf-extraction.server");
 return extractVerifiedPdf(await pdf.arrayBuffer());
});
const processInput=orgInput.extend({ operationKey:z.string().uuid().optional(), filePath:z.string().max(500).nullable(), filename:z.string().min(1).max(300), rawText:z.string().max(1000000).optional(), settings:settingsSchema, legacy:z.object({ id:z.string().uuid(), created_at:z.string().datetime(), file_hash:z.string().regex(/^[a-f0-9]{64}$/), invoice:z.unknown(), result:z.unknown() }).optional() });
export const processCloudInvoice=createServerFn({ method:"POST" }).middleware([requireSupabaseAuth]).inputValidator(processInput).handler(async ({data,context})=>{
 const {data: permitted}=await context.supabase.rpc("has_org_role",{_org:data.organizationId,_user:context.userId,_roles:["admin","finance_manager","invoice_processor"]});
 if(!permitted) throw new Error("Your role cannot process invoices.");
 const startedAt=new Date().toISOString();
 const {data:org,error:policyError}=await context.supabase.from('organizations').select('invoice_policy,policy_version').eq('id',data.organizationId).single();
 if(policyError||!org)throw new Error('Organization validation rules are unavailable.');
 const settings=settingsSchema.parse(org.invoice_policy);
 const {supabaseAdmin}=await import("@/integrations/supabase/client.server");
 if(data.operationKey){const {data:previous}=await context.supabase.from('processing_runs').select('id').eq('organization_id',data.organizationId).eq('operation_key',data.operationKey).maybeSingle();if(previous){const {data:state}=await context.supabase.rpc('get_cloud_invoice_state',{_org:data.organizationId});const saved=cloudRuns(state as unknown as CloudState).find(r=>r.id===previous.id);if(saved)return saved;}}
 if(data.operationKey){const {error}=await supabaseAdmin.rpc('claim_invoice_job',{_org:data.organizationId,_job:data.operationKey,_actor:context.userId});if(error)throw new Error(error.code==='P0001'?error.message:'Processing job could not be claimed.');}
 try {
 let hash=data.legacy?.file_hash ?? "", size:number|null=null;
 let rawText=data.legacy ? data.rawText ?? "" : "";
 let extraction: Awaited<ReturnType<typeof import("./pdf-extraction.server").extractVerifiedPdf>> | null = null;
 let filename = data.filename;
 if(!data.legacy){
  if(!data.filePath?.startsWith(`${data.organizationId}/`)) throw new Error("Invalid organization PDF path.");
  const {data:pdf,error}=await context.supabase.storage.from("invoice-pdfs").download(data.filePath);
  if(error || !pdf) throw new Error("Unable to read the private PDF.");
  size=pdf.size; if(size>20971520) throw new Error("PDF exceeds 20 MB.");
  const buffer=await pdf.arrayBuffer();
  hash=await sha256(buffer);
  const { extractVerifiedPdf } = await import("./pdf-extraction.server");
  const {data:job}=await context.supabase.from('invoice_processing_jobs').select('extraction').eq('organization_id',data.organizationId).eq('file_hash',hash).maybeSingle();
  const cached=job?.extraction as unknown as Awaited<ReturnType<typeof extractVerifiedPdf>> | null;
  extraction = cached && !cached.ocrRequired ? cached : await extractVerifiedPdf(buffer,{ocr:true});
  if(data.operationKey)await supabaseAdmin.from('invoice_processing_jobs').update({extraction:JSON.parse(JSON.stringify(extraction)) as Json}).eq('organization_id',data.organizationId).eq('id',data.operationKey);
  rawText = extraction.rawText;
  filename = `invoice-${hash.slice(0, 12)}.pdf`;
 }
 for(let attempt=0;attempt<4;attempt++){
  const {data:raw,error}=await context.supabase.rpc("get_cloud_invoice_state",{_org:data.organizationId});
  if(error) throw new Error("Unable to load organization validation data.");
  const state=raw as unknown as CloudState, history=cloudRuns(state);
  const invoice=extraction?.invoice ?? extractFields(rawText,rawText.trim()?"Legacy unverified text":"No readable text");
  let displayResult=validateCloudInvoice(invoice,state,settings,hash);
  if(!data.legacy){displayResult.evidence=financialEvidence(invoice,settings.gstTolerance,new Date().toISOString());if(displayResult.evidence.some(e=>e.result!=='pass')&&displayResult.status!=='Rejected'){displayResult.status='Needs Review';displayResult.reasons.push(...displayResult.evidence.filter(e=>e.result!=='pass').map(e=>e.description));}displayResult=requireHumanApproval(displayResult);}
  if (extraction?.ocrRequired && displayResult.status !== "Rejected") {
   displayResult.status = "Needs Review";
   displayResult.reasons.push(`Pages ${extraction.unreadablePages.join(", ")} still require OCR or manual review.`);
  }
  if(extraction?.ocrPages.some(p=>p.confidence<.9)&&displayResult.status!=='Rejected'){displayResult.status='Needs Review';displayResult.reasons.push('OCR confidence is below 90%; independent verification is required.');}
  if (!data.legacy && !invoice.currency && displayResult.status !== "Rejected") { displayResult.status="Needs Review"; displayResult.reasons.push("Currency is not explicitly identified. Verify manually."); }
  const run:Run={id:"",created_at:"",filename,file_hash:hash,file_path:data.filePath,invoice,result:displayResult,raw_text:rawText};
  if(data.legacy){ run.result.status="Needs Review"; run.result.reasons.unshift("Imported from device history; original PDF unavailable and prior decision is untrusted. Human verification required."); }
  const payload={invoice:run.invoice,result:run.result,settings:{...settings,policy_version:org.policy_version,requireHumanApproval:true},operation_key:data.operationKey,started_at:startedAt,raw_text:rawText,file_path:data.filePath,filename,file_hash:hash,file_size:size,invoice_date:invoiceDate(invoice.invoice_date),legacy_id:data.legacy?.id,legacy_created_at:data.legacy?.created_at,extraction_metadata:extraction ? { extractor: extraction.extractor, page_count: extraction.pageCount, ocr_required: extraction.ocrRequired, unreadable_pages: extraction.unreadablePages,ocr_pages:extraction.ocrPages.map(p=>({page:p.page,confidence:p.confidence})),sha256: hash, verified_bytes: size } : undefined};
  const {data:saved,error:saveError}=await supabaseAdmin.rpc("commit_cloud_invoice",{_org:data.organizationId,_actor:context.userId,_revision:state.revision,_payload:JSON.parse(JSON.stringify(payload)) as Json});
  if(saveError) throw new Error(saveError.code==='P0001'?saveError.message:"Invoice could not be saved. No decision was committed; please retry.");
  const commit=saved as unknown as {retry?:boolean;id:string;created_at?:string;already_imported?:boolean;result?:ValidationResult};
  if(commit.retry) continue;
  if(data.legacy){
   const {error:evidenceError}=await supabaseAdmin.rpc("retain_legacy_invoice_evidence",{_org:data.organizationId,_run:commit.id,_evidence:JSON.parse(JSON.stringify({...data.legacy,filename:data.filename,raw_text:data.rawText})) as Json});
   if(evidenceError)throw new Error("The record was imported, but its original evidence could not be retained. Retry safely.");
  }
  if(commit.already_imported){const previous=history.find(r=>r.id===commit.id);if(previous)return previous;}
  return {...run,result:commit.result??run.result,id:commit.id,created_at:commit.created_at??new Date().toISOString()};
 }
 throw new Error("Organization records changed during processing. Please retry.");
 } catch(error){if(data.operationKey)await supabaseAdmin.from('invoice_processing_jobs').update({status:'failed',lease_until:null,error_message:error instanceof Error?error.message:'Invoice processing failed'}).eq('organization_id',data.organizationId).eq('id',data.operationKey).neq('status','completed');throw error;}
});
export const approveCloudInvoice=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(orgInput.extend({runId:z.string().uuid(),note:z.string().trim().min(3).max(2000)})).handler(async({data,context})=>{
 const {data:allowed}=await context.supabase.rpc('has_org_role',{_org:data.organizationId,_user:context.userId,_roles:['admin','finance_manager','reviewer']});
 if(!allowed)throw new Error('Your role cannot approve invoices.');
 const {data:approved,error}=await context.supabase.rpc('approve_invoice',{_org:data.organizationId,_run:data.runId,_note:data.note});
 if(error)throw new Error(error.code==='P0001'?error.message:'Approval failed. No balance or decision was changed.');
 return approved;
});
export const rejectCloudInvoice=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(orgInput.extend({runId:z.string().uuid(),note:z.string().trim().min(3).max(2000)})).handler(async({data,context})=>{const {data:result,error}=await context.supabase.rpc('reject_invoice',{_org:data.organizationId,_run:data.runId,_note:data.note});if(error)throw new Error(error.code==='P0001'?error.message:'Invoice rejection failed.');return result;});
export const correctInvoice=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(orgInput.extend({runId:z.string().uuid(),note:z.string().trim().min(3).max(2000),fields:z.object({vendor_name:z.string().trim().min(2).max(300),invoice_number:z.string().trim().min(1).max(100),po_number:z.string().trim().min(1).max(100),gstin:z.string().trim().max(15),taxable_amount:z.number().nonnegative(),tax_amount:z.number().nonnegative(),grand_total:z.number().positive(),currency:z.string().regex(/^[A-Z]{3}$/)})})).handler(async({data,context})=>{const {data:allowed}=await context.supabase.rpc('has_org_role',{_org:data.organizationId,_user:context.userId,_roles:['admin','finance_manager','invoice_processor']});if(!allowed)throw new Error('Your role cannot correct invoice fields.');const {data:raw,error}=await context.supabase.rpc('get_cloud_invoice_state',{_org:data.organizationId});if(error)throw new Error('Invoice workspace unavailable.');const state=raw as unknown as CloudState;const run=cloudRuns(state).find(r=>r.id===data.runId);if(!run)throw new Error('Invoice not found.');const {data:org}=await context.supabase.from('organizations').select('invoice_policy').eq('id',data.organizationId).single();const policy=settingsSchema.parse(org?.invoice_policy);const invoice={...run.invoice,...data.fields,total_amount:data.fields.grand_total};const otherHistory={...state,runs:state.runs.filter(r=>r.invoice_id!==run.invoice_id),invoices:state.invoices.filter(i=>i.id!==run.invoice_id)};let result=validateCloudInvoice(invoice,otherHistory,policy,'correction-new');result.evidence=financialEvidence(invoice,policy.gstTolerance,new Date().toISOString());if(result.evidence.some(e=>e.result!=='pass'))result.status='Needs Review';result=requireHumanApproval(result);if(result.status==='Rejected')throw new Error('Corrected invoice has a blocking duplicate or cancelled PO.');const {supabaseAdmin}=await import('@/integrations/supabase/client.server');const {data:id,error:saveError}=await supabaseAdmin.rpc('commit_invoice_correction',{_org:data.organizationId,_actor:context.userId,_run:data.runId,_invoice:JSON.parse(JSON.stringify(invoice)) as Json,_result:JSON.parse(JSON.stringify(result)) as Json,_note:data.note,_policy:policy});if(saveError)throw new Error(saveError.code==='P0001'?saveError.message:'Correction could not be saved.');return id;});
