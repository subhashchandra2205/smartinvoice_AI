import { useEffect, useState, useCallback } from "react";
import { DEFAULT_SETTINGS, type Run, type Settings } from "./invoice";

const RUNS = "smartinvoice.runs";
const SETTINGS = "smartinvoice.settings";
const EVT = "smartinvoice:change";

function read<T>(k: string, d: T): T {
  try { const v = localStorage.getItem(k); return v ? { ...(d as object), ...JSON.parse(v) } as T : d; } catch { return d; }
}

export function getRuns(): Run[] {
  try { return JSON.parse(localStorage.getItem(RUNS) || "[]"); } catch { return []; }
}
export function saveRun(r: Run) {
  localStorage.setItem(RUNS, JSON.stringify([r, ...getRuns()]));
  window.dispatchEvent(new Event(EVT));
}
export function clearRuns() {
  localStorage.removeItem(RUNS);
  window.dispatchEvent(new Event(EVT));
}

export function useRuns() {
  const [runs, setRuns] = useState<Run[]>([]);
  useEffect(() => {
    const f = () => setRuns(getRuns());
    f();
    window.addEventListener(EVT, f);
    return () => window.removeEventListener(EVT, f);
  }, []);
  return runs;
}

export function useSettings() {
  const [s, setS] = useState<Settings>(DEFAULT_SETTINGS);
  useEffect(() => {
    const f = () => setS(read(SETTINGS, DEFAULT_SETTINGS));
    f();
    window.addEventListener(EVT, f);
    return () => window.removeEventListener(EVT, f);
  }, []);
  const update = useCallback((p: Partial<Settings>) => {
    const next = { ...read(SETTINGS, DEFAULT_SETTINGS), ...p };
    localStorage.setItem(SETTINGS, JSON.stringify(next));
    window.dispatchEvent(new Event(EVT));
  }, []);
  return [s, update] as const;
}
