import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { assertBackupPath, type BackupFile } from './pdf-backup';

export const readPdfBackupPage = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ organizationId: z.string().uuid(), page: z.number().int().min(1).max(1000000) }))
  .handler(async ({ data, context }) => {
    const { data: allowed, error: roleError } = await context.supabase.rpc('has_org_role', { _org: data.organizationId, _user: context.userId, _roles: ['admin'] });
    if (roleError || !allowed) throw new Error('Only organization administrators can back up PDFs.');
    const start = (data.page - 1) * 25;
    const [runs, jobs] = await Promise.all([
      context.supabase.from('processing_runs').select('id,invoice_id,source_file_path,source_file_sha256', { count: 'exact' }).eq('organization_id', data.organizationId).not('source_file_path', 'is', null).order('created_at').order('id').range(start, start + 24),
      context.supabase.from('invoice_processing_jobs').select('file_path,file_hash', { count: 'exact' }).eq('organization_id', data.organizationId).order('created_at').order('id').range(start, start + 24),
    ]);
    if (runs.error || jobs.error) throw new Error('Unable to list PDF backup records.');
    const files = new Map<string, BackupFile>();
    for (const run of runs.data ?? []) {
      if (!run.source_file_path) continue;
      assertBackupPath(data.organizationId, run.source_file_path);
      const entry = files.get(run.source_file_path) ?? { path: run.source_file_path, sha256: run.source_file_sha256 ?? '', invoiceIds: [], runIds: [] };
      entry.runIds.push(run.id);
      if (run.invoice_id && !entry.invoiceIds.includes(run.invoice_id)) entry.invoiceIds.push(run.invoice_id);
      files.set(entry.path, entry);
    }
    for (const job of jobs.data ?? []) {
      assertBackupPath(data.organizationId, job.file_path);
      if (!files.has(job.file_path)) files.set(job.file_path, { path: job.file_path, sha256: job.file_hash, invoiceIds: [], runIds: [] });
    }
    return { files: [...files.values()], pages: Math.max(1, Math.ceil(Math.max(runs.count ?? 0, jobs.count ?? 0) / 25)) };
  });