import { validateInvoice, type Invoice, type PurchaseOrder, type Run, type ValidationResult, type Settings } from "./invoice";
export interface CloudState {
 revision: string;
 vendors: { id: string; name: string; normalized_name: string | null; gstin?: string | null; email?: string | null; phone?: string | null; address?: string | null; status?: string; created_at?: string }[];
 purchase_orders: { id: string; vendor_id: string; po_number: string; amount: number; currency: string; status: string; issued_on?: string | null; delivery_date?: string | null; description?: string | null; created_at?: string }[];
 invoices: { id: string; file_name: string | null; file_path: string | null; file_sha256: string | null }[];
 runs: { id: string; invoice_id: string; created_at: string; created_by?:string|null;engine_version?:string;started_at?:string|null;completed_at?:string|null;extracted_fields: Invoice; result_snapshot: ValidationResult | null; raw_text: string | null; source_filename: string | null; source_file_path: string | null; source_file_sha256: string | null; legacy_created_at: string | null }[];
}
export const normalizeVendor = (name: string) => name.toLowerCase().replace(/\b(pvt|private|ltd|limited|llp|llc|inc|co|company|corp|corporation|the)\b/g, "").replace(/[^a-z0-9]/g, "");
export function validateCloudInvoice(invoice: Invoice, state: CloudState, settings: Settings, hash: string) {
 const vendor=state.vendors.find(v=>v.normalized_name===normalizeVendor(invoice.vendor_name??'') || normalizeVendor(v.name)===normalizeVendor(invoice.vendor_name??''));
 const orders=cloudOrders(state);
 const po=orders.find(p=>p.po_number.trim().toUpperCase()===invoice.po_number?.trim().toUpperCase());
 // Only an explicit reference selects a PO; multiple vendor POs must never be guessed.
 const matchedInvoice={...invoice,po_number:po?.po_number ?? invoice.po_number,vendor_name:invoice.vendor_name ? normalizeVendor(invoice.vendor_name) : null};
 const history=cloudRuns(state).map(r=>({...r,invoice:{...r.invoice,vendor_name:normalizeVendor(r.invoice.vendor_name??'')}}));
 const result=validateInvoice(matchedInvoice,history,settings,hash,orders.map(p=>({...p,vendor_name:normalizeVendor(p.vendor_name)})));
 result.matched_po=po ?? null;
 result.po_candidates=orders.filter(p=>result.po_candidates?.some(c=>c.po_number===p.po_number));
 const flag=(reason:string)=>{result.reasons.push(reason);if(result.status!=='Rejected')result.status='Needs Review';};
 if(!vendor)flag('Invoice vendor not found in this organization. Human verification required.');
 else if(vendor.status==='inactive')flag('Invoice vendor is inactive. Human verification required.');
 if(po){
  const reference=state.purchase_orders.find(p=>p.po_number===po.po_number);
  if(!vendor || reference?.vendor_id!==vendor.id){result.checks=result.checks.filter(c=>c!=='Vendor matches PO.');flag(`Vendor mismatch: invoice "${invoice.vendor_name ?? 'Unknown'}" vs PO "${po.vendor_name}".`);}
  if(invoice.currency!==po.currency)flag(`Currency mismatch: invoice ${invoice.currency} vs PO ${po.currency}.`);
  if(result.po_balance && result.po_balance.remaining_after<0)flag('Invoice spending exceeds the remaining PO balance. Human verification required.');
 }
 return result;
}
export function cloudOrders(state: CloudState): PurchaseOrder[] {
 return state.purchase_orders.map(p => ({ po_number: p.po_number, vendor_name: state.vendors.find(v => v.id === p.vendor_id)?.name ?? "Unknown vendor", po_amount: Number(p.amount), currency: p.currency, status: p.status === "open" ? "Open" : p.status === "closed" ? "Closed" : "Cancelled" }));
}
export function cloudRuns(state: CloudState): Run[] {
 return state.runs.filter(r => r.result_snapshot).map(r => { const i = state.invoices.find(i => i.id === r.invoice_id); return { id: r.id, invoice_id: r.invoice_id, created_at: r.created_at,created_by:r.created_by,engine_version:r.engine_version,started_at:r.started_at,completed_at:r.completed_at,filename: r.source_filename ?? i?.file_name ?? "Invoice", file_hash: r.source_file_sha256 ?? i?.file_sha256 ?? "", file_path: r.source_file_path ?? i?.file_path ?? null, invoice: r.extracted_fields, result: r.result_snapshot as ValidationResult, raw_text: r.raw_text ?? "", legacy_created_at: r.legacy_created_at }; });
}
export function invoiceDate(value: string | null): string | null {
 if (!value) return null;
 const match = value.match(/^(\d{1,4})[/.\-](\d{1,2})[/.\-](\d{1,4})$/);
 if (!match) return null;
 const a=match[1], b=match[2], c=match[3]; if (!a || !b || !c) return null;
 const year=a.length===4 ? +a : +c, month=+b, day=a.length===4 ? +c : +a;
 const date=new Date(Date.UTC(year,month-1,day));
 return date.getUTCFullYear()===year && date.getUTCMonth()===month-1 && date.getUTCDate()===day ? date.toISOString().slice(0,10) : null;
}
