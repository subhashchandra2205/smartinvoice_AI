import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useOrg } from "./org";
import {readReportSummary} from "./invoices.functions";
import {supabase} from "@/integrations/supabase/client";
import { readInvoiceWorkspace } from "./invoices.functions";
import { cloudRuns, cloudOrders } from "./cloud-invoice";
export function useInvoiceWorkspace(){
 const {active}=useOrg();const read=useServerFn(readReportSummary);
 const query=useQuery({queryKey:['invoice-workspace',active?.organization_id],enabled:!!active,queryFn:async()=>{if(!active)throw new Error('Select an organization.');const [summary,vendors,orders]=await Promise.all([read({data:{organizationId:active.organization_id}}),supabase.from('vendors').select('id,name').eq('organization_id',active.organization_id).limit(1000),supabase.from('purchase_orders').select('id,vendor_id,po_number,amount,currency,status').eq('organization_id',active.organization_id).order('created_at',{ascending:false}).limit(100)]);if(vendors.error||orders.error)throw new Error('Reference summary unavailable.');return {summary,orders:cloudOrders({revision:'',invoices:[],runs:[],vendors:(vendors.data??[]).map(v=>({...v,normalized_name:null})),purchase_orders:orders.data??[]})};},refetchInterval:15000});
 return {runs:cloudRuns({revision:'',invoices:[],vendors:[],purchase_orders:[],runs:query.data?.summary.recent??[]}),summary:query.data?.summary,orders:query.data?.orders??[],loading:query.isLoading,error:query.error,refetch:query.refetch};
}
export function useRefreshInvoices(){const qc=useQueryClient();return ()=>qc.invalidateQueries({queryKey:["invoice-workspace"]});}
