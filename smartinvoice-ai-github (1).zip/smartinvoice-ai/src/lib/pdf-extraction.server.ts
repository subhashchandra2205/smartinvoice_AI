import { extractFields } from "./invoice";
import { verifyPdfEnvelope } from "./pdf-verification";

export async function extractVerifiedPdf(buffer: ArrayBuffer, options: { ocr?: boolean } = {}) {
  verifyPdfEnvelope(new Uint8Array(buffer));
  const { getDocumentProxy } = await import("unpdf");
  let document: Awaited<ReturnType<typeof getDocumentProxy>> | undefined;
  try {
    document = await getDocumentProxy(new Uint8Array(buffer.slice(0)), {
      stopAtErrors: true, useWasm: false,
      useSystemFonts: false, standardFontDataUrl: undefined, cMapUrl: undefined,
      maxImageSize: 16777216, disableFontFace: true, verbosity: 0,
    });
    if (document.numPages > 100) throw new Error("PDF exceeds the supported 100-page limit.");
    const pages: string[] = [];
    const unreadablePages: number[] = [];
    let characters = 0;
    for (let i = 1; i <= document.numPages; i++) {
      const page = await document.getPage(i);
      const content = await page.getTextContent();
      let line = "", out = "", lastY: number | null = null;
      for (const item of content.items) {
        if (!("str" in item)) continue;
        const y = item.transform[5] ?? 0;
        if (lastY !== null && Math.abs(y - lastY) > 2) { out += line.trim() + "\n"; line = ""; }
        line += item.str + " "; lastY = y;
      }
      const text = (out + line.trim()).normalize("NFKC").replace(/\u0000/g, "").trim();
      if (!text) unreadablePages.push(i);
      characters += text.length;
      if (characters > 1000000) throw new Error("PDF text exceeds the supported extraction limit.");
      pages.push(text);
      page.cleanup();
    }
    let ocrPages: { page: number; text: string; confidence: number }[] = [];
    if(options.ocr && unreadablePages.length){const {readScannedPages}=await import('./ocr.server');ocrPages=await readScannedPages(buffer,unreadablePages);for(const p of ocrPages)pages[p.page-1]=p.text;}
    const rawText = pages.join("\n\n");
    const fieldText = rawText.replace(/:\s*\|\s*/g, ': ');
    const invoice = extractFields(fieldText, rawText.trim() ? "Verified server PDF text" : "No readable text");
    // An unspecified currency is evidence, not a default extracted fact.
    if (!/currency\s*[:\-]\s*[A-Z]{3}\b/i.test(fieldText)) invoice.currency = "";
    invoice.field_evidence=Object.entries(invoice).filter(([key,value])=>key!=='field_evidence'&&typeof value!=='object').map(([field,value])=>{const source=pages.findIndex(text=>value!=null&&text.includes(String(value)));const ocr=ocrPages.find(p=>p.page===source+1);return {field,value:typeof value==='number'?value:typeof value==='string'?value:null,source_page:source>=0?source+1:null,confidence:ocr?.confidence??null,verification_status:value==null||value===''?'missing':ocr&&ocr.confidence<.9?'uncertain':'extracted'};});
    const items: NonNullable<typeof invoice.line_items> = [];
    for(const [index,text] of pages.entries())for(const line of text.split('\n')){const cols=line.split('|').map(c=>c.trim());if(cols.length!==6||!cols[0]||!/^[\d.]+$/.test(cols[2]??''))continue;const values=cols.slice(2).map(v=>Number(v.replace(/[,₹%]/g,'')));if(values.some(v=>!Number.isFinite(v)))continue;items.push({description:cols[0],hsn_sac:cols[1]||null,quantity:values[0]??null,unit_price:values[1]??null,tax_percentage:values[2]??null,line_total:values[3]??null,source_page:index+1});}
    invoice.line_items=items;
    return { invoice, rawText, pageCount: document.numPages, unreadablePages, ocrRequired: unreadablePages.length > 0 && !ocrPages.length, ocrPages, extractor: ocrPages.length ? "unpdf-2.1/gpt-6-astra-ocr-v1" : "unpdf-2.1/server-v1" };
  } catch (error) {
    console.error('pdf_extraction_error',{name:error instanceof Error?error.name:'Unknown',message:error instanceof Error?error.message:'Parser failed'});
    if (error instanceof Error && (error.name === "PasswordException" || /password|encrypted/i.test(error.message))) throw new Error("Encrypted PDFs are not supported. Upload an unencrypted original.");
    if (error instanceof Error && /supported|exceeds|OCR/.test(error.message)) throw error;
    throw new Error("PDF is malformed, corrupted or uses unsupported text encoding. Upload a readable original.");
  } finally {
    await document?.loadingTask.destroy();
  }
}