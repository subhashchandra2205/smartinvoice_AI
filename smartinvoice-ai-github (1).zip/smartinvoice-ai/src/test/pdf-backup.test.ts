// @vitest-environment node
import { describe, expect, it } from 'vitest';
import { jsPDF } from 'jspdf';
import { zipSync, strToU8 } from 'fflate';
import { sha256 } from '../lib/invoice';
import { assertBackupPath, verifyBackupArchive } from '../lib/pdf-backup';
const org = '11111111-1111-4111-8111-111111111111';
async function fixture() {
  const doc = new jsPDF(); doc.text('Recovery evidence', 20, 20);
  const bytes = new Uint8Array(doc.output('arraybuffer'));
  const hash = await sha256(bytes.slice().buffer), path = `${org}/verified/${hash}.pdf`;
  const manifest = { version: 1, organizationId: org, createdAt: new Date().toISOString(), files: [{ path, sha256: hash, invoiceIds: ['invoice-1'], runIds: ['run-1'] }] };
  return { bytes, path, manifest };
}
describe('private PDF backup integrity', () => {
  it('recovers exact original bytes and record references', async () => { const f = await fixture(); const zip = zipSync({ 'manifest.json': strToU8(JSON.stringify(f.manifest)), [f.path]: f.bytes }); const result = await verifyBackupArchive(zip, org); expect(result.files[0]?.invoiceIds).toEqual(['invoice-1']); expect(result.files[0]?.sha256).toBe(await sha256(f.bytes.slice().buffer)); });
  it('rejects a different organization', async () => { const f = await fixture(); await expect(verifyBackupArchive(zipSync({ 'manifest.json': strToU8(JSON.stringify(f.manifest)), [f.path]: f.bytes }), 'other')).rejects.toThrow('does not belong'); });
  it('rejects missing original PDFs', async () => { const f = await fixture(); await expect(verifyBackupArchive(zipSync({ 'manifest.json': strToU8(JSON.stringify(f.manifest)) }), org)).rejects.toThrow('missing'); });
  it('rejects altered PDF bytes', async () => { const f = await fixture(); const entry = f.manifest.files[0]; if (!entry) throw new Error('Missing fixture'); entry.sha256 = '0'.repeat(64); await expect(verifyBackupArchive(zipSync({ 'manifest.json': strToU8(JSON.stringify(f.manifest)), [f.path]: f.bytes }), org)).rejects.toThrow('checksum'); });
  it('rejects traversal and foreign paths', () => { expect(() => assertBackupPath(org, `${org}/../foreign.pdf`)).toThrow(); expect(() => assertBackupPath(org, 'other/file.pdf')).toThrow(); });
  it('rejects unlisted files', async () => { const f = await fixture(); await expect(verifyBackupArchive(zipSync({ 'manifest.json': strToU8(JSON.stringify(f.manifest)), [f.path]: f.bytes, 'extra.txt': strToU8('extra') }), org)).rejects.toThrow('unlisted'); });
});