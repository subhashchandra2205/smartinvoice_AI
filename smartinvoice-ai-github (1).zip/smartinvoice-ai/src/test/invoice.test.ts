import { describe, expect, it } from "vitest";
import { DEFAULT_SETTINGS, extractFields, validateInvoice, type Run } from "../lib/invoice";

const text = (id = "INV-101", subtotal = 20000, tax = 3600) => `Vendor: Acme Supplies Pvt Ltd\nInvoice number: ${id}\nInvoice date: 09/11/2026\nPO number: PO-1001\nSubtotal: ${subtotal}\nGST: ${tax}\nGrand total: ${subtotal + tax}`;
const invoice = (id = "INV-101", subtotal = 20000) => extractFields(text(id, subtotal, subtotal * .18), "PDF text layer");
const run = (id: string, subtotal: number): Run => {
  const inv = invoice(id, subtotal);
  return { id, created_at: "2026-11-09T00:00:00Z", filename: `${id}.pdf`, file_hash: id, invoice: inv, result: validateInvoice(inv, [], DEFAULT_SETTINGS, id), raw_text: text(id, subtotal) };
};

describe("Invoice decision rules", () => {
  it("separates subtotal 20000 and grand total 23600", () => {
    const inv = invoice();
    expect(inv.taxable_amount).toBe(20000);
    expect(inv.total_amount).toBe(23600);
    expect(validateInvoice(inv, [], DEFAULT_SETTINGS, "new").status).toBe("Approved");
  });
  it("requires an invoice date before approval", () => {
    const inv = extractFields(text("INV-DATE", 50000, 9000).replace("Invoice date: 09/11/2026\n", ""), "PDF text layer");
    expect(validateInvoice(inv, [], DEFAULT_SETTINGS, "new").status).toBe("Needs Review");
  });
  it("rejects same vendor and invoice identity in a different PDF", () => {
    expect(validateInvoice(invoice(), [run("INV-101", 20000)], DEFAULT_SETTINGS, "different").status).toBe("Rejected");
  });
  it("allows two partial invoices totaling the 50000 PO", () => {
    const result = validateInvoice(invoice("INV-102", 30000), [run("INV-101", 20000)], DEFAULT_SETTINGS, "second");
    expect(result.status).toBe("Approved");
    expect(result.po_balance?.previously_approved).toBe(20000);
    expect(result.po_balance?.remaining_after).toBe(0);
  });
  it("flags cumulative spend above 50000 plus 2 percent tolerance", () => {
    expect(validateInvoice(invoice("INV-102", 32000), [run("INV-101", 20000)], DEFAULT_SETTINGS, "second").status).toBe("Needs Review");
  });
  it("does not consume PO balance for review-only invoices", () => {
    const prior = run("INV-101", 20000); prior.result.status = "Needs Review";
    expect(validateInvoice(invoice("INV-102", 50000), [prior], DEFAULT_SETTINGS, "second").status).toBe("Approved");
  });
  it("does not guess when PO reference is missing", () => {
    const inv = extractFields(text().replace("PO number: PO-1001\n", ""), "PDF text layer");
    const result = validateInvoice(inv, [], DEFAULT_SETTINGS, "new");
    expect(result.status).toBe("Needs Review");
    expect(result.matched_po).toBeNull();
    expect(result.po_candidates?.[0]?.po_number).toBe("PO-1001");
    expect(result.po_candidates?.length).toBe(2);
  });
  it("accepts tax-inclusive spend exactly at 2 percent tolerance", () => {
    const inv = extractFields("Vendor: Acme Supplies Pvt Ltd\nInvoice number: INC-1\nInvoice date: 09/11/2026\nPO: PO-1001\nGST: 9180\nGrand total: 60180", "PDF text layer");
    expect(validateInvoice(inv, [], DEFAULT_SETTINGS, "new").status).toBe("Approved");
  });
  it("flags tax-inclusive spend above the tolerance", () => {
    const inv = extractFields("Vendor: Acme Supplies Pvt Ltd\nInvoice number: INC-2\nInvoice date: 09/11/2026\nPO: PO-1001\nGST: 9180.18\nGrand total: 60181.18", "PDF text layer");
    expect(validateInvoice(inv, [], DEFAULT_SETTINGS, "new").status).toBe("Needs Review");
  });
  it("flags inconsistent subtotal plus tax instead of approving", () => {
    const inv = extractFields(text().replace("Grand total: 23600", "Grand total: 25000"), "PDF text layer");
    expect(validateInvoice(inv, [], DEFAULT_SETTINGS, "new").status).toBe("Needs Review");
  });
  it("keeps unreadable PDFs in manual review", () => {
    expect(validateInvoice(extractFields("", "No readable text"), [], DEFAULT_SETTINGS, "scan").status).toBe("Needs Review");
  });
});