import {describe,it,expect} from 'vitest';
import {historyQuery,historyArguments} from '../lib/history-query';
const org='0d425378-aeff-4293-b525-9e261bcd5c6d';
describe('bounded history queries',()=>{
 it('uses 25 rows initially',()=>expect(historyArguments(historyQuery.parse({organizationId:org}))._limit).toBe(25));
 it('can read beyond 1000 rows without truncation',()=>expect(historyArguments(historyQuery.parse({organizationId:org,page:42}))._offset).toBe(1025));
 it('limits each request to 100 rows',()=>expect(historyQuery.safeParse({organizationId:org,limit:101}).success).toBe(false));
 it('rejects invalid sort inputs',()=>expect(historyQuery.safeParse({organizationId:org,sort:'amount;delete'}).success).toBe(false));
 it('keeps tenant scope in every page',()=>expect(historyArguments(historyQuery.parse({organizationId:org,page:999}))._org).toBe(org));
});