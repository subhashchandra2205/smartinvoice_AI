import { expect, it } from "vitest";
import { DEMO_CASES } from "../lib/demo-invoices";
import { DEFAULT_SETTINGS, extractFields, validateInvoice, type Run } from "../lib/invoice";

it("demonstrates duplicate rejection with different file contents", () => {
  const files = DEMO_CASES[0]?.files;
  if (!files?.[0] || !files[1]) throw new Error("Missing duplicate fixtures");
  expect(files[0].text).not.toBe(files[1].text);
  const first = extractFields(files[0].text, "PDF text layer");
  const result = validateInvoice(first, [], DEFAULT_SETTINGS, "hash-a");
  expect(result.status).toBe("Approved");
  const prior: Run = { id: "1", created_at: "2026-11-09", filename: files[0].filename, file_hash: "hash-a", invoice: first, result, raw_text: files[0].text };
  expect(validateInvoice(extractFields(files[1].text, "PDF text layer"), [prior], DEFAULT_SETTINGS, "hash-b").status).toBe("Rejected");
});

it("demonstrates split spend with approved, approved, review outcomes", () => {
  const history: Run[] = [];
  const outcomes = DEMO_CASES[1]?.files.map((file, i) => {
    const invoice = extractFields(file.text, "PDF text layer");
    const result = validateInvoice(invoice, history, DEFAULT_SETTINGS, `hash-${i}`);
    history.push({ id: String(i), created_at: "2026-11-09", filename: file.filename, file_hash: `hash-${i}`, invoice, result, raw_text: file.text });
    return result.status;
  });
  expect(outcomes).toEqual(["Approved", "Approved", "Needs Review"]);
});