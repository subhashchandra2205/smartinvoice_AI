// @vitest-environment node
import { describe, expect, it } from "vitest";
import { jsPDF } from "jspdf";
import { extractVerifiedPdf } from "../lib/pdf-extraction.server";
import { MAX_PDF_BYTES, verifyPdfEnvelope, verifiedPdfPath } from "../lib/pdf-verification";
import { sha256, DEFAULT_SETTINGS, validateInvoice } from "../lib/invoice";

function pdf(text?: string, encrypted = false) {
 const doc = new jsPDF(encrypted ? { encryption: { userPassword: "test-only", ownerPassword: "owner-test-only", userPermissions: [] } } : {});
 if (text) doc.text(text, 20, 20);
 return doc.output("arraybuffer");
}
const text = "Vendor: Acme Supplies Pvt Ltd\nGSTIN: 29ABCDE1234F1Z5\nInvoice number: SERVER-1\nInvoice date: 09/11/2026\nPO: PO-1001\nCurrency: INR\nSubtotal: 1000\nCGST: 90\nSGST: 90\nGrand total: 1180";
describe("trusted PDF extraction", () => {
 it("extracts concrete fields and GST components from valid bytes", async () => {
  const result = await extractVerifiedPdf(pdf(text));
  expect(result.invoice).toMatchObject({ vendor_name: "Acme Supplies Pvt Ltd", invoice_number: "SERVER-1", po_number: "PO-1001", taxable_amount: 1000, tax_amount: 180, grand_total: 1180, gstin: "29ABCDE1234F1Z5", gst_components: { cgst: 90, sgst: 90, igst: null } });
  expect(result.ocrRequired).toBe(false);
  expect(validateInvoice(result.invoice, [], DEFAULT_SETTINGS, "new").status).toBe("Approved");
 });
 it("rejects truncated PDFs", async () => { const b=pdf(text); await expect(extractVerifiedPdf(b.slice(0,b.byteLength-50))).rejects.toThrow(/corrupted|incomplete/); });
 it("rejects a renamed non-PDF regardless of filename or MIME", async () => { await expect(extractVerifiedPdf(new TextEncoder().encode("this is not a PDF").buffer)).rejects.toThrow(/not a supported PDF/); });
 it("rejects forged PDF signatures", async () => { await expect(extractVerifiedPdf(new TextEncoder().encode("%PDF-1.7\nnot actually a PDF\nstartxref\n9\n%%EOF").buffer)).rejects.toThrow(/corrupted/); });
 it("rejects files larger than exactly 20 MB", () => { expect(()=>verifyPdfEnvelope(new Uint8Array(MAX_PDF_BYTES+1))).toThrow("PDF exceeds 20 MB."); expect(MAX_PDF_BYTES).toBe(20971520); });
 it("uses identical server hashes and paths for duplicate bytes", async () => { const b=pdf(text); const a=await sha256(b); expect(await sha256(b.slice(0))).toBe(a); expect(verifiedPdfPath("org-a",a)).toBe(`org-a/verified/${a}.pdf`); expect(verifiedPdfPath("org-b",a)).not.toBe(verifiedPdfPath("org-a",a)); });
 it("marks image-only/empty text as OCR required without invented fields", async () => { const r=await extractVerifiedPdf(pdf()); expect(r.ocrRequired).toBe(true); expect(r.unreadablePages).toEqual([1]); expect(r.invoice.vendor_name).toBeNull(); expect(r.invoice.total_amount).toBeNull(); expect(r.invoice.currency).toBe(""); expect(validateInvoice(r.invoice, [], DEFAULT_SETTINGS,"scan").status).toBe("Needs Review"); });
 it("flags an actual image-only scanned PDF", async () => { const d=new jsPDF(); d.addImage({data:new Uint8ClampedArray([255,255,255,255]),width:1,height:1},"RGBA",20,20,100,100); const r=await extractVerifiedPdf(d.output("arraybuffer")); expect(r.ocrRequired).toBe(true); expect(r.rawText.trim()).toBe(""); expect(r.invoice.invoice_number).toBeNull(); });
 it("rejects encrypted PDFs explicitly", async () => { await expect(extractVerifiedPdf(pdf(text,true))).rejects.toThrow(/Encrypted PDFs/); });
 it("does not infer an unstated currency", async()=>{expect((await extractVerifiedPdf(pdf(text.replace("Currency: INR\n","")))).invoice.currency).toBe("");});
 it("extracts OCR label-value pipe formatting without inventing fields", async()=>{const r=await extractVerifiedPdf(pdf(text.replaceAll(': ',': | ')));expect(r.invoice.invoice_number).toBe('SERVER-1');expect(r.invoice.total_amount).toBe(1180);expect(r.invoice.currency).toBe('INR');});
});