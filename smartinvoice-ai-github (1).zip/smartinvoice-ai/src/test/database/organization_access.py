"""Removed-creator RLS regression on the disposable test database only."""
import unittest, uuid
from approval_concurrency import sql

class OrganizationAccess(unittest.TestCase):
 def test_removed_creator_loses_read_current_member_keeps_read(self):
  actor, org = str(uuid.uuid4()), str(uuid.uuid4())
  sql("DROP TABLE IF EXISTS public.organization_read_probe; CREATE TABLE public.organization_read_probe(id uuid,created_by uuid); GRANT USAGE ON SCHEMA public TO authenticated; GRANT SELECT ON public.organization_members,public.organization_read_probe TO authenticated; ALTER TABLE public.organization_read_probe ENABLE ROW LEVEL SECURITY; CREATE POLICY members ON public.organization_read_probe FOR SELECT TO authenticated USING(public.is_org_member(id,auth.uid()));")
  sql(f"INSERT INTO public.organization_read_probe VALUES('{org}','{actor}');")
  def count():
   return int(sql(f"BEGIN; SET LOCAL ROLE authenticated; SET LOCAL test.actor='{actor}'; SELECT count(*) FROM public.organization_read_probe; COMMIT;").stdout.strip())
  self.assertEqual(count(),0)
  sql(f"INSERT INTO public.organization_members VALUES('{org}','{actor}','admin');")
  self.assertEqual(count(),1)
  sql(f"DELETE FROM public.organization_members WHERE organization_id='{org}' AND user_id='{actor}';")
  self.assertEqual(count(),0)

if __name__ == '__main__': unittest.main()