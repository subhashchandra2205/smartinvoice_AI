"""10,050-row history/aggregate checks on disposable PostgreSQL only; run after approval_concurrency.py."""
import json,time,uuid,unittest
from pathlib import Path
from approval_concurrency import sql,ROOT
class HistoryLoad(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.org,cls.actor,cls.other=[str(uuid.uuid4()) for _ in range(3)]
  sql("CREATE OR REPLACE FUNCTION public.is_org_member(uuid,uuid) RETURNS boolean LANGUAGE sql AS $$SELECT EXISTS(SELECT 1 FROM organization_members WHERE organization_id=$1 AND user_id=$2)$$;")
  sql(f"INSERT INTO organization_members VALUES('{cls.org}','{cls.actor}','admin');")
  migration=next((ROOT/'drizzle/migrations').glob('0021*.sql')).read_text();sql(migration[migration.index('CREATE INDEX'):])
  sql(next((ROOT/'drizzle/migrations').glob('0022*.sql')).read_text())
  sql(f"INSERT INTO processing_runs(organization_id,invoice_id,created_at,raw_text,extracted_fields,result_snapshot) SELECT '{cls.org}',gen_random_uuid(),'2026-01-01'::timestamptz+n*interval '1 second',repeat('x',10000),jsonb_build_object('invoice_number','LOAD-'||n,'vendor_name','Load vendor','currency','INR','total_amount',1180,'tax_amount',180),jsonb_build_object('status','Approved','reasons','[]'::jsonb) FROM generate_series(1,10050) n;")
 def query(self,expression):
  return json.loads(sql(f"BEGIN;SET LOCAL test.actor='{self.actor}';SELECT {expression};COMMIT;").stdout.strip())
 def test_page_beyond_1000(self):
  result=self.query(f"read_invoice_history('{self.org}',1000,25)");self.assertEqual(result['total'],10050);self.assertEqual(len(result['runs']),25);self.assertNotIn('raw_text',result['runs'][0]);self.assertLess(len(json.dumps(result)),50000)
 def test_last_page(self):
  result=self.query(f"read_invoice_history('{self.org}',10025,25)");self.assertEqual(len(result['runs']),25)
 def test_exact_aggregates(self):
  result=self.query(f"invoice_report_summary('{self.org}')");self.assertEqual(result['processed'],10050);self.assertEqual(result['currencyTotals']['INR'],11859000);self.assertEqual(len(result['recent']),5)
 def test_search(self):
  result=self.query(f"read_invoice_history('{self.org}',0,25,'LOAD-10050')");self.assertEqual(result['total'],1)
 def test_other_tenant(self):
  self.assertNotEqual(sql(f"BEGIN;SET LOCAL test.actor='{self.actor}';SELECT read_invoice_history('{self.other}');",False).returncode,0)
 def test_page_latency(self):
  start=time.monotonic();self.query(f"read_invoice_history('{self.org}',0,25)");elapsed=time.monotonic()-start;print(f'10,050 rows, 100 MB source text, page query: {elapsed:.3f}s');self.assertLess(elapsed,5)
if __name__=='__main__':unittest.main()