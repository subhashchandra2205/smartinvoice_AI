"""Real PostgreSQL tests against a disposable instance only.
Run: python3 src/test/database/approval_concurrency.py
Requires PostgreSQL on /tmp/approval-postgres port 55439. Never uses Cloud credentials.
"""
import concurrent.futures,json,subprocess,unittest,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
def sql(query,check=True):
 p=subprocess.run(['psql','-X','-h','/tmp/approval-postgres','-p','55439','-U','lovable','-d','postgres','-v','ON_ERROR_STOP=1','-Atq'],input=query,text=True,capture_output=True)
 if check and p.returncode: raise AssertionError(p.stderr)
 return p
class Approvals(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  sql('DROP SCHEMA public CASCADE; CREATE SCHEMA public; DROP SCHEMA IF EXISTS auth CASCADE;')
  sql("DO $$ BEGIN IF NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN CREATE ROLE authenticated; CREATE ROLE anon; CREATE ROLE service_role; END IF; END $$;")
  sql("""
  CREATE SCHEMA auth;
  CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql AS $$ SELECT nullif(current_setting('test.actor',true),'')::uuid $$;
  CREATE TYPE app_role AS ENUM ('admin','finance_manager','invoice_processor','reviewer','read_only');
  CREATE TYPE invoice_status AS ENUM ('received','processing','approved','needs_review','rejected');
  CREATE TYPE po_status AS ENUM ('open','closed','cancelled');
  CREATE TYPE run_status AS ENUM ('queued','running','succeeded','failed');
  CREATE TYPE recommendation AS ENUM ('approved','needs_review','rejected');
  CREATE TABLE organization_members(organization_id uuid,user_id uuid,role app_role);
  CREATE FUNCTION has_org_role(uuid,uuid,app_role[]) RETURNS boolean LANGUAGE sql AS $$ SELECT EXISTS(SELECT 1 FROM organization_members WHERE organization_id=$1 AND user_id=$2 AND role=ANY($3)) $$;
  CREATE FUNCTION normalize_vendor_name(text) RETURNS text LANGUAGE sql AS $$SELECT lower(regexp_replace($1,'[^a-zA-Z0-9]','','g'))$$;
  CREATE TABLE vendors(id uuid PRIMARY KEY,organization_id uuid,name text,normalized_name text,status text);
  CREATE TABLE purchase_orders(id uuid PRIMARY KEY,organization_id uuid,vendor_id uuid,amount numeric(14,2),currency text,status po_status);
  CREATE TABLE invoices(id uuid PRIMARY KEY,organization_id uuid,purchase_order_id uuid,vendor_id uuid,vendor_name_extracted text,invoice_number text,invoice_date date,status invoice_status,subtotal_amount numeric(14,2),tax_amount numeric(14,2),total_amount numeric(14,2),currency text,file_sha256 text,uploaded_by uuid);
  CREATE TABLE processing_runs(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),organization_id uuid,invoice_id uuid,status run_status,engine_version text,policy_snapshot jsonb,extracted_fields jsonb,raw_text text,started_at timestamptz,completed_at timestamptz,created_by uuid,result_snapshot jsonb,source_file_path text,source_filename text,source_file_sha256 text,legacy_record_id uuid,created_at timestamptz DEFAULT now(),extraction_metadata jsonb);
  CREATE TABLE validation_results(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),organization_id uuid,processing_run_id uuid,invoice_id uuid,recommendation recommendation,checks jsonb,reasons jsonb,rule_evidence jsonb);
  CREATE TABLE audit_events(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),organization_id uuid,actor_id uuid,entity_type text,entity_id uuid,action text,details jsonb);
  """)
  sql(next((ROOT/'drizzle/migrations').glob('0010*.sql')).read_text())
  sql(next((ROOT/'drizzle/migrations').glob('0012*.sql')).read_text())
  sql("CREATE SCHEMA IF NOT EXISTS storage; CREATE TABLE IF NOT EXISTS storage.objects(bucket_id text,name text);")
  current=next((ROOT/'drizzle/migrations').glob('0016*.sql')).read_text()
  sql(current[current.index('CREATE OR REPLACE FUNCTION public.approve_invoice'):current.index('CREATE OR REPLACE FUNCTION public.reject_invoice')])
 def setUp(self):
  self.org,self.actor,self.vendor,self.po=[str(uuid.uuid4()) for _ in range(4)]
  sql(f"INSERT INTO organization_members VALUES('{self.org}','{self.actor}','reviewer'); INSERT INTO vendors VALUES('{self.vendor}','{self.org}','Acme','acme','active'); INSERT INTO purchase_orders VALUES('{self.po}','{self.org}','{self.vendor}',100,'INR','open');")
 def invoice(self,amount,tolerance=0,status='Needs Review'):
  i,r=str(uuid.uuid4()),str(uuid.uuid4());snapshot=json.dumps({'status':status,'checks':[],'reasons':[]})
  sql(f"INSERT INTO invoices(id,organization_id,purchase_order_id,vendor_id,vendor_name_extracted,invoice_number,invoice_date,status,subtotal_amount,total_amount,currency,file_sha256,uploaded_by) VALUES('{i}','{self.org}','{self.po}','{self.vendor}','Acme','{i}','2026-11-09','needs_review',{amount},{amount},'INR','{i}','{uuid.uuid4()}'); INSERT INTO processing_runs(id,organization_id,invoice_id,policy_snapshot,result_snapshot,source_file_sha256,extraction_metadata,source_file_path) VALUES('{r}','{self.org}','{i}','{{\"tolerance\":{tolerance}}}','{snapshot}','{i}','{{\"extractor\":\"unpdf\",\"ocr_required\":false}}','{self.org}/{i}.pdf'); INSERT INTO storage.objects VALUES('invoice-pdfs','{self.org}/{i}.pdf');")
  return i,r
 def approve(self,r,org=None):
  return sql(f"BEGIN; SET LOCAL test.actor='{self.actor}'; SELECT approve_invoice('{org or self.org}','{r}','Reviewed source document'); COMMIT;",False)
 def count(self):return int(sql(f"SELECT count(*) FROM invoices WHERE organization_id='{self.org}' AND status='approved';").stdout.strip())
 def parallel(self,amounts):
  runs=[self.invoice(a)[1] for a in amounts]
  with concurrent.futures.ThreadPoolExecutor(2) as pool:return list(pool.map(self.approve,runs))
 def test_simultaneous_same_po(self):
  results=self.parallel([70,70]);self.assertEqual(sum(p.returncode==0 for p in results),1);self.assertEqual(self.count(),1)
 def test_combined_exceeds_balance(self):
  a=self.invoice(60)[1];b=self.invoice(50)[1];self.assertEqual(self.approve(a).returncode,0);failure=self.approve(b);self.assertNotEqual(failure.returncode,0);self.assertIn('PO balance exceeded',failure.stderr);self.assertEqual(self.count(),1)
 def test_combined_within_balance(self):
  results=self.parallel([40,60]);self.assertTrue(all(p.returncode==0 for p in results));self.assertEqual(self.count(),2)
 def test_duplicate_approval(self):
  r=self.invoice(50)[1];self.assertEqual(self.approve(r).returncode,0);self.assertNotEqual(self.approve(r).returncode,0);self.assertEqual(self.count(),1)
 def test_other_organization(self):
  r=self.invoice(10)[1];other=str(uuid.uuid4());sql(f"INSERT INTO organization_members VALUES('{other}','{self.actor}','reviewer');");self.assertNotEqual(self.approve(r,other).returncode,0);self.assertEqual(self.count(),0)
 def test_failure_rolls_back_every_decision(self):
  i,r=self.invoice(101);before=sql('SELECT count(*) FROM processing_runs; SELECT count(*) FROM validation_results; SELECT count(*) FROM audit_events;').stdout
  self.assertNotEqual(self.approve(r).returncode,0);after=sql('SELECT count(*) FROM processing_runs; SELECT count(*) FROM validation_results; SELECT count(*) FROM audit_events;').stdout;self.assertEqual(before,after);self.assertEqual(sql(f"SELECT status FROM invoices WHERE id='{i}';").stdout.strip(),'needs_review')
 def test_saved_tolerance(self):
  r=self.invoice(102,2)[1];self.assertEqual(self.approve(r).returncode,0);self.assertEqual(self.count(),1)
 def test_processor_cannot_approve(self):
  sql(f"UPDATE organization_members SET role='invoice_processor' WHERE organization_id='{self.org}';");self.assertNotEqual(self.approve(self.invoice(10)[1]).returncode,0)
 def test_rejected_duplicate_run(self):
  self.assertNotEqual(self.approve(self.invoice(10,status='Rejected')[1]).returncode,0);self.assertEqual(self.count(),0)
 def test_approved_amount_immutable(self):
  i,r=self.invoice(10);self.assertEqual(self.approve(r).returncode,0);self.assertNotEqual(sql(f"UPDATE invoices SET subtotal_amount=1 WHERE id='{i}';",False).returncode,0)
 def test_uploader_cannot_self_approve(self):
  i,r=self.invoice(10);sql(f"UPDATE invoices SET uploaded_by='{self.actor}' WHERE id='{i}';");failure=self.approve(r);self.assertNotEqual(failure.returncode,0);self.assertIn('separate authorized person',failure.stderr)
 def test_unverified_extraction_cannot_be_approved(self):
  i,r=self.invoice(10);sql(f"UPDATE processing_runs SET extraction_metadata=NULL WHERE id='{r}';");self.assertNotEqual(self.approve(r).returncode,0);self.assertEqual(self.count(),0)
 def test_read_only_cannot_approve(self):
  sql(f"UPDATE organization_members SET role='read_only' WHERE organization_id='{self.org}';");self.assertNotEqual(self.approve(self.invoice(10)[1]).returncode,0)
 def test_finance_manager_can_approve_independently(self):
  sql(f"UPDATE organization_members SET role='finance_manager' WHERE organization_id='{self.org}';");self.assertEqual(self.approve(self.invoice(10)[1]).returncode,0)
 def test_admin_can_approve_independently(self):
  sql(f"UPDATE organization_members SET role='admin' WHERE organization_id='{self.org}';");self.assertEqual(self.approve(self.invoice(10)[1]).returncode,0)
if __name__=='__main__':unittest.main()
