import { describe,it,expect } from "vitest";
import { extractFields,validateInvoice,DEFAULT_SETTINGS, type Run } from "@/lib/invoice";
import { invoiceDate, normalizeVendor } from "@/lib/cloud-invoice";
const text="Vendor: Acme Supplies Pvt Ltd\nInvoice No: CLOUD-001\nDate: 09/11/2026\nPO: PO-1001\nSubtotal: 20000\nGST: 3600\nGrand Total: 23600";
describe("Cloud validation boundaries",()=>{
 it("does not fall back to synthetic POs for an empty organization",()=>{const r=validateInvoice(extractFields(text,"PDF text layer"),[],DEFAULT_SETTINGS,"hash",[]);expect(r.status).toBe("Needs Review");expect(r.matched_po).toBeNull();});
 it("preserves GST validation using cloud PO amounts",()=>{const r=validateInvoice(extractFields(text,"PDF text layer"),[],DEFAULT_SETTINGS,"hash",[{po_number:"PO-1001",vendor_name:"Acme Supplies Pvt Ltd",po_amount:50000,currency:"INR",status:"Open"}]);expect(r.status).toBe("Approved");expect(r.gst_validation?.expected_tax).toBe(3600);});
 it("requires review when shared approved spend exceeds PO allowance",()=>{const invoice=extractFields(text,"PDF text layer");const po={po_number:"PO-1001",vendor_name:"Acme Supplies Pvt Ltd",po_amount:25000,currency:"INR",status:"Open" as const};const earlier:Run={id:"previous",created_at:"2026-11-09",filename:"earlier.pdf",file_hash:"other",raw_text:"",invoice:{...invoice,invoice_number:"EARLIER"},result:validateInvoice({...invoice,invoice_number:"EARLIER"},[],DEFAULT_SETTINGS,"other",[po])};const r=validateInvoice(invoice,[earlier],DEFAULT_SETTINGS,"new",[po]);expect(r.status).toBe("Needs Review");expect(r.po_balance?.previously_approved).toBe(20000);expect(r.po_balance?.allowed_total).toBe(25500);});
 it("normalizes legal suffixes for organization duplicate identity",()=>{expect(normalizeVendor("Acme Supplies Pvt Ltd")).toBe(normalizeVendor("ACME Supplies Limited"));});
 it("stores Indian invoice dates without swapping day and month",()=>{expect(invoiceDate("09/11/2026")).toBe("2026-11-09");expect(invoiceDate("31/02/2026")).toBeNull();});
});
