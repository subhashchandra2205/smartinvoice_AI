import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Button } from "./ui/button";
import { getRuns, useRuns, useSettings } from "@/lib/store";
import { useOrg } from "@/lib/org";
import { processCloudInvoice } from "@/lib/invoices.functions";
import { useRefreshInvoices } from "@/lib/invoices-store";
export function LegacyInvoiceImport(){
 const legacy=useRuns();const {active}=useOrg();const [settings]=useSettings();const [busy,setBusy]=useState(false);const process=useServerFn(processCloudInvoice);const refresh=useRefreshInvoices();
 if(!legacy.length || !active || !["admin","finance_manager","invoice_processor"].includes(active.role))return null;
 return <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border bg-card p-4"><p className="text-xs text-muted-foreground">{legacy.length} device records remain on this browser. Imports require review; original PDFs are not available.</p><Button variant="outline" size="sm" disabled={busy} onClick={async()=>{if(!confirm(`Import ${legacy.length} device records into ${active.organization_name}? Existing device history stays untouched. Imported decisions will require review.`))return;setBusy(true);let done=0;try{for(const r of getRuns()){await process({data:{organizationId:active.organization_id,filePath:null,filename:r.filename,rawText:r.raw_text,settings,legacy:{id:r.id,created_at:r.created_at,file_hash:r.file_hash,invoice:r.invoice,result:r.result}}});done++;}toast.success(`${done} records imported or already present`);}catch{toast.error(`Import stopped after ${done} records. Retry safely; device history is unchanged.`);}finally{setBusy(false);refresh();}}}>{busy?"Importing…":"Import device history"}</Button></div>;
}
