import type { ReactNode } from "react";
import { Receipt, ShieldCheck } from "lucide-react";

export function AuthLayout({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <div className="grid min-h-screen bg-background lg:grid-cols-[1.05fr_1fr]">
      <aside className="hidden flex-col justify-between border-r border-border bg-card p-10 lg:flex">
        <div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-md bg-primary text-primary-foreground"><Receipt className="size-4" /></span><p className="text-base font-semibold">SmartInvoice AI</p></div>
        <div><span className="mb-6 grid size-14 place-items-center rounded-xl bg-primary-soft text-primary"><ShieldCheck className="size-7" /></span><h2 className="max-w-md text-3xl font-semibold leading-snug">Your accounts payable workspace.</h2><p className="mt-5 text-sm text-muted-foreground">Secure access for your finance team.</p></div>
        <p className="text-xs text-muted-foreground">Access is limited to invited members of your organization.</p>
      </aside>
      <main className="flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 flex items-center gap-2.5 lg:hidden">
            <div className="grid size-8 place-items-center rounded-lg bg-primary text-primary-foreground">
              <Receipt className="size-4" />
            </div>
            <p className="font-display font-semibold">SmartInvoice AI</p>
          </div>
          <h1 className="font-display text-3xl font-semibold text-foreground">{title}</h1>
          {subtitle && <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>}
          <div className="mt-8">{children}</div>
        </div>
      </main>
    </div>
  );
}

export const authInput =
  "mt-1.5 w-full rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20";
export const authButton =
  "inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition hover:bg-primary-strong disabled:opacity-60";
