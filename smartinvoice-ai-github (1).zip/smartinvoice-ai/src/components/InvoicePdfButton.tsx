import { ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { Button } from "./ui/button";
import { supabase } from "@/integrations/supabase/client";
export function InvoicePdfButton({path}:{path?:string|null|undefined}){
 if(!path)return null;
 return <Button variant="outline" size="sm" onClick={async()=>{const tab=window.open("about:blank","_blank");if(tab)tab.opener=null;const {data,error}=await supabase.storage.from("invoice-pdfs").download(path);if(error||!data){tab?.close();toast.error("You cannot access this PDF.");return;}const url=URL.createObjectURL(data);if(tab){tab.location.href=url;window.setTimeout(()=>URL.revokeObjectURL(url),60000);}else{URL.revokeObjectURL(url);toast.error("Allow pop-ups to view this PDF.");}}}><ExternalLink />View original PDF</Button>;
}
