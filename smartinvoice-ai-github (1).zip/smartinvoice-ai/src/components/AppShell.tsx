import { Link, useNavigate, useLocation } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { LayoutDashboard, FileUp, History, Receipt, SlidersHorizontal, Users, LogOut, Plus, Menu, ChevronDown, Settings, Building2, ClipboardList,ChartNoAxesCombined } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ROLE_LABELS, useOrg } from "@/lib/org";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { RulesForm } from "@/components/RulesForm";

const nav = [
  { to: "/", label: "Overview", icon: LayoutDashboard },
  { to: "/process", label: "Process invoice", icon: FileUp },
  { to: "/history", label: "Run history", icon: History },
  { to: "/vendors", label: "Vendors", icon: Building2 },
  { to: "/purchase-orders", label: "Purchase orders", icon: ClipboardList },
  { to: "/team", label: "Team", icon: Users },
  { to: "/reports", label: "Reports", icon: ChartNoAxesCombined },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;
const pages: Record<string, { title: string; subtitle: string }> = {
  "/reports": {title:"Financial reports",subtitle:"Organization invoice, supplier and GST records."},
  "/": { title: "Overview", subtitle: "Your accounts payable workspace, at a glance." },
  "/process": { title: "Process invoice", subtitle: "A clear decision, backed by every check." },
  "/history": { title: "Run history", subtitle: "Invoice decisions and their supporting evidence." },
  "/team": { title: "Team", subtitle: "People and permissions in your workspace." },
  "/settings": { title: "Settings", subtitle: "Your invoice validation preferences." },
  "/vendors": { title: "Vendors", subtitle: "Supplier records for your organization." },
  "/purchase-orders": { title: "Purchase orders", subtitle: "Commitments, invoice spending and remaining balances." },
};
export function AppShell({ children }: { children: ReactNode }) {
  const [mobile, setMobile] = useState(false);
  const [rules, setRules] = useState(false);
  const { active, memberships, setActive, user } = useOrg();
  const qc = useQueryClient(); const navigate = useNavigate(); const { pathname } = useLocation();
  const page = pages[pathname] ?? { title: "Overview", subtitle: "Your accounts payable workspace, at a glance." };
  const name = typeof user.user_metadata?.['full_name'] === "string" ? user.user_metadata['full_name'] : user.email?.split("@")[0] ?? "Member";
  async function signOut() { await qc.cancelQueries(); qc.clear(); await supabase.auth.signOut(); navigate({ to: "/auth", search: {}, replace: true }); }
  const sidebar = <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
    <Link to="/" onClick={() => setMobile(false)} className="flex items-center gap-2.5 px-5 py-7"><span className="grid size-8 shrink-0 place-items-center rounded-md bg-primary text-primary-foreground"><Receipt className="size-4" /></span><span className="text-sm font-semibold">SmartInvoice AI</span></Link>
    {active && <div className="mx-4 mb-7 flex items-center gap-2 rounded-md border border-border px-3 py-2.5"><span className="grid size-6 shrink-0 place-items-center rounded bg-secondary text-xs font-semibold">{active.organization_name.slice(0, 1)}</span>{memberships.length > 1 ? <select aria-label="Switch organization" value={active.organization_id} onChange={e => setActive(e.target.value)} className="min-w-0 flex-1 bg-transparent text-xs font-medium">{memberships.map(m => <option key={m.organization_id} value={m.organization_id}>{m.organization_name}</option>)}</select> : <span className="min-w-0 flex-1 truncate text-xs font-medium">{active.organization_name}</span>}<ChevronDown className="size-3 text-muted-foreground" /></div>}
    <p className="px-6 text-[10px] font-semibold uppercase text-muted-foreground">Workspace</p>
    <nav className="mt-3 space-y-1 px-3">{nav.map(({ to, label, icon: I }) => <Button key={to} asChild variant="ghost" className="h-10 w-full justify-start px-3 text-muted-foreground data-[status=active]:bg-sidebar-accent data-[status=active]:text-primary"><Link to={to} activeOptions={{ exact: true }} onClick={() => setMobile(false)}><I className="size-4" />{label}</Link></Button>)}</nav>
    <div className="mt-auto border-t border-border p-4"><div className="flex items-center gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-full bg-secondary text-xs font-semibold">{name.slice(0, 2).toUpperCase()}</span><div className="min-w-0"><p className="truncate text-xs font-semibold">{name}</p><p className="mt-0.5 truncate text-[11px] text-muted-foreground">{user.email}</p></div></div><div className="mt-3 flex items-center justify-between"><span className="rounded-md bg-secondary px-2 py-1 text-[10px] font-medium">{active && ROLE_LABELS[active.role]}</span><div className="flex"><Button asChild variant="ghost" size="icon" title="New organization"><Link to="/onboarding"><Plus /></Link></Button><Button variant="ghost" size="icon" onClick={signOut} title="Sign out" aria-label="Sign out"><LogOut /></Button></div></div></div>
  </div>;
  return <div className="flex min-h-screen bg-background">
    <aside className="sticky top-0 hidden h-screen w-[240px] shrink-0 border-r border-border md:block">{sidebar}</aside>
    <Sheet open={mobile} onOpenChange={setMobile}><SheetContent side="left" className="w-[280px] p-0"><SheetTitle className="sr-only">Workspace navigation</SheetTitle><SheetDescription className="sr-only">SmartInvoice AI navigation and account</SheetDescription>{sidebar}</SheetContent></Sheet>
    <div className="min-w-0 flex-1"><header className="border-b border-border bg-card"><div className="mx-auto flex max-w-[1200px] flex-wrap items-center justify-between gap-4 px-5 py-6 lg:px-8"><div className="flex items-center gap-3"><Button variant="ghost" size="icon" className="md:hidden" aria-label="Open navigation" onClick={() => setMobile(true)}><Menu /></Button><div><h1 className="text-xl font-semibold">{page.title}</h1><p className="mt-1 text-xs text-muted-foreground">{page.subtitle}</p></div></div><div className="flex items-center gap-2"><Button variant="outline" onClick={() => setRules(true)}><SlidersHorizontal />Rules</Button><Button asChild><Link to="/process"><Plus />Process invoice</Link></Button></div></div></header>
      <main className="mx-auto max-w-[1200px] space-y-6 px-5 py-8 lg:px-8">{children}</main>
    </div>
    <Sheet open={rules} onOpenChange={setRules}><SheetContent className="w-full overflow-y-auto sm:max-w-[420px]"><SheetTitle>Validation rules</SheetTitle><SheetDescription className="mt-2">Invoice checks</SheetDescription><div className="mt-8">{rules && <RulesForm onSaved={() => setRules(false)} />}</div></SheetContent></Sheet>
  </div>;
}
