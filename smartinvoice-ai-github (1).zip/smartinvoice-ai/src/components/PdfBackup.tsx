import { useState } from 'react';
import { Download, FileCheck2 } from 'lucide-react';
import { useServerFn } from '@tanstack/react-start';
import { toast } from 'sonner';
import { Button } from './ui/button';
import { useOrg } from '@/lib/org';
import { supabase } from '@/integrations/supabase/client';
import { readPdfBackupPage } from '@/lib/pdf-backup.functions';
import { BACKUP_MAX_BYTES, verifyBackupArchive, type BackupManifest } from '@/lib/pdf-backup';
import { sha256 } from '@/lib/invoice';

export function PdfBackup() {
  const { active } = useOrg();
  const read = useServerFn(readPdfBackupPage);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState('');
  if (active?.role !== 'admin') return null;
  const org = active.organization_id;
  async function download() {
    setBusy(true); setResult('');
    try {
      const listing = await read({ data: { organizationId: org, page } });
      setPages(listing.pages);
      if (!listing.files.length) throw new Error('No PDFs on this backup page.');
      const { zipSync, strToU8 } = await import('fflate');
      const archive: Record<string, Uint8Array> = {};
      const manifest: BackupManifest = { version: 1, organizationId: org, createdAt: new Date().toISOString(), files: [] };
      let size = 0;
      for (const file of listing.files) {
        const { data, error } = await supabase.storage.from('invoice-pdfs').download(file.path);
        if (error || !data) throw new Error('Backup incomplete: a private PDF could not be downloaded.');
        size += data.size;
        if (size > BACKUP_MAX_BYTES - 1024 * 1024) throw new Error('This page exceeds 100 MB. Download its files separately through More → Storage.');
        const bytes = new Uint8Array(await data.arrayBuffer());
        const hash = await sha256(bytes.slice().buffer);
        if (file.sha256 && hash !== file.sha256) throw new Error('Original PDF checksum mismatch; backup stopped.');
        archive[file.path] = bytes;
        manifest.files.push({ ...file, sha256: hash });
      }
      archive['manifest.json'] = strToU8(JSON.stringify(manifest, null, 2));
      const zipped = zipSync(archive, { level: 0 });
      await verifyBackupArchive(zipped, org);
      const url = URL.createObjectURL(new Blob([zipped.slice().buffer], { type: 'application/zip' }));
      const anchor = document.createElement('a'); anchor.href = url; anchor.download = `smartinvoice-pdfs-${org}-page-${page}-${new Date().toISOString().slice(0,10)}.zip`; anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 60000);
      setResult(`${manifest.files.length} PDFs verified. Page ${page} of ${listing.pages} downloaded.`);
    } catch (error) { toast.error(error instanceof Error ? error.message : 'Backup failed.'); }
    finally { setBusy(false); }
  }
  return <section className="mt-10 space-y-4 border-t border-border pt-6">
    <h2 className="text-base font-semibold">Private PDF backups</h2>
    <div className="flex flex-wrap items-end gap-3">
      <label className="text-sm font-medium">Backup page<input aria-label="Backup page" className="mt-1 block w-24 rounded-md border border-input bg-card px-3 py-2" type="number" min={1} max={pages ?? 1000000} value={page} onChange={event => setPage(Math.max(1, Number(event.target.value) || 1))} /></label>
      <Button variant="outline" disabled={busy} onClick={download}><Download />Download PDF backup</Button>
      <label><span className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-input bg-card px-4 py-2 text-sm font-medium"><FileCheck2 className="size-4" />Verify backup</span><input className="sr-only" aria-label="Verify backup archive" type="file" accept=".zip" disabled={busy} onChange={async event => {
        const file = event.target.files?.[0]; if (!file) return;
        setBusy(true); setResult('');
        try { if (file.size > BACKUP_MAX_BYTES) throw new Error('Backup exceeds 100 MB.'); const manifest = await verifyBackupArchive(new Uint8Array(await file.arrayBuffer()), org); setResult(`${manifest.files.length} PDFs verified; organization and checksums match. No records changed.`); }
        catch (error) { toast.error(error instanceof Error ? error.message : 'Backup verification failed.'); }
        finally { setBusy(false); event.target.value = ''; }
      }} /></label>
    </div>
    {result && <p role="status" className="text-sm text-muted-foreground">{result}</p>}
  </section>;
}