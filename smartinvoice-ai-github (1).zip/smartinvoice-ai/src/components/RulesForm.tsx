import { useEffect, useState } from "react";
import { Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { usePolicy } from "@/lib/policy";

export function RulesForm({ onSaved }: { onSaved?: () => void }) {
  const {settings,save,canEdit,loading,error}=usePolicy();
  const [busy,setBusy]=useState(false);
  const [draft, setDraft] = useState(settings);
  useEffect(() => setDraft(settings), [settings]);
  if(error)return <p role="alert">Organization rules could not be loaded.</p>;
  return <form className="space-y-6" onSubmit={async(e) => { e.preventDefault();setBusy(true);try{await save(draft);toast.success("Organization validation rules saved");onSaved?.();}catch(e){toast.error(e instanceof Error?e.message:'Rules could not be saved');}finally{setBusy(false);}}}><fieldset disabled={!canEdit||loading||busy} className="space-y-6">
    <label className="block text-sm font-medium">PO amount tolerance <span className="num float-right text-primary">{draft.tolerance.toFixed(1)}%</span><input aria-label="PO amount tolerance" type="range" min={0} max={10} step={0.5} value={draft.tolerance} onChange={e => setDraft({ ...draft, tolerance: +e.target.value })} className="mt-4 w-full accent-primary" /><span className="mt-1 flex justify-between text-xs text-muted-foreground"><span>0%</span><span>10%</span></span></label>
    <label className="block text-sm font-medium">GST rate (%)<input aria-label="GST rate (%)" className="mt-2 h-10 w-full rounded-md border border-input bg-card px-3 num" type="number" min={0} max={100} required value={draft.gstRate} onChange={e => setDraft({ ...draft, gstRate: +e.target.value })} /></label>
    <label className="block text-sm font-medium">Invoice amount represents<select className="mt-2 h-10 w-full rounded-md border border-input bg-card px-3 text-sm" value={draft.gstBasis} onChange={e => setDraft({ ...draft, gstBasis: e.target.value as "taxable" | "inclusive" })}><option value="taxable">Taxable amount (GST added)</option><option value="inclusive">Total including GST</option></select></label>
    <label className="block text-sm font-medium">GST tolerance (₹)<input aria-label="GST tolerance (₹)" type="number" min={0} step={0.5} required className="num mt-2 h-10 w-full rounded-md border border-input bg-card px-3" value={draft.gstTolerance} onChange={e => setDraft({ ...draft, gstTolerance: +e.target.value })} /></label>
    <Button type="submit" className="w-full"><Save />Save rules</Button></fieldset>{!canEdit&&<p className="text-xs text-muted-foreground">Only admins and finance managers can change organization rules.</p>}
  </form>;
}
