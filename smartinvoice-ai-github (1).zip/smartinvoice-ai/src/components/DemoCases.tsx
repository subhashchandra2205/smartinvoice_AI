import { useState } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DEMO_CASES, downloadDemoInvoice, SCANNED_SAMPLE, type DemoInvoice } from "@/lib/demo-invoices";

export function DemoCases() {
  const [error, setError] = useState<string | null>(null);
  const download = async (sample: DemoInvoice) => {
    try { await downloadDemoInvoice(sample); setError(null); }
    catch { setError("Sample download failed. Please try again."); }
  };
  return <section className="mt-8 border-t border-border pt-6">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <h2 className="font-display text-xl font-semibold">Demo case files</h2>
      <Button variant="outline" size="sm" onClick={() => download(SCANNED_SAMPLE)}><Download />Scanned PDF</Button>
    </div>
    <div className="mt-4 grid gap-4 sm:grid-cols-2">
      {DEMO_CASES.map((item, i) => <article key={item.title} className="rounded-lg border border-border bg-card p-4">
        <p className="text-sm font-semibold"><span className="num mr-2 text-muted-foreground">0{i + 1}</span>{item.title}</p>
        <p className="mt-1 text-xs text-muted-foreground">{item.expected}</p>
        <div className="mt-3 flex flex-col items-start gap-1">{item.files.map((sample) => <Button key={sample.filename} variant="ghost" size="sm" className="h-auto max-w-full whitespace-normal text-left" onClick={() => download(sample)}><Download className="shrink-0" />{sample.filename}</Button>)}</div>
      </article>)}
    </div>
    {error && <p role="alert" className="mt-3 text-sm text-destructive">{error}</p>}
  </section>;
}