import { useState } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { useMutation,useQueryClient } from '@tanstack/react-query';
import { Check,Loader2,X } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { useOrg } from '@/lib/org';
import { approveCloudInvoice,rejectCloudInvoice } from '@/lib/invoices.functions';
import type { Run } from '@/lib/invoice';
export function InvoiceApproval({run,onApproved}:{run:Run;onApproved:()=>void}) {
 const {active,user}=useOrg();const [note,setNote]=useState('');const [error,setError]=useState('');const approve=useServerFn(approveCloudInvoice);const reject=useServerFn(rejectCloudInvoice);const qc=useQueryClient();
 const rejection=useMutation({mutationFn:()=>{if(!active)throw new Error('Select an organization.');return reject({data:{organizationId:active.organization_id,runId:run.id,note}});},onSuccess:async()=>{await qc.invalidateQueries({queryKey:['invoice-workspace']});toast.success('Invoice rejected');onApproved();},onError:e=>setError(e.message)});
 const mutation=useMutation({mutationFn:()=>{if(!active)throw new Error('Select an organization.');return approve({data:{organizationId:active.organization_id,runId:run.id,note}});},onSuccess:async()=>{await Promise.all([qc.invalidateQueries({queryKey:['invoice-workspace']}),qc.invalidateQueries({queryKey:['reference-records']})]);toast.success('Invoice approved');onApproved();},onError:e=>setError(e.message)});
 if(!active||!['admin','finance_manager','reviewer'].includes(active.role)||!['Needs Review','Pending Approval'].includes(run.result.status))return null;
 return <form className="space-y-3 border-t border-border pt-5" onSubmit={e=>{e.preventDefault();setError('');mutation.mutate();}}><label className="grid gap-2 text-xs font-medium">Decision note<Textarea required minLength={3} maxLength={2000} value={note} onChange={e=>setNote(e.target.value)}/></label>{error&&<p role="alert" className="text-xs text-destructive">{error}</p>}<div className="flex flex-wrap gap-2"><Button type="submit" disabled={mutation.isPending||rejection.isPending||note.trim().length<3||run.created_by===user.id}>{mutation.isPending?<Loader2 className="animate-spin"/>:<Check/>}Approve invoice</Button><Button type="button" variant="outline" disabled={mutation.isPending||rejection.isPending||note.trim().length<3} onClick={()=>{setError('');rejection.mutate();}}><X/>Reject invoice</Button></div>{run.created_by===user.id&&<p className="text-xs text-muted-foreground">A separate authorized person must approve your invoice.</p>}</form>;
}