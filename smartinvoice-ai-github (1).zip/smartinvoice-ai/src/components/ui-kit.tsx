import type { ReactNode } from "react";
import type { Status } from "@/lib/invoice";
import { cn } from "@/lib/utils";

export function PageHeader({ title, sub, action, eyebrow }: { title: string; sub?: string; action?: ReactNode; eyebrow?: string }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">{eyebrow}</p>}
        <h1 className="font-display text-xl font-semibold text-foreground">{title}</h1>
        {sub && <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-muted-foreground">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function Panel({ title, children, className, right }: { title?: string; children: ReactNode; className?: string; right?: ReactNode }) {
  return (
    <section className={cn("panel overflow-hidden", className)}>
      {title && (
        <div className="flex items-center justify-between gap-3 border-b border-border bg-card px-5 py-4">
          <h2 className="text-sm font-semibold text-foreground">{title}</h2>
          {right}
        </div>
      )}
      <div className="p-5">{children}</div>
    </section>
  );
}

export function Stat({ label, value, hint, tone }: { label: string; value: ReactNode; hint?: string; tone?: "success" | "warning" | "danger" }) {
  const bar = tone === "success" ? "bg-success" : tone === "warning" ? "bg-warning" : tone === "danger" ? "bg-destructive" : "bg-primary";
  return (
    <div className="panel lift relative overflow-hidden p-5">
      <span className={cn("absolute inset-y-0 left-0 w-1", bar)} />
      <p className="text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
      <p className="num mt-2 text-2xl font-semibold text-foreground">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function StatusPill({ status }: { status: Status | string }) {
  const s =
    status === "Approved" || status === "PASS" ? "bg-success-soft text-success ring-success/20" :
    status === "Rejected" || status === "FAIL" ? "bg-danger-soft text-destructive ring-destructive/20" :
    "bg-warning-soft text-warning ring-warning/25";
  return (
    <span className={cn("inline-flex items-center gap-1.5 whitespace-nowrap rounded-md px-2.5 py-1 text-[10px] font-medium ring-1 ring-inset", s)}>
      <span className="size-1.5 rounded-full bg-current" />
      {status}
    </span>
  );
}

export function Field({ label, value, mono }: { label: string; value: ReactNode; mono?: boolean }) {
  return (
    <div className="min-w-0">
      <dt className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className={cn("mt-2 break-words text-sm font-medium text-foreground", mono && "num", (value === null || value === "—") && "text-muted-foreground")}>{value ?? "Missing"}</dd>
    </div>
  );
}
