# SmartInvoice AI backup and recovery

## Separate backup sets
Cloud daily snapshots cover database schema and data only; the documented window is roughly 14 days. Neither snapshots nor the database export include storage files. No inventory, timestamp or completed restore is claimed without checking More → Database → Manage → Backups.

Invoice PDFs remain in private `invoice-pdfs`, at organization-scoped paths, with a 20 MiB upload limit and membership-gated reads. Ordinary users cannot upload, overwrite or delete stored originals directly. Do not make the bucket public or distribute signed URLs.

## PDF backup procedure
1. An organization administrator opens Settings → Private PDF backups.
2. Download every backup page (25 processing references and 25 job references per page). Each ZIP preserves the original organization path, SHA-256 checksum, invoice IDs and run IDs in `manifest.json`. Repeated originals across pages are safe; they must have identical hashes.
3. The app downloads through the administrator's authenticated session, checks source hashes and verifies the archive before offering it. Missing PDFs or differing hashes stop the page rather than silently creating a complete-looking backup. A page exceeding the 100 MiB safety limit must instead be downloaded through More → Storage. Legacy references lacking a stored hash are hashed during backup; this confirms archive integrity, not historic authenticity.
4. Use Verify backup on each saved ZIP, preferably on another machine. This checks organization, PDF structure, complete listed files and byte checksums offline without changing records.
5. Store copies in two independent access-restricted, encrypted locations, with versioning/immutability where available. The ZIP itself is not encrypted. Treat it as confidential; never email it, publish it or upload it to public file hosting. Archive verification cannot establish the security of its destination.
6. Record UTC backup date, organization, page count, filenames and verification results. Repeat after each day's uploads; take a coordinated database export and PDF set before releases/restores. Pause invoice writes during the coordinated capture if a consistent recovery point is required. Paginated backup pages are not snapshot-isolated.

This is a tested operator-run backup facility, not an automatic off-site backup service. No external backup destination, credentials, schedule or off-site retention was provided; unattended backup remains an owner configuration task. Files with no database/job reference are not included; review More → Storage for orphaned objects.

## Database preservation
More → Database → Manage → Settings → Export project data → Export data → Database → Export → Start export. Export requires a running backend; maximum database 15 GB, export 5 GB, one per 24 hours. Download the emailed link or the saved export in More → Storage. Exports include accounts/password hashes but omit storage, secrets and sign-in provider configuration.

## Isolated recovery drill (recommended)
1. Use a separate destination owned by your organization; never test by restoring production in place.
2. Restore the exported database into that separate destination and reconfigure sign-in providers/API keys there. Do not change production secrets or accounts.
3. Verify the ZIP manifests and restore the PDF files through the destination's owner storage controls at exactly the recorded paths in a **private** `invoice-pdfs` bucket. Lovable Cloud owners use More → Storage; there is no app-user upload bypass or service-role copying script. If the destination UI cannot preserve nested paths, stop and use a destination with supported owner storage import; do not enable browser writes.
4. Compare every restored file's SHA-256 with its manifest and each referenced invoice/run path. Use the app's authenticated PDF viewer and compare the downloaded bytes again.
5. Test existing-account login, two-user approval, locked PO balance, audit events, CSV totals, wrong-organization denial and signed-out PDF denial. Record evidence. A matching local archive alone is not a destination restore drill.

## Production database snapshot restore
The Backups view restores **the same project's whole database in place**. Later writes are lost, schema reverts as well as data, and the database is unavailable for a few minutes. This is permanent; export the current state and independently back up PDFs first. There is no arbitrary point-in-time or per-table restore. Use the closest earlier daily snapshot, a matching app version and manifests for that date. Do not click restore until the owner approves the destructive rollback.

After restoration, storage is unchanged: reconcile referenced paths against separately backed-up PDFs, do not delete newer/orphaned PDFs automatically, and do not overwrite any existing file with different bytes. Test the restored schema against the app and apply any required additive repairs through managed migrations. No production restore was executed by this task.

## Retention recommendation — not activated
For Indian GST-related accounting evidence, recommend retaining invoices, original PDFs, processing/correction/decision evidence and audit events together for at least **8 financial years**, subject to confirmation by your accountant/legal adviser. The statutory GST baseline commonly uses 72 months from the annual-return due date, and proceedings/legal holds can extend it; an eight-year policy is a conservative recommendation, not a legal determination.

Retain failed/abandoned PDF jobs for 90 days **only after explicit administrator adoption**, with legal holds and investigation exceptions. Proposed operational backup rotation: daily versions for 35 days and monthly archives for the adopted accounting period, with at least two isolated encrypted copies. Cloud's automatic database snapshots cannot be configured to this period by this app; separate exports are needed.

All deletion/retention automation remains OFF. No invoices, PDFs, processing runs or audits were deleted, and no retention configuration or destructive schedule was installed. Administrator confirmation must specify jurisdiction, duration/start date, holds, recoverability, approved deletion roles and immutable evidence treatment before implementation. Do not shorten append-only audit integrity to enable cleanup.